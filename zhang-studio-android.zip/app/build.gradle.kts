plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.zhangstudio.app"
    // compileSdk 36: CI run #5 (13 Nov 2026) proved platforms;android-37 is
    // NOT installable on GitHub runners ("Failed to find Platform SDK with
    // path: platforms;android-37") — no stable API-37 platform exists in the
    // SDK repo yet. If CI reports a minCompileSdk error, the error message
    // names the required version.
    compileSdk = 36

    defaultConfig {
        applicationId = "com.zhangstudio.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Media3 1.11.1 = latest stable (Nov 11, 2026, per Jetpack release notes).
    val media3Version = "1.11.1"
    implementation("androidx.media3:media3-transformer:$media3Version")
    implementation("androidx.media3:media3-effect:$media3Version")
    implementation("androidx.media3:media3-common:$media3Version")
    // ComponentActivity + ActivityResultContracts (GetContent pickers).
    // Plain `activity` artifact (Java APIs only) — avoids the Kotlin-based
    // activity-ktx artifact so the scaffold's Kotlin 1.9.22 toolchain is safe
    // against Media3's Kotlin 2.2 metadata.
    implementation("androidx.activity:activity:1.13.0")
}
