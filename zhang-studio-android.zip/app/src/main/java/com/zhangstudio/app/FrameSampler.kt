package com.zhangstudio.app

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.ByteArrayOutputStream

/**
 * v0.14.0: samples small JPEG frames from a video for the server's
 * baked-in subtitle detection (/api/detect-subs-zone). Frames are
 * spread across the video (20/40/60/80% in) so the detector sees the
 * subtitle position most of the video uses, and shrunk to 480px wide
 * so the upload stays tiny on slow connections. Never throws: any
 * failure returns the frames collected so far (possibly none), and
 * the caller falls back to the manual cover bands.
 */
object FrameSampler {

    fun sampleFrames(
        context: Context,
        videoUri: Uri,
        count: Int = 4,
        targetWidth: Int = 480,
        quality: Int = 70
    ): List<ByteArray> {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, videoUri)
            val durationMs = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull() ?: 0L
            if (durationMs <= 0) return emptyList()
            val out = mutableListOf<ByteArray>()
            for (i in 0 until count) {
                val frac = (i + 1).toDouble() / (count + 1)
                val timeUs = (durationMs * 1000 * frac).toLong()
                val frame = try {
                    retriever.getFrameAtTime(
                        timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                    )
                } catch (e: Exception) {
                    null
                } ?: continue
                try {
                    val scaled = if (frame.width > targetWidth) {
                        val h = (frame.height * targetWidth / frame.width).coerceAtLeast(1)
                        Bitmap.createScaledBitmap(frame, targetWidth, h, true)
                    } else {
                        frame
                    }
                    try {
                        val bos = ByteArrayOutputStream()
                        scaled.compress(Bitmap.CompressFormat.JPEG, quality, bos)
                        val bytes = bos.toByteArray()
                        if (bytes.isNotEmpty()) out.add(bytes)
                    } finally {
                        if (scaled !== frame) scaled.recycle()
                    }
                } finally {
                    frame.recycle()
                }
            }
            return out
        } catch (e: Exception) {
            return emptyList()
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }
    }
}
