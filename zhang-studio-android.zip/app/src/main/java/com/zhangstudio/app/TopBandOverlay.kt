package com.zhangstudio.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import androidx.media3.common.OverlaySettings
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.StaticOverlaySettings

/**
 * A [BitmapOverlay] that hides baked-in top logos (v0.10.9): a
 * slightly translucent black band over the top 10% of the frame,
 * shown for the whole export. Source dramas carry platform/account
 * logos in the top corners (e.g. the Xiaohongshu pill top-left,
 * the account name + avatar top-right); the band dims them out.
 * It is NOT fully opaque (alpha 235/255, Zin's "blur it a little"
 * ask): the picture shows through dimly instead of a hard black
 * bar. The Myanmar title (StaticTextOverlay) draws on top of it:
 * this overlay is first in the OverlayEffect list, so it is drawn
 * first. A moving mid-frame watermark cannot be covered by a
 * fixed band — only the top-corner logos are hidden.
 *
 * One instance serves one export only. Call [dispose] after the
 * export ends to drop the bitmap reference (GC reclaims it).
 */
@OptIn(UnstableApi::class)
class TopBandOverlay : BitmapOverlay() {

    @Volatile
    private var bitmap: Bitmap? = null

    @Volatile
    private var settings: OverlaySettings? = null

    private val emptyBitmap: Bitmap =
        Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)

    override fun configure(videoSize: Size) {
        val bandH = (videoSize.height * 0.10f).toInt().coerceAtLeast(1)
        val band = Bitmap.createBitmap(
            videoSize.width.coerceAtLeast(1), bandH, Bitmap.Config.ARGB_8888
        )
        // v0.10.11: alpha 235 — at 200 the white pills stayed
        // clearly readable; 235 hides them, still slightly soft.
        Canvas(band).drawColor(Color.argb(235, 0, 0, 0))
        bitmap = band
        // NDC y axis points up: frame top = +1, frame bottom = -1.
        // Band spans the top bandH pixels: its center is bandH/2
        // below the frame top.
        val bandCenterYPx = bandH / 2f
        val anchorY = 1f - 2f * bandCenterYPx / videoSize.height
        settings = StaticOverlaySettings.Builder()
            .setOverlayFrameAnchor(0f, 0f)
            .setBackgroundFrameAnchor(0f, anchorY)
            .setScale(1f, 1f)
            .build()
    }

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        return bitmap ?: emptyBitmap
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        return settings ?: StaticOverlaySettings.Builder().build()
    }

    /** Drops the bitmap reference (GC reclaims it). Call once, after the export has ended. */
    fun dispose() {
        bitmap = null
    }

    override fun release() {
        dispose()
        super.release()
    }
}
