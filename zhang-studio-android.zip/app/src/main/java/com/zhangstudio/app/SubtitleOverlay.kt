package com.zhangstudio.app

import android.graphics.Bitmap
import android.graphics.Typeface
import androidx.media3.common.OverlaySettings
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.StaticOverlaySettings

/**
 * A [BitmapOverlay] that shows the active subtitle cue's band bitmap.
 *
 * The band bitmaps are rendered lazily (one per cue change, then cached) by
 * [SubtitleBandRenderer], so per-frame work is just a cache lookup. Outside
 * cue intervals a 1x1 transparent bitmap is returned, which is invisible.
 *
 * Positioning uses [StaticOverlaySettings] with the overlay's center
 * anchored to the band's center in Normalised Device Coordinates, at
 * 1:1 pixel scale (the band bitmap is already full video width).
 *
 * One instance serves one export only. Call [dispose] after the export
 * ends (completed, failed, or cancelled) to drop cached bitmaps.
 */
@OptIn(UnstableApi::class)
class SubtitleOverlay(
    private val cues: List<SubtitleCue>,
    private val typeface: Typeface
) : BitmapOverlay() {

    private val lock = Any()

    @Volatile
    private var renderer: SubtitleBandRenderer? = null

    @Volatile
    private var settings: OverlaySettings? = null

    private var cachedCue: SubtitleCue? = null
    private var cachedBitmap: Bitmap? = null

    // 1x1 transparent bitmap: the "no subtitle for this frame" placeholder.
    // Never recycled, so getBitmap() stays safe even after dispose().
    private val emptyBitmap: Bitmap =
        Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)

    override fun configure(videoSize: Size) {
        val prepared = SubtitleBandRenderer(typeface, videoSize.width, videoSize.height)
        prepared.prepare(cues)
        renderer = prepared
        // NDC y axis points up: frame top = +1, frame bottom = -1.
        val bandCenterYPx = prepared.bandTop + prepared.bandHeight / 2f
        val anchorY = 1f - 2f * bandCenterYPx / videoSize.height
        settings = StaticOverlaySettings.Builder()
            .setOverlayFrameAnchor(0f, 0f)
            .setBackgroundFrameAnchor(0f, anchorY)
            .setScale(1f, 1f)
            .build()
    }

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val cue = activeCue(presentationTimeUs)
        val prepared = renderer
        if (cue == null || prepared == null) return emptyBitmap
        synchronized(lock) {
            if (cue != cachedCue) {
                // Old bitmap is dropped, not recycled: the GL thread may
                // still hold it for the frame in flight. GC reclaims it.
                cachedBitmap = prepared.render(cue)
                cachedCue = cue
            }
            return cachedBitmap ?: emptyBitmap
        }
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        // Same settings for every cue: all bands share one size/position.
        // Before configure() runs, fall back to centered defaults.
        return settings ?: StaticOverlaySettings.Builder().build()
    }

    /** Drops cached bitmaps (GC reclaims them). Call once, after the export has ended. */
    fun dispose() {
        synchronized(lock) {
            cachedBitmap = null
            cachedCue = null
        }
    }

    override fun release() {
        dispose()
        super.release()
    }

    /** Latest-starting cue whose interval contains [timeUs], or null. */
    private fun activeCue(timeUs: Long): SubtitleCue? {
        var low = 0
        var high = cues.size - 1
        var found: SubtitleCue? = null
        while (low <= high) {
            val mid = (low + high) ushr 1
            val cue = cues[mid]
            if (timeUs < cue.startUs) {
                high = mid - 1
            } else {
                found = cue
                low = mid + 1
            }
        }
        return found?.takeIf { timeUs < it.endUs }
    }
}
