package com.zhangstudio.app

import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Talks to the Zhang Studio server's TTS and prompt-video APIs
 * (server v15+ for TTS, v17+ for prompt-video).
 *
 * - POST /api/tts (form: text, voice, rate, pitch) returns {"job_id"} at
 *   once (HTTP 202). The job is polled with TranscribeClient.poll() until
 *   it is done; a finished TTS job carries the SRT text plus an audio_url.
 * - GET /api/download/{job_id}/audio returns the finished narration mp3.
 * - POST /api/prompt-video (form: prompt, api_key, voice, rate, pitch)
 *   returns {"job_id"} at once (HTTP 202). A finished job carries the SRT
 *   text plus a video_url (and audio_url) for the assembled video.
 *
 * No Gemini key is needed for TTS: the server's edge-tts voices are free.
 * Prompt-video needs the user's Gemini key (script writing) and sends it
 * with the request, like transcription does.
 * Call only from a background thread (execute() blocks).
 */
class TtsClient {

    companion object {
        const val VOICE_NILAR = "my-MM-NilarNeural"
        const val VOICE_THIHA = "my-MM-ThihaNeural"
        // Gemini TTS voices (language-agnostic prebuilt voices, v22+).
        const val GEMINI_VOICE_FEMALE = "Sulafat"
        const val GEMINI_VOICE_MALE = "Kore"
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .build()

    /** Submits text for narration. Returns the job id to poll.
     * mode "auto" (server v20+) asks Gemini to split the text by character
     * and assign male/female voices per part; it needs the user's Gemini
     * key, sent as api_key. Manual mode needs no key. */
    @Throws(IOException::class)
    fun submit(
        text: String,
        voice: String,
        rate: Int,
        pitch: Int,
        mode: String = "manual",
        apiKey: String? = null
    ): String {
        val formBuilder = FormBody.Builder()
            .add("text", text)
            .add("voice", voice)
            .add("rate", rate.toString())
            .add("pitch", pitch.toString())
            .add("mode", mode)
        if (!apiKey.isNullOrBlank()) {
            formBuilder.add("api_key", apiKey.trim())
        }
        val form = formBuilder.build()
        val request = Request.Builder()
            .url("${TranscribeClient.BASE_URL}/api/tts")
            .post(form)
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail =
                    runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                throw IOException(
                    "Server error ${response.code}" +
                        if (detail.isNotEmpty()) ": $detail" else ""
                )
            }
            val json = runCatching { JSONObject(body) }.getOrNull()
                ?: throw IOException("Server returned an unreadable reply")
            val jobId = json.optString("job_id")
            if (jobId.isEmpty()) throw IOException("Server returned no job id")
            return jobId
        }
    }

    /** Submits text to Gemini's expressive TTS (server v22+): the voice
     * follows a style direction (natural/spooky) with varied pitch.
     * Needs the user's Gemini key. Returns the job id to poll. */
    @Throws(IOException::class)
    fun submitGemini(
        text: String,
        voice: String,
        style: String,
        apiKey: String?
    ): String {
        val formBuilder = FormBody.Builder()
            .add("text", text)
            .add("voice", voice)
            .add("style", style)
        if (!apiKey.isNullOrBlank()) {
            formBuilder.add("api_key", apiKey.trim())
        }
        val form = formBuilder.build()
        val request = Request.Builder()
            .url("${TranscribeClient.BASE_URL}/api/gemini-tts")
            .post(form)
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail =
                    runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                throw IOException(
                    "Server error ${response.code}" +
                        if (detail.isNotEmpty()) ": $detail" else ""
                )
            }
            val json = runCatching { JSONObject(body) }.getOrNull()
                ?: throw IOException("Server returned an unreadable reply")
            val jobId = json.optString("job_id")
            if (jobId.isEmpty()) throw IOException("Server returned no job id")
            return jobId
        }
    }

    /** Submits a prompt for a 3-scene video. Returns the job id to poll.
     * v26+: [imageFiles] (up to 3) become the scenes' pictures in order;
     * scenes without a supplied picture use AI-generated ones.
     * v28+: mode "auto" asks the server to split each scene's narration
     * by character and read each part in that character's own voice. */
    @Throws(IOException::class)
    fun submitPromptVideo(
        prompt: String,
        apiKey: String,
        voice: String,
        rate: Int,
        pitch: Int,
        imageFiles: List<File> = emptyList(),
        mode: String = "manual"
    ): String {
        val builder = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("prompt", prompt)
            .addFormDataPart("api_key", apiKey)
            .addFormDataPart("voice", voice)
            .addFormDataPart("rate", rate.toString())
            .addFormDataPart("pitch", pitch.toString())
            .addFormDataPart("mode", mode)
        imageFiles.take(3).forEachIndexed { idx, file ->
            builder.addFormDataPart(
                "image${idx + 1}", file.name,
                file.asRequestBody("image/jpeg".toMediaTypeOrNull())
            )
        }
        val request = Request.Builder()
            .url("${TranscribeClient.BASE_URL}/api/prompt-video")
            .post(builder.build())
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail =
                    runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                throw IOException(
                    "Server error ${response.code}" +
                        if (detail.isNotEmpty()) ": $detail" else ""
                )
            }
            val json = runCatching { JSONObject(body) }.getOrNull()
                ?: throw IOException("Server returned an unreadable reply")
            val jobId = json.optString("job_id")
            if (jobId.isEmpty()) throw IOException("Server returned no job id")
            return jobId
        }
    }

    /** Downloads the finished narration mp3 for a done job. */
    @Throws(IOException::class)
    fun downloadAudio(audioUrl: String): ByteArray {
        val url = if (audioUrl.startsWith("http")) {
            audioUrl
        } else {
            TranscribeClient.BASE_URL + audioUrl
        }
        val request = Request.Builder().url(url).get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("Server error ${response.code} (audio download)")
            }
            return response.body?.bytes()
                ?: throw IOException("Server returned an empty audio file")
        }
    }
}
