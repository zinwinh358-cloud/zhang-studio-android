package com.zhangstudio.app

import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Talks to the Zhang Studio server's TTS API (server v15+).
 *
 * - POST /api/tts (form: text, voice, rate, pitch) returns {"job_id"} at
 *   once (HTTP 202). The job is polled with TranscribeClient.poll() until
 *   it is done; a finished TTS job carries the SRT text plus an audio_url.
 * - GET /api/download/{job_id}/audio returns the finished narration mp3.
 *
 * No Gemini key is needed: the server's edge-tts voices are free.
 * Call only from a background thread (execute() blocks).
 */
class TtsClient {

    companion object {
        const val VOICE_NILAR = "my-MM-NilarNeural"
        const val VOICE_THIHA = "my-MM-ThihaNeural"
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .build()

    /** Submits text for narration. Returns the job id to poll. */
    @Throws(IOException::class)
    fun submit(text: String, voice: String, rate: Int, pitch: Int): String {
        val form = FormBody.Builder()
            .add("text", text)
            .add("voice", voice)
            .add("rate", rate.toString())
            .add("pitch", pitch.toString())
            .build()
        val request = Request.Builder()
            .url("${TranscribeClient.BASE_URL}/api/tts")
            .post(form)
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail =
                    runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                throw IOException(
                    "Server error ${response.code}" +
                        if (detail.isNotEmpty()) ": $detail" else ""
                )
            }
            val json = runCatching { JSONObject(body) }.getOrNull()
                ?: throw IOException("Server returned an unreadable reply")
            val jobId = json.optString("job_id")
            if (jobId.isEmpty()) throw IOException("Server returned no job id")
            return jobId
        }
    }

    /** Downloads the finished narration mp3 for a done job. */
    @Throws(IOException::class)
    fun downloadAudio(audioUrl: String): ByteArray {
        val url = if (audioUrl.startsWith("http")) {
            audioUrl
        } else {
            TranscribeClient.BASE_URL + audioUrl
        }
        val request = Request.Builder().url(url).get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("Server error ${response.code} (audio download)")
            }
            return response.body?.bytes()
                ?: throw IOException("Server returned an empty audio file")
        }
    }
}
