package com.zhangstudio.app

import android.graphics.Bitmap
import android.graphics.Typeface
import androidx.media3.common.OverlaySettings
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.StaticOverlaySettings

/**
 * A [BitmapOverlay] that shows one fixed line of text at the top of the
 * frame for the whole export (the timing screen's title/text feature).
 * The text is rendered once with [SubtitleBandRenderer] (Myanmar shaping
 * correct) and the same bitmap is returned for every frame.
 *
 * One instance serves one export only.
 *
 * v0.9.3: [xFrac]/[topFrac] are the dragged title position on the
 * preview (fractions of the frame; defaults reproduce the original
 * centered top placement).
 */
@OptIn(UnstableApi::class)
class StaticTextOverlay(
    private val text: String,
    private val typeface: Typeface,
    private val xFrac: Float = 0.5f,
    private val topFrac: Float = 0.08f
) : BitmapOverlay() {

    @Volatile
    private var bitmap: Bitmap? = null

    @Volatile
    private var settings: OverlaySettings? = null

    private val emptyBitmap: Bitmap =
        Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)

    override fun configure(videoSize: Size) {
        val renderer = SubtitleBandRenderer(typeface, videoSize.width, videoSize.height)
        val cue = SubtitleCue(0L, Long.MAX_VALUE, text, xFrac = xFrac)
        renderer.prepare(listOf(cue))
        bitmap = renderer.render(cue)
        // NDC y axis points up: frame top = +1. Band top at topFrac
        // below the frame top (0.08 = the original placement),
        // mirroring the subtitle bottom margin.
        val bandCenterYPx = topFrac * videoSize.height + renderer.bandHeight / 2f
        val anchorY = 1f - 2f * bandCenterYPx / videoSize.height
        settings = StaticOverlaySettings.Builder()
            .setOverlayFrameAnchor(0f, 0f)
            .setBackgroundFrameAnchor(0f, anchorY)
            .setScale(1f, 1f)
            .build()
    }

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        return bitmap ?: emptyBitmap
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        return settings ?: StaticOverlaySettings.Builder().build()
    }

    override fun release() {
        bitmap = null
        super.release()
    }
}
