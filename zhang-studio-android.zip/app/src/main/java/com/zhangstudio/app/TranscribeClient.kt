package com.zhangstudio.app

import android.content.ContentResolver
import android.net.Uri
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okio.BufferedSink
import okio.source
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Uploads a video to the Zhang Studio server, which listens with Gemini
 * and returns the Myanmar subtitles (SRT text). The Gemini API key lives
 * on the server only — it is never in the app.
 *
 * The upload streams from the content Uri (no full-file copy in memory).
 * Gemini transcription can take 1-3 minutes, so the read/write timeouts
 * are long. Call only from a background thread (execute() blocks).
 */
class TranscribeClient(private val contentResolver: ContentResolver) {

    companion object {
        // Single place for the server address. The Render service URL
        // never changes when the app is updated.
        const val BASE_URL = "https://zhang-studio.onrender.com"
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(300, TimeUnit.SECONDS)
        .writeTimeout(300, TimeUnit.SECONDS)
        .build()

    /** Returns the SRT text, or throws IOException with a readable reason. */
    @Throws(IOException::class)
    fun transcribe(videoUri: Uri, fileName: String): String {
        val videoBody = object : RequestBody() {
            override fun contentType() = "video/mp4".toMediaTypeOrNull()

            override fun writeTo(sink: BufferedSink) {
                val stream = contentResolver.openInputStream(videoUri)
                    ?: throw IOException("Could not open the video")
                stream.use { sink.writeAll(it.source()) }
            }
        }
        val multipart = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("video", fileName, videoBody)
            .build()
        val request = Request.Builder()
            .url("$BASE_URL/api/transcribe")
            .post(multipart)
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail =
                    runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                throw IOException(
                    "Server error ${response.code}" +
                        if (detail.isNotEmpty()) ": $detail" else ""
                )
            }
            val srt = runCatching { JSONObject(body).getString("srt") }.getOrNull().orEmpty()
            if (srt.isBlank()) throw IOException("Server returned no subtitles")
            return srt
        }
    }
}
