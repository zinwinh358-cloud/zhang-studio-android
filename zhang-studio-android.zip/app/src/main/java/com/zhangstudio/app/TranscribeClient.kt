package com.zhangstudio.app

import android.content.ContentResolver
import android.net.Uri
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okio.BufferedSink
import okio.source
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Talks to the Zhang Studio server. Two server generations are supported:
 * - v14+ (async): POST /api/transcribe returns {"job_id"} at once; the
 *   client polls GET /api/status/{job_id} until the job is done. This is
 *   what makes slow mobile connections work — no single request waits
 *   minutes, so nothing times out.
 * - v13 (sync): POST returns {"srt", "model"} directly. Still handled,
 *   with long timeouts, so the app keeps working before the server
 *   upgrade lands.
 *
 * The user's Gemini API key (entered once in the app) is sent with the
 * upload; the server uses it when present and falls back to its own key.
 * The upload streams from the content Uri (no full-file copy in memory).
 * Call only from a background thread (execute() blocks).
 */
class TranscribeClient(private val contentResolver: ContentResolver) {

    companion object {
        // Single place for the server address. The Render service URL
        // never changes when the app is updated.
        const val BASE_URL = "https://zhang-studio.onrender.com"
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(600, TimeUnit.SECONDS)
        .writeTimeout(600, TimeUnit.SECONDS)
        .build()

    /** Result of submitting a video: either a job to poll, or SRT already. */
    sealed class SubmitResult {
        data class Job(val jobId: String) : SubmitResult()
        data class Ready(val srt: String, val model: String) : SubmitResult()
    }

    data class JobState(
        val status: String,
        val srt: String?,
        val model: String?,
        val error: String?
    )

    @Throws(IOException::class)
    fun submit(videoUri: Uri, fileName: String, apiKey: String?): SubmitResult {
        val videoBody = object : RequestBody() {
            override fun contentType() = "video/mp4".toMediaTypeOrNull()

            override fun writeTo(sink: BufferedSink) {
                val stream = contentResolver.openInputStream(videoUri)
                    ?: throw IOException("Could not open the video")
                stream.use { sink.writeAll(it.source()) }
            }
        }
        val builder = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("video", fileName, videoBody)
        if (!apiKey.isNullOrBlank()) {
            builder.addFormDataPart("api_key", apiKey.trim())
        }
        val request = Request.Builder()
            .url("$BASE_URL/api/transcribe")
            .post(builder.build())
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail =
                    runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                throw IOException(
                    "Server error ${response.code}" +
                        if (detail.isNotEmpty()) ": $detail" else ""
                )
            }
            val json = runCatching { JSONObject(body) }.getOrNull()
                ?: throw IOException("Server returned an unreadable reply")
            val jobId = json.optString("job_id")
            if (jobId.isNotEmpty()) return SubmitResult.Job(jobId)
            val srt = json.optString("srt")
            if (srt.isNotBlank()) return SubmitResult.Ready(srt, json.optString("model"))
            throw IOException("Server returned no subtitles")
        }
    }

    @Throws(IOException::class)
    fun poll(jobId: String): JobState {
        val request = Request.Builder()
            .url("$BASE_URL/api/status/$jobId")
            .get()
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail =
                    runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                throw IOException(
                    "Server error ${response.code}" +
                        if (detail.isNotEmpty()) ": $detail" else ""
                )
            }
            val json = JSONObject(body)
            return JobState(
                status = json.optString("status"),
                srt = json.optString("srt").ifEmpty { null },
                model = json.optString("model").ifEmpty { null },
                error = json.optString("error").ifEmpty { null }
            )
        }
    }
}
