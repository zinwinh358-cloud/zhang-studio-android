package com.zhangstudio.app

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okio.Buffer
import okio.BufferedSink
import okio.ForwardingSink
import okio.buffer
import okio.source
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Talks to the Zhang Studio server. Two server generations are supported:
 * - v14+ (async): POST /api/transcribe returns {"job_id"} at once; the
 *   client polls GET /api/status/{job_id} until the job is done. This is
 *   what makes slow mobile connections work — no single request waits
 *   minutes, so nothing times out.
 * - v13 (sync): POST returns {"srt", "model"} directly. Still handled,
 *   with long timeouts, so the app keeps working before the server
 *   upgrade lands.
 *
 * The user's Gemini API key (entered once in the app) is sent with the
 * upload; the server uses it when present and falls back to its own key.
 * The upload streams from the content Uri (no full-file copy in memory).
 * Call only from a background thread (execute() blocks).
 */
class TranscribeClient(private val contentResolver: ContentResolver) {

    companion object {
        // Single place for the server address. The Render service URL
        // never changes when the app is updated.
        const val BASE_URL = "https://zhang-studio.onrender.com"
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(600, TimeUnit.SECONDS)
        .writeTimeout(600, TimeUnit.SECONDS)
        .build()

    /** Result of submitting a video: either a job to poll, or SRT already. */
    sealed class SubmitResult {
        data class Job(val jobId: String) : SubmitResult()
        data class Ready(val srt: String, val model: String) : SubmitResult()
    }

    /**
     * v0.6.6: upload progress. Wraps a streaming body so the UI can show a
     * percentage while a video/image uploads. The total comes from the
     * content provider; when it is unknown the callback never fires and
     * the UI keeps its indeterminate state. The callback runs on the
     * calling (background) thread; the UI must post to the main thread.
     */
    private class CountingRequestBody(
        private val delegate: RequestBody,
        private val totalBytes: Long,
        private val onProgress: (Int) -> Unit
    ) : RequestBody() {
        override fun contentType() = delegate.contentType()
        override fun contentLength() = delegate.contentLength()
        override fun writeTo(sink: BufferedSink) {
            var sent = 0L
            var lastPercent = -1
            val counting = object : ForwardingSink(sink) {
                override fun write(source: Buffer, byteCount: Long) {
                    super.write(source, byteCount)
                    sent += byteCount
                    if (totalBytes > 0) {
                        val pct = ((sent * 100) / totalBytes).toInt().coerceIn(0, 100)
                        if (pct != lastPercent) {
                            lastPercent = pct
                            onProgress(pct)
                        }
                    }
                }
            }
            delegate.writeTo(counting.buffer())
            counting.flush()
        }
    }

    private fun uriSize(uri: Uri): Long {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getLong(0) else -1L }
                ?: -1L
        } catch (e: Exception) {
            -1L
        }
    }

    /** Streaming body for a content Uri, with optional upload progress.
     * contentLength stays -1 (chunked) on purpose: a size reported by the
     * provider is only used for the percentage, never declared to OkHttp —
     * a wrong declared length aborts the upload ("unexpected end of
     * stream"). The percentage is approximate when the size is off, but
     * the upload itself can never break because of it. */
    private fun streamBody(uri: Uri, mime: String, onProgress: ((Int) -> Unit)?): RequestBody {
        val size = uriSize(uri)
        val base = object : RequestBody() {
            override fun contentType() = mime.toMediaTypeOrNull()
            override fun contentLength() = -1L
            override fun writeTo(sink: BufferedSink) {
                val stream = contentResolver.openInputStream(uri)
                    ?: throw IOException("Could not open the file")
                stream.use { sink.writeAll(it.source()) }
            }
        }
        return if (onProgress != null && size > 0) {
            CountingRequestBody(base, size, onProgress)
        } else {
            base
        }
    }

    data class JobState(
        val status: String,
        val srt: String?,
        val model: String?,
        val error: String?,
        // TTS jobs only: relative URL of the finished mp3, e.g.
        // "/api/download/<job_id>/audio". Null for transcribe jobs.
        val audioUrl: String? = null,
        // Voiceover jobs only: relative URL of the finished mp4, e.g.
        // "/api/download/<job_id>/video". Null for other jobs.
        val videoUrl: String? = null,
        // Audio-only voiceover jobs (v31+) only: relative URL of the
        // narration .m4a (AAC), e.g. "/api/download/<job_id>/audio-m4a".
        val audioM4aUrl: String? = null,
        // MTV jobs only: the song title YouTube returned. Null otherwise.
        val title: String? = null
    )

    @Throws(IOException::class)
    fun submit(
        videoUri: Uri,
        fileName: String,
        apiKey: String?,
        onUploadProgress: ((Int) -> Unit)? = null
    ): SubmitResult {
        val videoBody = streamBody(videoUri, "video/mp4", onUploadProgress)
        val builder = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("video", fileName, videoBody)
        if (!apiKey.isNullOrBlank()) {
            builder.addFormDataPart("api_key", apiKey.trim())
        }
        val request = Request.Builder()
            .url("$BASE_URL/api/transcribe")
            .post(builder.build())
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail =
                    runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                throw IOException(
                    "Server error ${response.code}" +
                        if (detail.isNotEmpty()) ": $detail" else ""
                )
            }
            val json = runCatching { JSONObject(body) }.getOrNull()
                ?: throw IOException("Server returned an unreadable reply")
            val jobId = json.optString("job_id")
            if (jobId.isNotEmpty()) return SubmitResult.Job(jobId)
            val srt = json.optString("srt")
            if (srt.isNotBlank()) return SubmitResult.Ready(srt, json.optString("model"))
            throw IOException("Server returned no subtitles")
        }
    }

    /**
     * Submits phone-extracted audio for transcription (server v35+):
     * the app uploads only the .m4a audio instead of the whole video
     * (~10x less upload data, much faster on slow connections).
     * Same /api/transcribe endpoint and "video" field; the server
     * detects audio-only input and skips the video probe.
     */
    @Throws(IOException::class)
    fun submitAudioFile(
        audioFile: File,
        fileName: String,
        apiKey: String?,
        onUploadProgress: ((Int) -> Unit)? = null
    ): SubmitResult {
        val audioBody = fileBody(audioFile, "audio/mp4", onUploadProgress)
        val builder = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("video", fileName, audioBody)
        if (!apiKey.isNullOrBlank()) {
            builder.addFormDataPart("api_key", apiKey.trim())
        }
        val request = Request.Builder()
            .url("$BASE_URL/api/transcribe")
            .post(builder.build())
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail =
                    runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                throw IOException(
                    "Server error ${response.code}" +
                        if (detail.isNotEmpty()) ": $detail" else ""
                )
            }
            val json = runCatching { JSONObject(body) }.getOrNull()
                ?: throw IOException("Server returned an unreadable reply")
            val jobId = json.optString("job_id")
            if (jobId.isNotEmpty()) return SubmitResult.Job(jobId)
            val srt = json.optString("srt")
            if (srt.isNotBlank()) return SubmitResult.Ready(srt, json.optString("model"))
            throw IOException("Server returned no subtitles")
        }
    }

    /**
     * Submits a video for the voiceover pipeline (server v16+): the server
     * transcribes/translates it, narrates it in Myanmar, and muxes the
     * narration into the video. Returns the job id to poll; a finished job
     * carries video_url + audio_url + srt.
     */
    @Throws(IOException::class)
    fun submitVoiceover(
        videoUri: Uri,
        fileName: String,
        apiKey: String?,
        voice: String,
        rate: Int,
        pitch: Int,
        mode: String = "manual",
        onUploadProgress: ((Int) -> Unit)? = null
    ): String {
        val videoBody = streamBody(videoUri, "video/mp4", onUploadProgress)
        val builder = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("video", fileName, videoBody)
            .addFormDataPart("voice", voice)
            .addFormDataPart("rate", rate.toString())
            .addFormDataPart("pitch", pitch.toString())
            .addFormDataPart("mode", mode)
        if (!apiKey.isNullOrBlank()) {
            builder.addFormDataPart("api_key", apiKey.trim())
        }
        val request = Request.Builder()
            .url("$BASE_URL/api/voiceover")
            .post(builder.build())
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail =
                    runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                throw IOException(
                    "Server error ${response.code}" +
                        if (detail.isNotEmpty()) ": $detail" else ""
                )
            }
            val json = runCatching { JSONObject(body) }.getOrNull()
                ?: throw IOException("Server returned an unreadable reply")
            val jobId = json.optString("job_id")
            if (jobId.isEmpty()) throw IOException("Server returned no job id")
            return jobId
        }
    }

    /** Streaming body for a local file (the extracted voiceover audio),
     * with optional upload progress. The file length is exact, so the
     * percentage is accurate. */
    private fun fileBody(file: File, mime: String, onProgress: ((Int) -> Unit)?): RequestBody {
        val base = object : RequestBody() {
            override fun contentType() = mime.toMediaTypeOrNull()
            override fun contentLength() = file.length()
            override fun writeTo(sink: BufferedSink) {
                file.inputStream().use { sink.writeAll(it.source()) }
            }
        }
        return if (onProgress != null) {
            CountingRequestBody(base, file.length(), onProgress)
        } else {
            base
        }
    }

    /**
     * Submits extracted audio for the audio-only voiceover pipeline
     * (server v31+): the server transcribes/translates it and narrates
     * it in Myanmar. Returns the job id to poll; a finished job carries
     * audio_m4a_url (narration, AAC in .m4a) + audio_url (mp3) + srt.
     * The phone muxes the narration onto the original video itself.
     */
    @Throws(IOException::class)
    fun submitVoiceoverAudio(
        audioFile: File,
        fileName: String,
        apiKey: String?,
        voice: String,
        rate: Int,
        pitch: Int,
        mode: String = "manual",
        onUploadProgress: ((Int) -> Unit)? = null
    ): String {
        val audioBody = fileBody(audioFile, "audio/mp4", onUploadProgress)
        val builder = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("audio", fileName, audioBody)
            .addFormDataPart("voice", voice)
            .addFormDataPart("rate", rate.toString())
            .addFormDataPart("pitch", pitch.toString())
            .addFormDataPart("mode", mode)
        if (!apiKey.isNullOrBlank()) {
            builder.addFormDataPart("api_key", apiKey.trim())
        }
        val request = Request.Builder()
            .url("$BASE_URL/api/voiceover-audio")
            .post(builder.build())
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail =
                    runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                throw IOException(
                    "Server error ${response.code}" +
                        if (detail.isNotEmpty()) ": $detail" else ""
                )
            }
            val json = runCatching { JSONObject(body) }.getOrNull()
                ?: throw IOException("Server returned an unreadable reply")
            val jobId = json.optString("job_id")
            if (jobId.isEmpty()) throw IOException("Server returned no job id")
            return jobId
        }
    }

    /**
     * Submits a character image + text for a narrated video (server v21+):
     * the image with a slow zoom, Myanmar narration, and burned subtitles.
     * Returns the job id to poll. A finished job carries video_url,
     * audio_url, and the SRT text.
     */
    @Throws(IOException::class)
    fun submitNarrateImage(
        imageUri: Uri,
        fileName: String,
        text: String,
        apiKey: String?,
        voice: String,
        rate: Int,
        pitch: Int,
        mode: String,
        engine: String = "edge",
        style: String = "natural",
        onUploadProgress: ((Int) -> Unit)? = null
    ): String {
        val imageBody = streamBody(
            imageUri,
            contentResolver.getType(imageUri) ?: "image/jpeg",
            onUploadProgress
        )
        val builder = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("image", fileName, imageBody)
            .addFormDataPart("text", text)
            .addFormDataPart("voice", voice)
            .addFormDataPart("rate", rate.toString())
            .addFormDataPart("pitch", pitch.toString())
            .addFormDataPart("mode", mode)
            .addFormDataPart("engine", engine)
            .addFormDataPart("style", style)
        if (!apiKey.isNullOrBlank()) {
            builder.addFormDataPart("api_key", apiKey.trim())
        }
        val request = Request.Builder()
            .url("$BASE_URL/api/narrate-image")
            .post(builder.build())
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail =
                    runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                throw IOException(
                    "Server error ${response.code}" +
                        if (detail.isNotEmpty()) ": $detail" else ""
                )
            }
            val json = runCatching { JSONObject(body) }.getOrNull()
                ?: throw IOException("Server returned an unreadable reply")
            val jobId = json.optString("job_id")
            if (jobId.isEmpty()) throw IOException("Server returned no job id")
            return jobId
        }
    }

    /**
     * Submits a person photo + song name and/or YouTube link for a
     * 20-second MTV (server v29+): the server fetches the song (the
     * link when given, else the first YouTube search result), takes
     * its loudest 20 seconds, and builds a slow-zoom video from the
     * photo. Returns the job id to poll. A finished job carries
     * video_url, audio_url, and the song title. No Gemini key needed.
     */
    @Throws(IOException::class)
    fun submitMtv(
        imageUri: Uri,
        fileName: String,
        song: String,
        link: String? = null,
        onUploadProgress: ((Int) -> Unit)? = null
    ): String {
        val imageBody = streamBody(
            imageUri,
            contentResolver.getType(imageUri) ?: "image/jpeg",
            onUploadProgress
        )
        val builder = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("image", fileName, imageBody)
            .addFormDataPart("song", song)
        if (!link.isNullOrBlank()) {
            builder.addFormDataPart("link", link.trim())
        }
        val request = Request.Builder()
            .url("$BASE_URL/api/mtv")
            .post(builder.build())
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail =
                    runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                throw IOException(
                    "Server error ${response.code}" +
                        if (detail.isNotEmpty()) ": $detail" else ""
                )
            }
            val json = runCatching { JSONObject(body) }.getOrNull()
                ?: throw IOException("Server returned an unreadable reply")
            val jobId = json.optString("job_id")
            if (jobId.isEmpty()) throw IOException("Server returned no job id")
            return jobId
        }
    }

    /**
     * Streams a finished file (video_url / audio_url) to [dest] without
     * holding it in memory — finished videos can be tens of megabytes.
     */
    @Throws(IOException::class)
    fun downloadToFile(url: String, dest: File) {
        // v0.9.9: retry the download — Zin's connection regularly drops
        // mid-stream ("unexpected end of stream", 14 Nov voiceover test).
        // Fresh GET each attempt; partial files deleted so nothing
        // corrupt is ever used. Server cost is nil (static file), unlike
        // re-submitting a job (which would re-spend Gemini quota).
        val fullUrl = if (url.startsWith("http")) url else BASE_URL + url
        for (attempt in 0 until 5) {
            try {
                val request = Request.Builder().url(fullUrl).get().build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        throw IOException("Server error ${response.code} (download)")
                    }
                    val body = response.body ?: throw IOException("Server returned an empty file")
                    body.byteStream().use { input ->
                        dest.outputStream().use { output -> input.copyTo(output) }
                    }
                }
                return
            } catch (e: IOException) {
                // Real server errors (404/500) must not be retried as
                // connection drops — surface them at once.
                if (e.message?.startsWith("Server error") == true) throw e
                runCatching { if (dest.exists()) dest.delete() }
                if (attempt < 4) Thread.sleep(4000)
            }
        }
        throw IOException("ဒေါင်းလုဒ် လုပ်နေရင်း လိုင်းပြတ်သွားတယ်။ လိုင်းကောင်းတဲ့အချိန် ထပ်စမ်းပါ။")
    }

    @Throws(IOException::class)
    fun poll(jobId: String): JobState {
        val request = Request.Builder()
            .url("$BASE_URL/api/status/$jobId")
            .get()
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail =
                    runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                throw IOException(
                    "Server error ${response.code}" +
                        if (detail.isNotEmpty()) ": $detail" else ""
                )
            }
            val json = JSONObject(body)
            return JobState(
                status = json.optString("status"),
                srt = json.optString("srt").ifEmpty { null },
                model = json.optString("model").ifEmpty { null },
                error = json.optString("error").ifEmpty { null },
                audioUrl = json.optString("audio_url").ifEmpty { null },
                videoUrl = json.optString("video_url").ifEmpty { null },
                audioM4aUrl = json.optString("audio_m4a_url").ifEmpty { null },
                title = json.optString("title").ifEmpty { null }
            )
        }
    }
}
