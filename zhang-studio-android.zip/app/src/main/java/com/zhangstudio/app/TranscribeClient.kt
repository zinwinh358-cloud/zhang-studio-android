package com.zhangstudio.app

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okio.Buffer
import okio.BufferedSink
import okio.ForwardingSink
import okio.buffer
import okio.source
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Talks to the Zhang Studio server. Two server generations are supported:
 * - v14+ (async): POST /api/transcribe returns {"job_id"} at once; the
 *   client polls GET /api/status/{job_id} until the job is done. This is
 *   what makes slow mobile connections work — no single request waits
 *   minutes, so nothing times out.
 * - v13 (sync): POST returns {"srt", "model"} directly. Still handled,
 *   with long timeouts, so the app keeps working before the server
 *   upgrade lands.
 *
 * The user's Gemini API key (entered once in the app) is sent with the
 * upload; the server uses it when present and falls back to its own key.
 * The upload streams from the content Uri (no full-file copy in memory).
 * Call only from a background thread (execute() blocks).
 */
class TranscribeClient(private val contentResolver: ContentResolver) {

    companion object {
        // Single place for the server address. The Render service URL
        // never changes when the app is updated.
        const val BASE_URL = "https://zhang-studio.onrender.com"
        // v0.10.2: chunked uploads — 1MB parts, each retried on its own.
        const val CHUNK_SIZE = 1024 * 1024
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(600, TimeUnit.SECONDS)
        .writeTimeout(600, TimeUnit.SECONDS)
        .build()

    /** Result of submitting a video: either a job to poll, or SRT already. */
    sealed class SubmitResult {
        data class Job(val jobId: String) : SubmitResult()
        data class Ready(val srt: String, val model: String) : SubmitResult()
    }

    /**
     * v0.6.6: upload progress. Wraps a streaming body so the UI can show a
     * percentage while a video/image uploads. The total comes from the
     * content provider; when it is unknown the callback never fires and
     * the UI keeps its indeterminate state. The callback runs on the
     * calling (background) thread; the UI must post to the main thread.
     */
    private class CountingRequestBody(
        private val delegate: RequestBody,
        private val totalBytes: Long,
        private val onProgress: (Int) -> Unit,
        private val sentHolder: LongArray? = null
    ) : RequestBody() {
        override fun contentType() = delegate.contentType()
        override fun contentLength() = delegate.contentLength()
        override fun writeTo(sink: BufferedSink) {
            var sent = 0L
            var lastPercent = -1
            val counting = object : ForwardingSink(sink) {
                override fun write(source: Buffer, byteCount: Long) {
                    super.write(source, byteCount)
                    sent += byteCount
                    sentHolder?.set(0, sent)
                    if (totalBytes > 0) {
                        val pct = ((sent * 100) / totalBytes).toInt().coerceIn(0, 100)
                        if (pct != lastPercent) {
                            lastPercent = pct
                            onProgress(pct)
                        }
                    }
                }
            }
            delegate.writeTo(counting.buffer())
            counting.flush()
        }
    }

    private fun uriSize(uri: Uri): Long {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getLong(0) else -1L }
                ?: -1L
        } catch (e: Exception) {
            -1L
        }
    }

    /** Streaming body for a content Uri, with optional upload progress.
     * contentLength stays -1 (chunked) on purpose: a size reported by the
     * provider is only used for the percentage, never declared to OkHttp —
     * a wrong declared length aborts the upload ("unexpected end of
     * stream"). The percentage is approximate when the size is off, but
     * the upload itself can never break because of it. */
    private fun streamBody(uri: Uri, mime: String, onProgress: ((Int) -> Unit)?): RequestBody {
        val size = uriSize(uri)
        val base = object : RequestBody() {
            override fun contentType() = mime.toMediaTypeOrNull()
            override fun contentLength() = -1L
            override fun writeTo(sink: BufferedSink) {
                val stream = contentResolver.openInputStream(uri)
                    ?: throw IOException("Could not open the file")
                stream.use { sink.writeAll(it.source()) }
            }
        }
        return if (onProgress != null && size > 0) {
            CountingRequestBody(base, size, onProgress)
        } else {
            base
        }
    }

    data class JobState(
        val status: String,
        val srt: String?,
        val model: String?,
        val error: String?,
        // TTS jobs only: relative URL of the finished mp3, e.g.
        // "/api/download/<job_id>/audio". Null for transcribe jobs.
        val audioUrl: String? = null,
        // Voiceover jobs only: relative URL of the finished mp4, e.g.
        // "/api/download/<job_id>/video". Null for other jobs.
        val videoUrl: String? = null,
        // Audio-only voiceover jobs (v31+) only: relative URL of the
        // narration .m4a (AAC), e.g. "/api/download/<job_id>/audio-m4a".
        val audioM4aUrl: String? = null,
        // MTV jobs only: the song title YouTube returned. Null otherwise.
        val title: String? = null
    )

    @Throws(IOException::class)
    fun submit(
        videoUri: Uri,
        fileName: String,
        apiKey: String?,
        onUploadProgress: ((Int) -> Unit)? = null
    ): SubmitResult {
        val videoBody = streamBody(videoUri, "video/mp4", onUploadProgress)
        val builder = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("video", fileName, videoBody)
        if (!apiKey.isNullOrBlank()) {
            builder.addFormDataPart("api_key", apiKey.trim())
        }
        val request = Request.Builder()
            .url("$BASE_URL/api/transcribe")
            .post(builder.build())
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail =
                    runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                throw IOException(
                    "Server error ${response.code}" +
                        if (detail.isNotEmpty()) ": $detail" else ""
                )
            }
            val json = runCatching { JSONObject(body) }.getOrNull()
                ?: throw IOException("Server returned an unreadable reply")
            val jobId = json.optString("job_id")
            if (jobId.isNotEmpty()) return SubmitResult.Job(jobId)
            val srt = json.optString("srt")
            if (srt.isNotBlank()) return SubmitResult.Ready(srt, json.optString("model"))
            throw IOException("Server returned no subtitles")
        }
    }

    /**
     * Submits phone-extracted audio for transcription (server v35+):
     * the app uploads only the .m4a audio instead of the whole video
     * (~10x less upload data, much faster on slow connections).
     * Same /api/transcribe endpoint and "video" field; the server
     * detects audio-only input and skips the video probe.
     */
    @Throws(IOException::class)
    fun submitAudioFile(
        audioFile: File,
        fileName: String,
        apiKey: String?,
        onUploadProgress: ((Int) -> Unit)? = null,
        onRetry: ((Int) -> Unit)? = null
    ): SubmitResult {
        // v0.10.1: retry the upload when the connection dies mid-upload
        // ("unexpected end of stream" on a dead-slow connection). Retry
        // is SAFE: sentHolder proves the file never fully left the
        // phone, so the server created no job and no Gemini quota was
        // spent. Once the full file was sent, never retry (the job may
        // exist and only its response was lost).
        val sentHolder = LongArray(1)
        var attempt = 0
        while (true) {
            attempt++
            sentHolder[0] = 0L
            try {
        val audioBody = fileBody(audioFile, "audio/mp4", onUploadProgress, sentHolder)
        val builder = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("video", fileName, audioBody)
        if (!apiKey.isNullOrBlank()) {
            builder.addFormDataPart("api_key", apiKey.trim())
        }
        val request = Request.Builder()
            .url("$BASE_URL/api/transcribe")
            .post(builder.build())
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail =
                    runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                throw IOException(
                    "Server error ${response.code}" +
                        if (detail.isNotEmpty()) ": $detail" else ""
                )
            }
            val json = runCatching { JSONObject(body) }.getOrNull()
                ?: throw IOException("Server returned an unreadable reply")
            val jobId = json.optString("job_id")
            if (jobId.isNotEmpty()) return SubmitResult.Job(jobId)
            val srt = json.optString("srt")
            if (srt.isNotBlank()) return SubmitResult.Ready(srt, json.optString("model"))
            throw IOException("Server returned no subtitles")
        }
            } catch (e: IOException) {
                if (attempt >= 3 || sentHolder[0] >= audioFile.length()) throw e
                onRetry?.invoke(attempt)
                try { Thread.sleep(3000) } catch (_: InterruptedException) { }
            }
        }
    }

    /**
     * Submits a video for the voiceover pipeline (server v16+): the server
     * transcribes/translates it, narrates it in Myanmar, and muxes the
     * narration into the video. Returns the job id to poll; a finished job
     * carries video_url + audio_url + srt.
     */
    @Throws(IOException::class)
    fun submitVoiceover(
        videoUri: Uri,
        fileName: String,
        apiKey: String?,
        voice: String,
        rate: Int,
        pitch: Int,
        mode: String = "manual",
        onUploadProgress: ((Int) -> Unit)? = null
    ): String {
        val videoBody = streamBody(videoUri, "video/mp4", onUploadProgress)
        val builder = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("video", fileName, videoBody)
            .addFormDataPart("voice", voice)
            .addFormDataPart("rate", rate.toString())
            .addFormDataPart("pitch", pitch.toString())
            .addFormDataPart("mode", mode)
        if (!apiKey.isNullOrBlank()) {
            builder.addFormDataPart("api_key", apiKey.trim())
        }
        val request = Request.Builder()
            .url("$BASE_URL/api/voiceover")
            .post(builder.build())
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail =
                    runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                throw IOException(
                    "Server error ${response.code}" +
                        if (detail.isNotEmpty()) ": $detail" else ""
                )
            }
            val json = runCatching { JSONObject(body) }.getOrNull()
                ?: throw IOException("Server returned an unreadable reply")
            val jobId = json.optString("job_id")
            if (jobId.isEmpty()) throw IOException("Server returned no job id")
            return jobId
        }
    }

    /** Streaming body for a local file (the extracted voiceover audio),
     * with optional upload progress. The file length is exact, so the
     * percentage is accurate. */
    private fun fileBody(file: File, mime: String, onProgress: ((Int) -> Unit)?, sentHolder: LongArray? = null): RequestBody {
        val base = object : RequestBody() {
            override fun contentType() = mime.toMediaTypeOrNull()
            override fun contentLength() = file.length()
            override fun writeTo(sink: BufferedSink) {
                file.inputStream().use { sink.writeAll(it.source()) }
            }
        }
        // v0.10.1: always wrap, so sentHolder tracks bytes written
        // even without a progress callback (upload-retry detection).
        return CountingRequestBody(base, file.length(), onProgress ?: {}, sentHolder)
    }

    /**
     * Submits extracted audio for the audio-only voiceover pipeline
     * (server v31+): the server transcribes/translates it and narrates
     * it in Myanmar. Returns the job id to poll; a finished job carries
     * audio_m4a_url (narration, AAC in .m4a) + audio_url (mp3) + srt.
     * The phone muxes the narration onto the original video itself.
     */
    @Throws(IOException::class)
    fun submitVoiceoverAudio(
        audioFile: File,
        fileName: String,
        apiKey: String?,
        voice: String,
        rate: Int,
        pitch: Int,
        mode: String = "manual",
        onUploadProgress: ((Int) -> Unit)? = null,
        onRetry: ((Int) -> Unit)? = null
    ): String {
        // v0.10.1: same mid-upload retry as submitAudioFile (see above).
        val sentHolder = LongArray(1)
        var attempt = 0
        while (true) {
            attempt++
            sentHolder[0] = 0L
            try {
        val audioBody = fileBody(audioFile, "audio/mp4", onUploadProgress, sentHolder)
        val builder = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("audio", fileName, audioBody)
            .addFormDataPart("voice", voice)
            .addFormDataPart("rate", rate.toString())
            .addFormDataPart("pitch", pitch.toString())
            .addFormDataPart("mode", mode)
        if (!apiKey.isNullOrBlank()) {
            builder.addFormDataPart("api_key", apiKey.trim())
        }
        val request = Request.Builder()
            .url("$BASE_URL/api/voiceover-audio")
            .post(builder.build())
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail =
                    runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                throw IOException(
                    "Server error ${response.code}" +
                        if (detail.isNotEmpty()) ": $detail" else ""
                )
            }
            val json = runCatching { JSONObject(body) }.getOrNull()
                ?: throw IOException("Server returned an unreadable reply")
            val jobId = json.optString("job_id")
            if (jobId.isEmpty()) throw IOException("Server returned no job id")
            return jobId
        }
            } catch (e: IOException) {
                if (attempt >= 3 || sentHolder[0] >= audioFile.length()) throw e
                onRetry?.invoke(attempt)
                try { Thread.sleep(3000) } catch (_: InterruptedException) { }
            }
        }
    }

    /**
     * Submits a character image + text for a narrated video (server v21+):
     * the image with a slow zoom, Myanmar narration, and burned subtitles.
     * Returns the job id to poll. A finished job carries video_url,
     * audio_url, and the SRT text.
     */
    @Throws(IOException::class)
    fun submitNarrateImage(
        imageUri: Uri,
        fileName: String,
        text: String,
        apiKey: String?,
        voice: String,
        rate: Int,
        pitch: Int,
        mode: String,
        engine: String = "edge",
        style: String = "natural",
        onUploadProgress: ((Int) -> Unit)? = null
    ): String {
        val imageBody = streamBody(
            imageUri,
            contentResolver.getType(imageUri) ?: "image/jpeg",
            onUploadProgress
        )
        val builder = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("image", fileName, imageBody)
            .addFormDataPart("text", text)
            .addFormDataPart("voice", voice)
            .addFormDataPart("rate", rate.toString())
            .addFormDataPart("pitch", pitch.toString())
            .addFormDataPart("mode", mode)
            .addFormDataPart("engine", engine)
            .addFormDataPart("style", style)
        if (!apiKey.isNullOrBlank()) {
            builder.addFormDataPart("api_key", apiKey.trim())
        }
        val request = Request.Builder()
            .url("$BASE_URL/api/narrate-image")
            .post(builder.build())
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail =
                    runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                throw IOException(
                    "Server error ${response.code}" +
                        if (detail.isNotEmpty()) ": $detail" else ""
                )
            }
            val json = runCatching { JSONObject(body) }.getOrNull()
                ?: throw IOException("Server returned an unreadable reply")
            val jobId = json.optString("job_id")
            if (jobId.isEmpty()) throw IOException("Server returned no job id")
            return jobId
        }
    }

    /**
     * Submits a person photo + song name and/or YouTube link for a
     * 20-second MTV (server v29+): the server fetches the song (the
     * link when given, else the first YouTube search result), takes
     * its loudest 20 seconds, and builds a slow-zoom video from the
     * photo. Returns the job id to poll. A finished job carries
     * video_url, audio_url, and the song title. No Gemini key needed.
     */
    @Throws(IOException::class)
    fun submitMtv(
        imageUri: Uri,
        fileName: String,
        song: String,
        link: String? = null,
        onUploadProgress: ((Int) -> Unit)? = null
    ): String {
        val imageBody = streamBody(
            imageUri,
            contentResolver.getType(imageUri) ?: "image/jpeg",
            onUploadProgress
        )
        val builder = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("image", fileName, imageBody)
            .addFormDataPart("song", song)
        if (!link.isNullOrBlank()) {
            builder.addFormDataPart("link", link.trim())
        }
        val request = Request.Builder()
            .url("$BASE_URL/api/mtv")
            .post(builder.build())
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail =
                    runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                throw IOException(
                    "Server error ${response.code}" +
                        if (detail.isNotEmpty()) ": $detail" else ""
                )
            }
            val json = runCatching { JSONObject(body) }.getOrNull()
                ?: throw IOException("Server returned an unreadable reply")
            val jobId = json.optString("job_id")
            if (jobId.isEmpty()) throw IOException("Server returned no job id")
            return jobId
        }
    }

    /**
     * v0.10.2: CHUNKED upload (server v36+). The audio file is split into
     * 1MB parts; each part uploads with its own retry (3 attempts, growing
     * waits). A broken connection loses one part, not the whole file, and
     * the upload resumes from the failed part. Progress = parts done.
     * Returns the server upload_id; the caller then completes the upload,
     * which starts the job.
     */
    private fun chunkCount(file: File): Int {
        val len = file.length()
        return ((len + CHUNK_SIZE - 1) / CHUNK_SIZE).toInt().coerceAtLeast(1)
    }

    @Throws(IOException::class)
    private fun uploadChunks(
        audioFile: File,
        onChunkProgress: ((done: Int, total: Int) -> Unit)?,
        onChunkRetry: ((part: Int, attempt: Int) -> Unit)?
    ): String {
        if (audioFile.length() <= 0) {
            throw IOException("အသံဖိုင် ဗလာဖြစ်နေတယ် — video မှာ အသံ မပါဘူး။")
        }
        val uploadId = java.util.UUID.randomUUID().toString().replace("-", "")
        val total = chunkCount(audioFile)
        java.io.RandomAccessFile(audioFile, "r").use { raf ->
            val buf = ByteArray(CHUNK_SIZE)
            for (index in 0 until total) {
                val off = index.toLong() * CHUNK_SIZE
                val want = minOf(CHUNK_SIZE.toLong(), audioFile.length() - off).toInt()
                raf.seek(off)
                var read = 0
                while (read < want) {
                    val r = raf.read(buf, read, want - read)
                    if (r < 0) break
                    read += r
                }
                if (read != want) throw IOException("အသံဖိုင် ဖတ်လို့ မရဘူး။")
                uploadOneChunk(uploadId, index, total, buf.copyOf(read), onChunkRetry)
                onChunkProgress?.invoke(index + 1, total)
            }
        }
        return uploadId
    }

    @Throws(IOException::class)
    private fun uploadOneChunk(
        uploadId: String, index: Int, total: Int, part: ByteArray,
        onChunkRetry: ((Int, Int) -> Unit)?
    ) {
        var attempt = 0
        while (true) {
            attempt++
            try {
                val body = MultipartBody.Builder().setType(MultipartBody.FORM)
                    .addFormDataPart("upload_id", uploadId)
                    .addFormDataPart("index", index.toString())
                    .addFormDataPart("total", total.toString())
                    .addFormDataPart("chunk", "part$index",
                        part.toRequestBody("application/octet-stream".toMediaTypeOrNull()))
                    .build()
                val request = Request.Builder()
                    .url("$BASE_URL/api/upload-chunk").post(body).build()
                client.newCall(request).execute().use { response ->
                    val respBody = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        throw IOException("Server error ${response.code}: $respBody")
                    }
                }
                return
            } catch (e: IOException) {
                if (attempt >= 3 || e.message?.startsWith("Server error") == true) throw e
                onChunkRetry?.invoke(index, attempt)
                try { Thread.sleep(2000L * attempt) } catch (_: InterruptedException) { }
            }
        }
    }

    @Throws(IOException::class)
    private fun completeChunkedUpload(
        uploadId: String, total: Int, fileName: String, kind: String,
        apiKey: String?, voice: String, rate: Int, pitch: Int, mode: String
    ): String {
        // The complete call is a small form POST (no file) — retry it so
        // a stall here never wastes the uploaded parts.
        var attempt = 0
        while (true) {
            attempt++
            try {
                val builder = MultipartBody.Builder().setType(MultipartBody.FORM)
                    .addFormDataPart("upload_id", uploadId)
                    .addFormDataPart("total", total.toString())
                    .addFormDataPart("filename", fileName)
                    .addFormDataPart("kind", kind)
                    .addFormDataPart("voice", voice)
                    .addFormDataPart("rate", rate.toString())
                    .addFormDataPart("pitch", pitch.toString())
                    .addFormDataPart("mode", mode)
                if (!apiKey.isNullOrBlank()) builder.addFormDataPart("api_key", apiKey.trim())
                val request = Request.Builder()
                    .url("$BASE_URL/api/upload-complete").post(builder.build()).build()
                client.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    val json = runCatching { JSONObject(body) }.getOrNull()
                    if (!response.isSuccessful) {
                        throw IOException("Server error ${response.code}: " +
                            (json?.optString("error").orEmpty()))
                    }
                    val jobId = json?.optString("job_id").orEmpty()
                    if (jobId.isEmpty()) throw IOException("Server returned no job id")
                    return jobId
                }
            } catch (e: IOException) {
                if (attempt >= 3 || e.message?.startsWith("Server error") == true) throw e
                try { Thread.sleep(3000L * attempt) } catch (_: InterruptedException) { }
            }
        }
    }

    /**
     * Chunked version of submitAudioFile (server v36+): same result, but
     * the audio goes up in 1MB parts with per-part retry, so a flaky
     * connection only ever loses one part. Same callback shapes, so the
     * call sites only change the function name.
     */
    @Throws(IOException::class)
    fun submitAudioFileChunked(
        audioFile: File,
        fileName: String,
        apiKey: String?,
        onUploadProgress: ((Int) -> Unit)? = null,
        onRetry: ((Int) -> Unit)? = null
    ): SubmitResult {
        val total = chunkCount(audioFile)
        val uploadId = uploadChunks(audioFile,
            onChunkProgress = { done, tot ->
                onUploadProgress?.invoke((done * 100 / tot).coerceIn(0, 100))
            },
            onChunkRetry = { _, attempt -> onRetry?.invoke(attempt) })
        val jobId = completeChunkedUpload(uploadId, total, fileName, "transcribe",
            apiKey, "my-MM-NilarNeural", 0, 0, "manual")
        return SubmitResult.Job(jobId)
    }

    /**
     * Chunked version of submitVoiceoverAudio (server v36+): same result
     * (job id to poll), audio in 1MB parts with per-part retry.
     */
    @Throws(IOException::class)
    fun submitVoiceoverAudioChunked(
        audioFile: File,
        fileName: String,
        apiKey: String?,
        voice: String,
        rate: Int,
        pitch: Int,
        mode: String = "manual",
        onUploadProgress: ((Int) -> Unit)? = null,
        onRetry: ((Int) -> Unit)? = null
    ): String {
        val total = chunkCount(audioFile)
        val uploadId = uploadChunks(audioFile,
            onChunkProgress = { done, tot ->
                onUploadProgress?.invoke((done * 100 / tot).coerceIn(0, 100))
            },
            onChunkRetry = { _, attempt -> onRetry?.invoke(attempt) })
        return completeChunkedUpload(uploadId, total, fileName, "voiceover-audio",
            apiKey, voice, rate, pitch, mode)
    }

    /** A resolved video link (server v38+): the direct video URL, an
     * optional separate audio URL (DASH splits, e.g. YouTube), and the
     * title. The video itself never passes through Render — the phone
     * downloads it from the platform CDN, so server bandwidth is
     * untouched. */
    data class ResolvedLink(val url: String, val audioUrl: String?, val title: String?, val titleMm: String? = null)

    @Throws(IOException::class)
    fun resolveLink(link: String, apiKey: String? = null): ResolvedLink {
        val bodyBuilder = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("link", link)
        // v0.10.10: the key lets the server (v43+) translate the
        // resolved title to Myanmar for the auto title band.
        if (!apiKey.isNullOrBlank()) bodyBuilder.addFormDataPart("api_key", apiKey)
        val body = bodyBuilder.build()
        val request = Request.Builder()
            .url("$BASE_URL/api/resolve-link").post(body).build()
        client.newCall(request).execute().use { response ->
            val respBody = response.body?.string().orEmpty()
            val json = runCatching { JSONObject(respBody) }.getOrNull()
            if (!response.isSuccessful) {
                throw IOException(
                    json?.optString("error")?.ifEmpty { null }
                        ?: "Server error ${response.code}"
                )
            }
            val url = json?.optString("url").orEmpty()
            if (url.isEmpty()) throw IOException("ဒီ link က video ရှာလို့ မရဘူး။")
            return ResolvedLink(
                url,
                json?.optString("audio_url").orEmpty().ifEmpty { null },
                json?.optString("title").orEmpty().ifEmpty { null },
                json?.optString("title_mm").orEmpty().ifEmpty { null }
            )
        }
    }

    /**
     * Streams a finished file (video_url / audio_url) to [dest] without
     * holding it in memory — finished videos can be tens of megabytes.
     */
    @Throws(IOException::class)
    fun downloadToFile(url: String, dest: File, resumeNote: Boolean = false, onProgress: ((Int) -> Unit)? = null) {
        // v0.9.9: retry the download — Zin's connection regularly drops
        // mid-stream ("unexpected end of stream", 14 Nov voiceover test).
        // v0.10.4: RESUME — each retry continues from the partial file
        // via HTTP Range instead of restarting from zero (a 124 B/s
        // connection dropped the link-flow audio download after 5 full
        // restarts, 15 Nov 00:02). CDNs (googlevideo/rednotecdn) and
        // Render all honour Range; a server that answers 200 instead of
        // 206 restarts clean, and 416 means the file is already complete.
        val fullUrl = if (url.startsWith("http")) url else BASE_URL + url
        for (attempt in 0 until 5) {
            try {
                val existing = if (dest.exists()) dest.length() else 0L
                val reqBuilder = Request.Builder().url(fullUrl).get()
                if (existing > 0) reqBuilder.header("Range", "bytes=$existing-")
                client.newCall(reqBuilder.build()).execute().use { response ->
                    if (response.code == 416 && existing > 0) return@use
                    if (!response.isSuccessful) {
                        throw IOException("Server error ${response.code} (download)")
                    }
                    val body = response.body ?: throw IOException("Server returned an empty file")
                    // 206 = resuming; any other success with a partial
                    // file means the server ignored Range — overwrite.
                    val resume = response.code == 206 && existing > 0
                    val startAt = if (resume) existing else 0L
                    val total = body.contentLength().let { if (it > 0) it + startAt else -1L }
                    var readTotal = startAt
                    body.byteStream().use { input ->
                        java.io.FileOutputStream(dest, resume).use { output ->
                            val buf = ByteArray(8192)
                            var lastPct = -1
                            while (true) {
                                val n = input.read(buf)
                                if (n < 0) break
                                output.write(buf, 0, n)
                                readTotal += n
                                if (total > 0) {
                                    val pct = ((readTotal * 100) / total).toInt().coerceIn(0, 100)
                                    if (pct != lastPct) {
                                        lastPct = pct
                                        onProgress?.invoke(pct)
                                    }
                                }
                            }
                        }
                    }
                    // v0.10.17: a stream that ends early WITHOUT an
                    // exception (dropped connection, chunked cut-off)
                    // used to return as a successful partial download.
                    // When the server told us the total, a short read
                    // is a failure — throw so the retry / resume logic
                    // engages instead of handing on a broken file.
                    if (total > 0 && readTotal < total) {
                        throw IOException("Download မပြည့်စုံဘူး ($readTotal/$total)")
                    }
                }
                return
            } catch (e: IOException) {
                // Real server errors (404/500) must not be retried as
                // connection drops — surface them at once.
                if (e.message?.startsWith("Server error") == true) throw e
                // v0.10.4: KEEP the partial file so the next attempt resumes.
                if (attempt < 4) Thread.sleep(4000)
            }
        }
        throw IOException(if (resumeNote) "ဒေါင်းလုဒ် လုပ်နေရင်း လိုင်းပြတ်သွားတယ်။ ဒေါင်းထားတာ သိမ်းထားပြီးပြီ — ခလုတ်ကို ထပ်နှိပ်ရင် ကျန်တာ ဆက်ဒေါင်းမယ်။" else "ဒေါင်းလုဒ် လုပ်နေရင်း လိုင်းပြတ်သွားတယ်။ လိုင်းကောင်းတဲ့အချိန် ထပ်စမ်းပါ။")
    }

    @Throws(IOException::class)
    fun poll(jobId: String): JobState {
        val request = Request.Builder()
            .url("$BASE_URL/api/status/$jobId")
            .get()
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail =
                    runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                throw IOException(
                    "Server error ${response.code}" +
                        if (detail.isNotEmpty()) ": $detail" else ""
                )
            }
            val json = JSONObject(body)
            return JobState(
                status = json.optString("status"),
                srt = json.optString("srt").ifEmpty { null },
                model = json.optString("model").ifEmpty { null },
                error = json.optString("error").ifEmpty { null },
                audioUrl = json.optString("audio_url").ifEmpty { null },
                videoUrl = json.optString("video_url").ifEmpty { null },
                audioM4aUrl = json.optString("audio_m4a_url").ifEmpty { null },
                title = json.optString("title").ifEmpty { null }
            )
        }
    }
}
