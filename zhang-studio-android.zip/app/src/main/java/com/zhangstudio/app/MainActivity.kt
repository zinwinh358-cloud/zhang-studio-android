package com.zhangstudio.app

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.util.UnstableApi
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Zhang Studio v0.6.24 — seven screens over the studio photo background:
 * 1. Login: Gemini API Key, entered once and remembered. A "Key သွားယူရန်"
 *    link opens the AI Studio key page so new users can get a key.
 * 2. Menu: all six features, all working now.
 * 3. Work (modes 1-2): pick a video -> Gemini SRT -> burn on the phone CPU
 *    (subtitle mode) or SRT alone (SRT mode). Finished files wait for the
 *    separate download button — nothing is saved to Downloads by itself.
 * 4. TTS (mode 3): type text -> AI voice reads it aloud (2 voices + speed
 *    slider, or AI auto mode: Gemini splits the text by character and
 *    assigns male/female voices per part) -> MP3 + SRT on demand, or a
 *    finished video when a character image is picked (image + narration
 *    + burned subtitles). Style picker: plain edge-tts voice, or
 *    expressive Gemini TTS (natural / spooky ghost-story style).
 *    Server: POST /api/tts, POST /api/gemini-tts, POST /api/narrate-image.
 * 5. Voiceover (mode 4): pick a video -> server transcribes/translates it,
 *    narrates it in Myanmar (manual voice or AI auto split), and muxes the
 *    voice into the video -> finished MP4 + SRT on demand.
 *    Server: POST /api/voiceover (v16+, auto mode v20+).
 * 6. Timing (mode 5): CapCut-style timeline editor — preview on
 *    top, ruler + video strip + music track + SRT track on one time
 *    axis, tools in a bottom toolbar. Shift subtitle timing
 *    (-10s..+10s), trim, cut out a middle section, speed, background
 *    music, title text -> burn on the phone CPU, or save the SRT alone.
 * 7. Prompt-video (mode 6): chat-style "Video generation" screen —
 *    type a prompt in the bottom box -> 3-scene video with Myanmar
 *    narration + subtitles, on demand. Server: POST /api/prompt-video.
 *
 * Server jobs are polled (async), so slow connections never hit a single
 * long request that times out. A sync (v13) transcribe server still works.
 * All errors surface as status text — the app never crashes on bad input.
 * Rotating the phone during a burn cancels the export.
 */
@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {

    private val modeSubtitle = 1
    private val modeSrt = 2
    private val modeTts = 3
    private val modeVoiceover = 4
    private val modeTiming = 5
    private val modePromptVideo = 6
    private val modeMtv = 7
    private var mode = modeSubtitle

    private var videoUri: Uri? = null
    private var voVideoUri: Uri? = null
    private var timingVideoUri: Uri? = null
    private var timingCues: List<SubtitleCue> = emptyList()
    private var timingShiftUs: Long = 0L
    private var timingBusy: Boolean = false
    private var burner: SubtitleBurner? = null
    private var timingBurner: SubtitleBurner? = null
    private var apiKey: String = ""

    // Two real Myanmar edge-tts voices (Nilar = female, Thiha = male).
    // Auto mode (v0.6.3): AI splits the text by character instead.
    private data class VoiceOption(val label: String, val voice: String)
    private val voiceOptions = listOf(
        VoiceOption("မိန်းကလေး အသံ", TtsClient.VOICE_NILAR),
        VoiceOption("ယောက်ျားလေး အသံ", TtsClient.VOICE_THIHA)
    )
    private var selectedVoiceIndex = 0
    private val voiceOptionButtons = mutableListOf<Pair<Button, Int>>()
    private var autoVoice = false
    private val autoVoiceButtons = mutableListOf<Button>()
    // Narration style (v0.6.5): "edge" = plain edge-tts voice; "gemini" =
    // expressive Gemini TTS with a style direction. Gemini and the auto
    // character split exclude each other (Gemini is single-voice).
    private var ttsEngine: String = "edge"
    private var ttsStyle: String = "natural"
    private val styleButtons = mutableListOf<Pair<Button, String>>()
    private var ttsRate: Int = 0

    private val prefs by lazy { getSharedPreferences("zhang_studio", MODE_PRIVATE) }

    private lateinit var loginScreen: View
    private lateinit var menuScreen: View
    private lateinit var workScreen: View
    private lateinit var ttsScreen: View
    private lateinit var voiceoverScreen: View
    private lateinit var timingScreen: View
    private lateinit var promptVideoScreen: View
    private lateinit var mtvScreen: View
    private lateinit var keyField: EditText
    private lateinit var loginStatus: TextView
    private lateinit var workTitle: TextView
    private lateinit var pickVideoButton: Button
    private lateinit var videoLabel: TextView
    private lateinit var makeButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var workDownloadButton: Button
    // v0.9.9: hide-original-subtitles toggle + finished-video preview.
    private lateinit var workCoverCheck: CheckBox
    private lateinit var workPreviewVideo: VideoView
    private var workLastOutput: File? = null
    private var workLastSrt: String? = null
    private lateinit var ttsTextField: EditText
    private lateinit var ttsRateLabel: TextView
    private lateinit var ttsMakeButton: Button
    private lateinit var ttsProgressBar: ProgressBar
    private lateinit var ttsStatusText: TextView
    private lateinit var ttsDownloadButton: Button
    private var ttsLastAudio: ByteArray? = null
    private var ttsLastSrt: String? = null
    // v0.6.20: listen to the generated voice here before downloading.
    private lateinit var ttsPlayerRow: LinearLayout
    private lateinit var ttsPlayButton: Button
    private lateinit var ttsSeekBar: SeekBar
    private lateinit var ttsTimeText: TextView
    private var ttsPlayer: MediaPlayer? = null
    private var ttsPlayerFile: File? = null
    private val ttsPlayerHandler = Handler(Looper.getMainLooper())
    private val ttsPlayerPoller = object : Runnable {
        override fun run() {
            val mp = ttsPlayer ?: return
            if (!::ttsSeekBar.isInitialized) return
            try {
                if (mp.isPlaying) {
                    ttsSeekBar.progress = mp.currentPosition
                    ttsTimeText.text =
                        "${formatClockUs(mp.currentPosition * 1_000L)} / ${formatClockUs(mp.duration * 1_000L)}"
                    ttsPlayerHandler.postDelayed(this, 250L)
                } else {
                    ttsPlayButton.text = "▶"
                }
            } catch (e: Exception) {
            }
        }
    }
    private var ttsImageUri: Uri? = null
    private lateinit var ttsImageButton: Button
    private lateinit var ttsImageLabel: TextView
    private var ttsLastVideo: File? = null
    private var ttsLastVideoUrl: String? = null
    // v0.7.4: MTV screen — person photo + song name -> 20s MTV.
    private var mtvImageUri: Uri? = null
    private lateinit var mtvImageButton: Button
    private lateinit var mtvImageLabel: TextView
    private lateinit var mtvSongField: EditText
    private lateinit var mtvLinkField: EditText
    private lateinit var mtvMakeButton: Button
    private lateinit var mtvProgressBar: ProgressBar
    private lateinit var mtvStatusText: TextView
    private lateinit var mtvDownloadButton: Button
    private var mtvLastVideo: File? = null
    private var mtvLastVideoUrl: String? = null
    private lateinit var voPickButton: Button
    private lateinit var voVideoLabel: TextView
    private lateinit var voMakeButton: Button
    private lateinit var voProgressBar: ProgressBar
    private lateinit var voStatusText: TextView
    private lateinit var voDownloadButton: Button
    private lateinit var voSrtDownloadButton: Button
    private lateinit var voScrollView: ScrollView
    private var voLastTmp: File? = null
    private var voLastVideoUrl: String? = null
    private var voLastSrt: String? = null
    // v0.6.8: preview the finished voiceover video + SRT before downloading.
    // v0.6.21: the SRT text shows full-height on the page (no nested
    // scroll box), and Video / SRT download as separate buttons.
    private lateinit var voPreviewVideo: VideoView
    private lateinit var voSrtText: TextView
    private lateinit var timingPickVideoButton: Button
    private lateinit var timingVideoLabel: TextView
    private lateinit var timingPickSrtButton: Button
    private lateinit var timingSrtLabel: TextView
    // v0.7.8: manual captions — type text instead of loading an SRT.
    private lateinit var timingManualTextField: EditText
    private lateinit var timingAddCueButton: Button
    // v0.7.9: VN-style cue timing — duration slider + text editing.
    private lateinit var timingEditCueButton: Button
    private lateinit var timingCueShorterButton: Button
    private lateinit var timingCueLongerButton: Button
    private lateinit var timingCueDurationSlider: SeekBar
    private lateinit var timingCueDurationLabel: TextView
    private lateinit var timingSpeedBadge: TextView
    // v0.9.0: subtitle sheet style — color + size for new cues, and
    // applied to the selected cue when a template/swatch is tapped.
    private var timingNewCueColor: Int = Color.WHITE
    private var timingNewCueSizeScale: Float = 1f
    // v0.9.2: typing style bar (fixed above the toolbar, visible
    // above the keyboard) + separate video/music volumes.
    private lateinit var timingTypingBar: LinearLayout
    private val timingTypingSizePills = mutableListOf<Button>()
    private val timingTypingSwatches = mutableListOf<View>()
    private lateinit var timingSubtitlePanel: LinearLayout
    private var timingVideoVolume: Float = 1f
    private var timingMusicVolume: Float = 1f
    // v0.9.3: VN text-box drag — the video picture rect inside the
    // preview frame, the dragged position for newly typed cues, the
    // title box position, and the drag/center-guide state.
    private var timingPicLeft = 0
    private var timingPicTop = 0
    private var timingPicW = 0
    private var timingPicH = 0
    private var timingNewCueXFrac = 0.5f
    private var timingNewCueYFrac = 0.92f
    private var timingTitleXFrac = 0.5f
    private var timingTitleTopFrac = 0.08f
    private var timingTextDragging = false
    private var timingMediaPlayer: MediaPlayer? = null
    // v0.9.8: background-music preview player, kept in sync
    // with the VideoView playhead by the preview poller.
    private var timingMusicPlayer: MediaPlayer? = null
    private var timingMusicPlayerUri: Uri? = null
    private var timingMusicPlayerReady: Boolean = false
    private val timingSwatchColors = listOf(
        Color.WHITE,
        Color.rgb(255, 214, 0),
        Color.rgb(255, 82, 82),
        Color.rgb(105, 240, 174),
        Color.rgb(64, 196, 255),
        Color.rgb(30, 107, 74)
    )
    private var timingManualCueDurationUs: Long = 3_000_000L
    private lateinit var timingShiftLabel: TextView
    private lateinit var timingInfoText: TextView
    // v0.6.13 editor slice 1: preview + live cue text + trim.
    // v0.6.14: title text shown over the preview and burned at the top.
    // v0.6.18: timeline editor — ruler + video strip + music track
    // share one time axis; tools live in a bottom toolbar.
    private lateinit var timingPreviewFrame: FrameLayout
    private lateinit var timingPreviewPlaceholder: LinearLayout
    private lateinit var timingPreviewVideo: VideoView
    private lateinit var timingTopTextPreview: TextView
    private lateinit var timingCueText: TextView
    // v0.9.3: magenta center guides shown while dragging text.
    private lateinit var timingGuideV: View
    private lateinit var timingGuideH: View
    // v0.8.0: VN-style scrollable timeline.
    private lateinit var timingTimelineScroll: HorizontalScrollView
    private var timingTrackContentWidthPx: Int = 0
    private lateinit var timingSrtTrack: SrtTrackView
    private lateinit var timingRuler: TimeRulerView
    private lateinit var timingVideoStrip: VideoStripView
    private lateinit var timingMusicTrack: MusicTrackView
    private lateinit var timingPlayButton: Button
    private lateinit var timingTimeText: TextView
    private lateinit var timingChangeVideoButton: Button
    private val timingToolPanels = mutableListOf<View>()
    private val timingToolButtons = mutableListOf<View>()
    private var timingExportPanel: View? = null
    private lateinit var timingTrimStartField: EditText
    private lateinit var timingTrimEndField: EditText
    private lateinit var timingTopTextField: EditText
    // v0.6.16 editor slice 2: speed, background music. (The typed
    // cut-out-middle boxes were removed in v0.7.7 — middle cuts are
    // done by tapping a segment and splitting/deleting it.)
    private var timingSpeed: Float = 1f
    private val timingSpeedButtons = mutableListOf<Pair<Button, Float>>()
    private lateinit var timingSpeedSlider: SeekBar
    private lateinit var timingSpeedLabel: TextView
    private var timingMusicUri: Uri? = null
    private lateinit var timingMusicLabel: TextView
    private lateinit var timingMusicClearButton: Button
    private lateinit var timingDeleteVideoButton: Button
    private lateinit var timingDeleteSrtButton: Button
    private lateinit var timingMuteCheck: CheckBox
    private var timingVideoDurationMs: Long = 0L
    private var timingVideoBaseLabel: String = ""
    // v0.7.0: VN-style segment models (source-timeline microseconds).
    private var timingVideoSegments: MutableList<Pair<Long, Long>> = mutableListOf()
    private var timingMusicClips: MutableList<MusicClip> = mutableListOf()
    // v0.9.4: photo overlays (stickers) on their own timeline row.
    private var timingOverlayClips: MutableList<OverlayClip> = mutableListOf()
    private lateinit var timingOverlayTrack: OverlayTrackView
    private lateinit var timingOverlayImage: ImageView
    // Decoded overlay bitmaps (sampled, capped) + which clip is shown.
    private val timingOverlayBitmaps = LinkedHashMap<Uri, Bitmap>()
    private val timingOverlayLoading = mutableSetOf<Uri>()
    private var timingOverlayShownUri: Uri? = null
    private var timingOverlayAspect: Float = 1f
    private var timingOverlayDragging = false
    private var timingMusicDurationMs: Long = 0L
    private var timingMusicName: String = ""
    // Selection: 0 = none, 1 = video, 2 = music, 3 = SRT, 4 = overlay.
    private var selectedTrack: Int = 0
    private var selectedIndex: Int = -1
    private lateinit var timingSelectionBar: LinearLayout
    private lateinit var timingSelectionScroll: HorizontalScrollView
    private lateinit var timingSelectionLabel: TextView
    private lateinit var timingSplitButton: Button
    private lateinit var timingVolumeBarButton: Button
    private lateinit var timingDeleteSegmentButton: Button
    private lateinit var timingUndoBarButton: Button
    private lateinit var timingRedoBarButton: Button
    // v0.9.4: Volume panel (CapCut-style 0–1000 slider + done).
    private lateinit var timingVolumePanel: LinearLayout
    private lateinit var timingVolumeSlider: SeekBar
    private lateinit var timingVolumeValueLabel: TextView
    private var timingVolumeTarget: Int = 1 // 1 = video, 2 = music
    private var timingVolumeClipIndex: Int = -1 // -1 = whole track
    private lateinit var timingVideoVolumeSlider: SeekBar
    private lateinit var timingVideoVolumeLabel: TextView
    private lateinit var timingMusicVolumeSlider: SeekBar
    private lateinit var timingMusicVolumeLabel: TextView
    private lateinit var timingRailMuteButton: TextView
    private lateinit var timingTitlePanel: LinearLayout
    // v0.9.4: white border on the preview text box while editing.
    private var timingCueTextBordered: Boolean = false
    private data class EditorSnapshot(
        val videoSegments: List<Pair<Long, Long>>,
        val musicClips: List<MusicClip>,
        val cues: List<SubtitleCue>,
        val overlayClips: List<OverlayClip>
    )
    // v0.8.1: full undo/redo stacks (Gemini zip parity) — up to 20 steps.
    private val timingUndoStack = ArrayDeque<EditorSnapshot>()
    private val timingRedoStack = ArrayDeque<EditorSnapshot>()
    private val timingPreviewHandler = Handler(Looper.getMainLooper())
    private val timingPreviewPoller = object : Runnable {
        override fun run() {
            if (!::timingPreviewVideo.isInitialized) return
            if (::timingScreen.isInitialized &&
                timingScreen.visibility == View.VISIBLE
            ) {
                val posMs = timingPreviewVideo.currentPosition.toLong()
                val posUs = posMs * 1_000L
                if (::timingCoverPreview.isInitialized) {
                    val showCover = timingCoverImageUri != null &&
                        timingCoverDurationUs > 0L && posUs < timingCoverDurationUs
                    timingCoverPreview.visibility =
                        if (showCover) View.VISIBLE else View.GONE
                }
                val cues = SrtParser.shifted(timingCues, timingShiftUs)
                val active = cues.firstOrNull { posUs in it.startUs until it.endUs }
                // v0.9.2: text being typed shows live on the video
                // with the chosen color/size, ahead of stored cues.
                val typed = if (::timingManualTextField.isInitialized &&
                    timingManualTextField.hasFocus()
                ) {
                    timingManualTextField.text.toString().trim()
                } else {
                    ""
                }
                if (typed.isNotEmpty()) {
                    timingCueText.text = typed
                    timingCueText.setTextColor(timingNewCueColor)
                    timingCueText.textSize = 16f * timingNewCueSizeScale
                    placeCueText(timingNewCueXFrac, timingNewCueYFrac)
                    refreshCueTextBorder(true)
                } else {
                    timingCueText.text = active?.text.orEmpty()
                    // v0.9.0: the live line shows the cue's own color/size.
                    timingCueText.setTextColor(active?.color ?: Color.WHITE)
                    timingCueText.textSize = 16f * (active?.sizeScale ?: 1f)
                    placeCueText(active?.xFrac ?: 0.5f, active?.yFrac ?: 0.92f)
                    // v0.9.4: white box border while the shown cue is
                    // the selected one (CapCut text-box style).
                    val activeIndex = if (active == null) -1
                    else cues.indexOf(active)
                    refreshCueTextBorder(
                        active != null && selectedTrack == 3 &&
                            selectedIndex == activeIndex
                    )
                }
                // v0.9.4: the sticker/overlay photo on the preview.
                refreshTimingOverlay()
                if (::timingSrtTrack.isInitialized) {
                    timingSrtTrack.setPosition(posMs)
                }
                if (::timingVideoStrip.isInitialized) {
                    timingVideoStrip.setPosition(posMs)
                }
                if (::timingMusicTrack.isInitialized) {
                    timingMusicTrack.setPosition(posMs)
                }
                if (::timingOverlayTrack.isInitialized) {
                    timingOverlayTrack.setPosition(posMs)
                }
                if (::timingTimeText.isInitialized) {
                    // v0.9.4: two-line time (demo style): current on
                    // line 1, total with centiseconds on line 2.
                    timingTimeText.text =
                        "${formatClockUs(posUs)} /\n${formatClockUsCs(timingVideoDurationMs * 1_000L)}"
                }
                if (::timingPlayButton.isInitialized) {
                    timingPlayButton.text =
                        if (timingPreviewVideo.isPlaying) "⏸" else "▶"
                }
                // v0.9.8: keep the added song playing in step
                // with the preview (silent in gaps / paused).
                syncTimingMusicPreview()
                // v0.7.0: keep the Split button's enabled state in step
                // with the moving playhead.
                if (::timingSelectionBar.isInitialized) refreshSelectionBar()
                // v0.8.0: while playing, keep the playhead centered
                // in the scrolling timeline, VN-style.
                if (timingPreviewVideo.isPlaying &&
                    ::timingTimelineScroll.isInitialized &&
                    timingVideoDurationMs > 0
                ) {
                    val scroll = timingTimelineScroll
                    val contentW = timingTrackContentWidthPx
                    if (contentW > scroll.width && scroll.width > 0) {
                        val px = (posMs.toFloat() / timingVideoDurationMs * contentW).toInt()
                        scroll.scrollTo(
                            (px - scroll.width / 2).coerceIn(0, contentW - scroll.width), 0
                        )
                    }
                }
                timingPreviewHandler.postDelayed(this, 250L)
            }
        }
    }
    private lateinit var timingBurnButton: Button
    private lateinit var timingSaveSrtButton: Button
    // v0.7.8: save the playhead frame as a cover image.
    private lateinit var timingCoverButton: Button
    private var timingCoverImageUri: Uri? = null
    private var timingCoverDurationUs: Long = 2_000_000L
    private lateinit var timingCoverPreview: ImageView
    private lateinit var timingCoverDurationLabel: TextView
    private lateinit var timingProgressBar: ProgressBar
    private lateinit var timingStatusText: TextView
    private lateinit var timingDownloadButton: Button
    private var timingLastOutput: File? = null
    private lateinit var pvTextField: EditText
    private lateinit var pvHintText: TextView
    private lateinit var pvInputCard: LinearLayout
    private lateinit var pvPickImageButton: Button
    private lateinit var pvClearImagesButton: Button
    private lateinit var pvImageLabel: TextView
    private lateinit var pvImageRow: LinearLayout
    private val pvImageUris = mutableListOf<Uri>()
    private lateinit var pvMakeButton: Button
    private lateinit var pvProgressBar: ProgressBar
    private lateinit var pvStatusText: TextView
    private lateinit var pvDownloadButton: Button
    private var pvLastTmp: File? = null
    private var pvLastVideoUrl: String? = null
    private var pvLastSrt: String? = null

    private val pickVideoLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                videoUri = uri
                videoLabel.text = "Video: ${uri.lastPathSegment ?: uri}"
                updateMakeEnabled()
            }
        }

    private val pickVoVideoLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                voVideoUri = uri
                voVideoLabel.text = "Video: ${uri.lastPathSegment ?: uri}"
                voMakeButton.isEnabled = true
            }
        }

    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                ttsImageUri = uri
                ttsImageLabel.text = "ပုံ: ${uri.lastPathSegment ?: uri}"
            }
        }

    private val pickMtvImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                mtvImageUri = uri
                mtvImageLabel.text = "ပုံ: ${uri.lastPathSegment ?: uri}"
            }
        }

    private val pickPvImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null && pvImageUris.size < 3) {
                pvImageUris.add(uri)
                updatePvImageLabel()
            }
        }

    private fun updatePvImageLabel() {
        val n = pvImageUris.size
        pvImageLabel.text = if (n == 0) {
            "ပုံ မထည့်ရသေးဘူး — ပုံမထည့်ရင် AI က ပုံထုတ်ပေးမယ်"
        } else {
            "ပုံ $n ပုံ ထည့်ပြီးပြီ" + if (n < 3) " — နောက် ပုံ ထပ်ထည့်လို့ရတယ်" else ""
        }
        pvPickImageButton.isEnabled = n < 3
        pvClearImagesButton.visibility = if (n == 0) View.GONE else View.VISIBLE
        // v0.6.10: show the picked images as thumbnails together with the
        // text, so each added image is visible (not just a count).
        // v0.6.12: each thumbnail carries a small X — tapping it removes
        // just that image.
        pvImageRow.removeAllViews()
        for ((index, uri) in pvImageUris.withIndex()) {
            val thumb = ImageView(this).apply {
                setImageURI(uri)
                scaleType = ImageView.ScaleType.CENTER_CROP
                layoutParams = FrameLayout.LayoutParams(dp(72), dp(72))
            }
            val cross = TextView(this).apply {
                text = "✕"
                textSize = 13f
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.argb(160, 0, 0, 0))
                setPadding(dp(5), dp(1), dp(5), dp(1))
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { gravity = Gravity.TOP or Gravity.END }
                setOnClickListener {
                    pvImageUris.removeAt(index)
                    updatePvImageLabel()
                }
            }
            val frame = FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(72), dp(72)).apply {
                    marginEnd = dp(8)
                }
                addView(thumb)
                addView(cross)
            }
            pvImageRow.addView(frame)
        }
        pvImageRow.visibility = if (n == 0) View.GONE else View.VISIBLE
    }

    private val pickTimingVideoLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                timingVideoUri = uri
                timingVideoBaseLabel = "Video: ${uri.lastPathSegment ?: uri}"
                timingVideoLabel.text = timingVideoBaseLabel
                timingPreviewVideo.setVideoURI(uri)
                timingPreviewVideo.setOnPreparedListener { mp ->
                    timingMediaPlayer = mp
                    applyTimingPreviewVolume()
                    timingVideoDurationMs = mp.duration.toLong()
                    val secs = mp.duration / 1000
                    timingVideoLabel.text = "$timingVideoBaseLabel — ${secs}s"
                    timingSrtTrack.setDuration(mp.duration.toLong())
                    timingRuler.setDuration(mp.duration.toLong())
                    timingMusicTrack.setDuration(mp.duration.toLong())
                    if (::timingOverlayTrack.isInitialized) {
                        timingOverlayTrack.setDuration(mp.duration.toLong())
                    }
                    timingVideoStrip.setVideo(uri, mp.duration.toLong())
                    updateTimelineWidths()
                    // v0.7.0: one full segment; extend a pristine music
                    // clip to the new video length.
                    timingVideoSegments = mutableListOf(
                        0L to mp.duration.toLong() * 1_000L
                    )
                    clearTrimCutFields()
                    if (timingMusicClips.size == 1 &&
                        timingMusicClips[0].startUs == 0L &&
                        timingMusicClips[0].offsetUs == 0L
                    ) {
                        timingMusicClips[0] = timingMusicClips[0].copy(
                            endUs = mp.duration.toLong() * 1_000L
                        )
                    }
                    refreshEditorModels()
                    setSelection(0, -1)
                    timingPreviewFrame.post {
                        fitTimingPreview(mp.videoWidth, mp.videoHeight)
                    }
                    timingPreviewHandler.removeCallbacks(timingPreviewPoller)
                    timingPreviewHandler.post(timingPreviewPoller)
                }
                timingPreviewPlaceholder.visibility = View.GONE
                timingDeleteVideoButton.visibility = View.VISIBLE
                updateTimingEnabled()
            }
        }

    private val pickMusicLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                timingMusicUri = uri
                val name = "${uri.lastPathSegment ?: uri}"
                timingMusicName = name
                timingMusicLabel.text = "Music: $name"
                timingMusicClearButton.visibility = View.VISIBLE
                timingMusicDurationMs = musicDurationMs(uri)
                // v0.7.0: one clip covering the video (or the song, when
                // no video is picked yet — extended on video prepared).
                val endUs = if (timingVideoDurationMs > 0) {
                    timingVideoDurationMs * 1_000L
                } else {
                    timingMusicDurationMs * 1_000L
                }
                timingMusicClips = mutableListOf(MusicClip(0L, endUs, 0L))
                refreshEditorModels()
                setSelection(0, -1)
            }
        }

    private val pickSrtLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri == null) return@registerForActivityResult
            try {
                val text = contentResolver.openInputStream(uri)?.use {
                    it.readBytes().toString(Charsets.UTF_8)
                } ?: ""
                val cues = SrtParser.parse(text)
                if (cues.isEmpty()) {
                    timingCues = emptyList()
                    timingSrtLabel.text = "No subtitles found in the SRT file."
                } else {
                    timingCues = cues
                    timingSrtLabel.text = "SRT: ${cues.size} subtitles"
                }
            } catch (e: Exception) {
                timingCues = emptyList()
                timingSrtLabel.text = "Could not read the SRT file."
            }
            timingDeleteSrtButton.visibility =
                if (timingCues.isNotEmpty()) View.VISIBLE else View.GONE
            updateTimingInfo()
            updateTimingEnabled()
            setSelection(0, -1)
        }

    // v0.9.4: photo picker for the sticker/overlay row.
    private val pickOverlayLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) onOverlayPhotoPicked(uri)
        }

    // v0.9.7: picker for the intro cover image.
    private val pickCoverLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) onCoverImagePicked(uri)
        }

    private val burnCallback = object : SubtitleBurner.Callback {
        override fun onProgress(percent: Int) {
            progressBar.progress = percent
            setStatus("စာတန်းထည့်နေတယ်… $percent%")
        }

        override fun onCompleted(outputPath: String) {
            // v0.6.2: no auto-download — the finished file waits until
            // the user taps the separate download button.
            workLastOutput = File(outputPath)
            workLastSrt = null
            runOnUiThread {
                setBusy(false)
                progressBar.progress = 100
                workDownloadButton.text = "Video ဒေါင်းလုဒ်လုပ်ရန်"
                workDownloadButton.visibility = View.VISIBLE
                // v0.9.9: preview the finished video here first.
                if (::workPreviewVideo.isInitialized) {
                    workPreviewVideo.setVideoPath(outputPath)
                    workPreviewVideo.visibility = View.VISIBLE
                    workPreviewVideo.setOnPreparedListener { mp -> mp.seekTo(100) }
                }
                setStatus("ပြီးပြီ — Video ကို ဒီမှာ ကြည့်ပြီး၊ ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။")
            }
        }

        override fun onError(message: String) {
            setBusy(false)
            setStatus("အမှား: $message")
        }
    }

    private val timingBurnCallback = object : SubtitleBurner.Callback {
        override fun onProgress(percent: Int) {
            timingProgressBar.progress = percent
            timingStatusText.text = "Burning subtitles… $percent%"
        }

        override fun onCompleted(outputPath: String) {
            // v0.6.2: no auto-download — the finished file waits until
            // the user taps the separate download button.
            timingLastOutput = File(outputPath)
            runOnUiThread {
                timingBusy = false
                updateTimingEnabled()
                timingProgressBar.progress = 100
                timingDownloadButton.visibility = View.VISIBLE
                timingStatusText.text = "Done — tap the button below to download."
            }
        }

        override fun onError(message: String) {
            timingBusy = false
            updateTimingEnabled()
            timingStatusText.text = "Error: $message"
        }
    }

    private var loginBgPlayer: MediaPlayer? = null
    private var loginBgView: TextureView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        apiKey = prefs.getString("gemini_api_key", "").orEmpty()

        val root = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.rgb(17, 20, 24))
        }

        // Deep green-charcoal gradient background (approved design).
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.rgb(12, 32, 26), Color.rgb(6, 13, 10))
        )

        // Looping muted video behind the login (API key) screen only.
        loginBgView = TextureView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(
                    surfaceTexture: SurfaceTexture, width: Int, height: Int
                ) {
                    initLoginBgPlayer(Surface(surfaceTexture))
                }

                override fun onSurfaceTextureSizeChanged(
                    surfaceTexture: SurfaceTexture, width: Int, height: Int
                ) {
                    loginBgPlayer?.let {
                        adjustLoginBgTransform(it.videoWidth, it.videoHeight)
                    }
                }

                override fun onSurfaceTextureDestroyed(surfaceTexture: SurfaceTexture): Boolean {
                    try {
                        loginBgPlayer?.release()
                    } catch (e: Exception) {
                    }
                    loginBgPlayer = null
                    return true
                }

                override fun onSurfaceTextureUpdated(surfaceTexture: SurfaceTexture) {}
            }
        }
        root.addView(loginBgView)

        loginScreen = buildLoginScreen()
        menuScreen = buildMenuScreen()
        workScreen = buildWorkScreen()
        ttsScreen = buildTtsScreen()
        voiceoverScreen = buildVoiceoverScreen()
        timingScreen = buildTimingScreen()
        promptVideoScreen = buildPromptVideoScreen()
        mtvScreen = buildMtvScreen()
        root.addView(loginScreen)
        root.addView(menuScreen)
        root.addView(workScreen)
        root.addView(ttsScreen)
        root.addView(voiceoverScreen)
        root.addView(timingScreen)
        root.addView(promptVideoScreen)
        root.addView(mtvScreen)
        setContentView(root)

        if (apiKey.isBlank()) showScreen(loginScreen) else showScreen(menuScreen)
    }

    override fun onDestroy() {
        burner?.cancel()
        burner = null
        timingBurner?.cancel()
        timingBurner = null
        try {
            loginBgPlayer?.release()
        } catch (e: Exception) {
        }
        loginBgPlayer = null
        stopTtsPlayer()
        releaseTimingMusicPlayer()
        super.onDestroy()
    }

    override fun onPause() {
        try {
            loginBgPlayer?.let { if (it.isPlaying) it.pause() }
        } catch (e: Exception) {
        }
        pauseTimingMusicPreview()
        try {
            if (::workPreviewVideo.isInitialized && workPreviewVideo.isPlaying) {
                workPreviewVideo.pause()
            }
        } catch (e: Exception) {
        }
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (loginScreen.visibility == View.VISIBLE) {
            try {
                loginBgPlayer?.let { if (!it.isPlaying) it.start() }
            } catch (e: Exception) {
            }
        }
    }

    // ---------- screens ----------

    private fun showScreen(screen: View) {
        // Stop the voiceover preview when leaving that screen, so its
        // audio never keeps playing over another screen.
        // v0.9.9: stop the work-screen preview when leaving it.
        if (screen !== workScreen && ::workPreviewVideo.isInitialized) {
            workPreviewVideo.stopPlayback()
        }
        if (screen !== voiceoverScreen && ::voPreviewVideo.isInitialized) {
            voPreviewVideo.stopPlayback()
        }
        // Pause the TTS listen-here player when leaving that screen.
        if (screen !== ttsScreen) {
            pauseTtsPlayer()
        }
        // Same for the timing-screen preview + its cue poller.
        if (screen !== timingScreen && ::timingPreviewVideo.isInitialized) {
            timingPreviewVideo.stopPlayback()
            pauseTimingMusicPreview()
            timingPreviewHandler.removeCallbacks(timingPreviewPoller)
        }
        // Returning to the editor restarts the playhead poller.
        if (screen === timingScreen && ::timingPreviewVideo.isInitialized &&
            timingVideoUri != null
        ) {
            timingPreviewHandler.removeCallbacks(timingPreviewPoller)
            timingPreviewHandler.post(timingPreviewPoller)
        }
        loginScreen.visibility = if (screen === loginScreen) View.VISIBLE else View.GONE
        menuScreen.visibility = if (screen === menuScreen) View.VISIBLE else View.GONE
        workScreen.visibility = if (screen === workScreen) View.VISIBLE else View.GONE
        ttsScreen.visibility = if (screen === ttsScreen) View.VISIBLE else View.GONE
        voiceoverScreen.visibility =
            if (screen === voiceoverScreen) View.VISIBLE else View.GONE
        timingScreen.visibility = if (screen === timingScreen) View.VISIBLE else View.GONE
        promptVideoScreen.visibility =
            if (screen === promptVideoScreen) View.VISIBLE else View.GONE
        mtvScreen.visibility = if (screen === mtvScreen) View.VISIBLE else View.GONE
        // Login-only video background: visible + playing on the login
        // screen, hidden + paused everywhere else.
        val bgVisible = screen === loginScreen
        loginBgView?.visibility = if (bgVisible) View.VISIBLE else View.GONE
        try {
            if (bgVisible) {
                loginBgPlayer?.let { if (!it.isPlaying) it.start() }
            } else {
                loginBgPlayer?.let { if (it.isPlaying) it.pause() }
            }
        } catch (e: Exception) {
            // Player not prepared yet; the prepared listener starts it.
        }
    }

    private fun screenColumn(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val pad = dp(24)
        setPadding(pad, dp(48), pad, pad)
        layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    private fun wrapScroll(column: LinearLayout): ScrollView = ScrollView(this).apply {
        layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        addView(column)
    }

    // ---------- login video background ----------

    private fun initLoginBgPlayer(surface: Surface) {
        try {
            val fd = assets.openFd("login_bg.mp4")
            loginBgPlayer = MediaPlayer().apply {
                setDataSource(fd.fileDescriptor, fd.startOffset, fd.length)
                setSurface(surface)
                isLooping = true
                setVolume(0f, 0f)
                setOnVideoSizeChangedListener { _, w, h -> adjustLoginBgTransform(w, h) }
                setOnPreparedListener {
                    if (loginScreen.visibility == View.VISIBLE) {
                        try {
                            start()
                        } catch (e: Exception) {
                        }
                    }
                }
                prepareAsync()
            }
            fd.close()
        } catch (e: Exception) {
            loginBgView?.visibility = View.GONE
        }
    }

    private fun adjustLoginBgTransform(videoW: Int, videoH: Int) {
        val view = loginBgView ?: return
        if (videoW == 0 || videoH == 0 || view.width == 0 || view.height == 0) return
        val viewW = view.width.toFloat()
        val viewH = view.height.toFloat()
        val scaleX = viewW / videoW
        val scaleY = viewH / videoH
        val scale = maxOf(scaleX, scaleY)
        val matrix = Matrix()
        matrix.setScale(scale / scaleX, scale / scaleY, viewW / 2f, viewH / 2f)
        view.setTransform(matrix)
    }

    private fun buildLoginScreen(): View {
        val col = screenColumn()
        col.addView(titleText("ZHANG Studio", 32f))
        col.addView(titleText("မှ ကြိုဆိုပါတယ်", 26f))

        val banner = TextView(this).apply {
            text = "Gemini API Key ထည့်ပြီး\nစတင် အသုံးပြုနိုင်ပါပြီ"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = pillBg(Color.rgb(30, 107, 74), Color.rgb(76, 175, 125), 2)
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        col.addView(banner, rowParams(dp(40)))

        keyField = EditText(this).apply {
            hint = "API Key"
            textSize = 18f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            setSingleLine(true)
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(22), dp(14), dp(22), dp(14))
            if (apiKey.isNotBlank()) setText(apiKey)
        }
        col.addView(keyField, rowParams(dp(24)))

        val loginButton = pillButton("Login", Color.rgb(35, 35, 35), Color.WHITE, null)
        loginButton.setOnClickListener { onLoginClicked() }
        col.addView(loginButton, rowParams(dp(16)))

        loginStatus = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.rgb(255, 213, 74))
            gravity = Gravity.CENTER
        }
        col.addView(loginStatus, rowParams(dp(12)))

        // "Go get a Key" link: new users who don't know what a key is can
        // tap it and land straight on the free AI Studio key page.
        val keyLink = TextView(this).apply {
            text = "🔑 Key သွားယူရန်"
            textSize = 17f
            setTextColor(Color.rgb(255, 213, 74))
            gravity = Gravity.CENTER
            paint.isUnderlineText = true
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        keyLink.setOnClickListener {
            try {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://aistudio.google.com/apikey")
                    )
                )
            } catch (e: Exception) {
                loginStatus.text = "Link ဖွင့်လို့ မရဘူး။"
            }
        }
        col.addView(keyLink, rowParams(dp(8)))

        col.addView(hintText("Key ကို aistudio.google.com/apikey မှာ အခမဲ့ ရယူနိုင်ပါတယ်"),
            rowParams(dp(12)))
        // Dim the looping video background so the form stays readable.
        return wrapScroll(col).apply {
            setBackgroundColor(Color.argb(90, 0, 0, 0))
        }
    }

    private fun buildMenuScreen(): View {
        val col = screenColumn()
        col.addView(titleText("ZHANG Studio", 30f))
        col.addView(titleText("လုပ်ဆောင်ချက်များ ရွေးချယ်ပါ", 20f))

        val items = listOf(
            Triple("\uD83D\uDCC4", "SRT သီးသန့်ထုတ်ရန်", "Video ကနေ SRT ဖိုင်ပဲ ထုတ်မယ်") to modeSrt,
            Triple("\uD83C\uDFAC", "Video ကို မြန်မာစာတန်းထိုးပေးရန်", "စာတန်း ထိုး + Video တွဲ ထုတ်မယ်") to modeSubtitle,
            Triple("\uD83D\uDD0A", "ရေးထားသောစာများကို AI အသံဖြင့် ဖတ်ပြရန်", "စာသား → မြန်မာ AI အသံ") to modeTts,
            Triple("\uD83C\uDF99\uFE0F", "Video များကို မြန်မာအသံဖြင့် ပြောပြပေးရန်", "Video အသံ → မြန်မာ အသံပြောင်း") to modeVoiceover,
            Triple("\uD83C\uDF9E\uFE0F", "SRT နှင့် Video တွဲရန် နှင့် စာသား အတိုအရှည် စိတ်ကြိုက်ချိန်ရန်", "အချိန် ညှိ · တည်း · Export") to modeTiming
        )
        for ((card, targetMode) in items) {
            val (emoji, label, sub) = card
            col.addView(menuCard(emoji, label, sub) {
                when (targetMode) {
                    modeSrt, modeSubtitle -> openWork(targetMode)
                    modeTts -> showScreen(ttsScreen)
                    modeVoiceover -> showScreen(voiceoverScreen)
                    modeTiming -> showScreen(timingScreen)
                }
            }, rowParams(dp(14)))
        }

        val changeKey = TextView(this).apply {
            text = "API Key ပြောင်းရန်"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        changeKey.setOnClickListener {
            keyField.setText(apiKey)
            loginStatus.text = ""
            showScreen(loginScreen)
        }
        col.addView(changeKey, rowParams(dp(18)))
        return wrapScroll(col)
    }

    private fun buildWorkScreen(): View {
        val col = screenColumn()
        workTitle = titleText("", 22f)
        col.addView(workTitle)

        pickVideoButton = pillButton("Video ရွေးပါ", Color.WHITE, Color.BLACK, null)
        pickVideoButton.setOnClickListener { pickVideoLauncher.launch("video/*") }
        col.addView(pickVideoButton, rowParams(dp(24)))

        videoLabel = TextView(this).apply {
            text = "Video မရွေးရသေးဘူး"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(videoLabel, rowParams(dp(12)))

        workCoverCheck = CheckBox(this).apply {
            text = "မူလ စာတန်းကို ဖျောက်မယ်"
            textSize = 16f
            setTextColor(Color.WHITE)
            isChecked = true
        }
        col.addView(workCoverCheck, rowParams(dp(12)))

        makeButton = ctaButton("")
        makeButton.isEnabled = false
        makeButton.setOnClickListener { onMakeClicked() }
        col.addView(makeButton, rowParams(dp(12)))

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        col.addView(progressBar, rowParams(dp(16)))

        statusText = TextView(this).apply {
            text = "Video ရွေးပါ။"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(statusText, rowParams(dp(8)))

        workDownloadButton = pillButton("Video ဒေါင်းလုဒ်လုပ်ရန်", Color.WHITE, Color.BLACK, null)
        workDownloadButton.visibility = View.GONE
        workDownloadButton.setOnClickListener { onWorkDownloadClicked() }
        col.addView(workDownloadButton, rowParams(dp(12)))

        workPreviewVideo = VideoView(this).apply {
            visibility = View.GONE
        }
        workPreviewVideo.setMediaController(
            MediaController(this).apply { setAnchorView(workPreviewVideo) }
        )
        col.addView(
            workPreviewVideo,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(280)
            ).apply { topMargin = dp(12) }
        )

        col.addView(backLink(), rowParams(dp(16)))
        return wrapScroll(col)
    }

    private fun buildMtvScreen(): View {
        val col = screenColumn()
        col.addView(titleText("ပုံ + သီချင်း MTV ထုတ်ရန်", 22f))

        mtvImageButton = pillButton("လူပုံ ရွေးပါ", Color.WHITE, Color.BLACK, null)
        mtvImageButton.setOnClickListener { pickMtvImageLauncher.launch("image/*") }
        col.addView(mtvImageButton, rowParams(dp(24)))

        mtvImageLabel = TextView(this).apply {
            text = "ပုံ မရွေးရသေးဘူး"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(mtvImageLabel, rowParams(dp(8)))

        mtvSongField = EditText(this).apply {
            hint = "သီချင်းနာမည် ရိုက်ပါ — ဥပမာ Chit Thu"
            textSize = 17f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_TEXT
            maxLines = 1
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(22), dp(14), dp(22), dp(14))
        }
        col.addView(mtvSongField, rowParams(dp(16)))

        mtvLinkField = EditText(this).apply {
            hint = "YouTube Link (ရှိရင် ဒီမှာ ထည့်ပါ)"
            textSize = 17f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            maxLines = 1
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(22), dp(14), dp(22), dp(14))
        }
        col.addView(mtvLinkField, rowParams(dp(12)))

        col.addView(TextView(this).apply {
            text = "Link ထည့်ရင် အဲ့သီချင်းကို တိုက်ရိုက်သုံးမယ်။ Link မထည့်ရင် နာမည်နဲ့ ရှာမယ်။ သီချင်းရဲ့ အကောင်းဆုံး 20 စက္ကန့်ကို သုံးမယ်။"
            textSize = 15f
            setTextColor(Color.WHITE)
        }, rowParams(dp(8)))

        mtvMakeButton = pillButton(
            "MTV လုပ်မယ်", Color.rgb(30, 107, 74), Color.WHITE, Color.rgb(76, 175, 125)
        )
        mtvMakeButton.setOnClickListener { onMtvClicked() }
        col.addView(mtvMakeButton, rowParams(dp(16)))

        mtvProgressBar =
            ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = 0
            }
        col.addView(mtvProgressBar, rowParams(dp(16)))

        mtvStatusText = TextView(this).apply {
            text = "ပုံ ရွေးပြီး သီချင်းနာမည် ရိုက်ထည့်ပါ။"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(mtvStatusText, rowParams(dp(8)))

        mtvDownloadButton = pillButton("Video ဒေါင်းလုဒ်လုပ်ရန်", Color.WHITE, Color.BLACK, null)
        mtvDownloadButton.visibility = View.GONE
        mtvDownloadButton.setOnClickListener { onMtvDownloadClicked() }
        col.addView(mtvDownloadButton, rowParams(dp(12)))

        col.addView(backLink(), rowParams(dp(16)))
        return wrapScroll(col)
    }

    private fun buildTtsScreen(): View {
        val col = screenColumn()
        col.addView(titleText("စာကို AI အသံဖြင့် ဖတ်ပြရန်", 22f))

        ttsTextField = EditText(this).apply {
            hint = "ဖတ်ပြစေချင်တဲ့ မြန်မာစာသား ဒီမှာ ရိုက်ထည့်ပါ..."
            textSize = 17f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 6
            gravity = Gravity.TOP
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(22), dp(14), dp(22), dp(14))
        }
        col.addView(ttsTextField, rowParams(dp(24)))

        ttsImageButton = pillButton("ဇာတ်ကောင်ပုံ ရွေးပါ", Color.WHITE, Color.BLACK, null)
        ttsImageButton.setOnClickListener { pickImageLauncher.launch("image/*") }
        col.addView(ttsImageButton, rowParams(dp(12)))

        ttsImageLabel = TextView(this).apply {
            text = "ပုံ မရွေးရသေးဘူး (ပုံ မထည့်ရင် အသံသီးသန့် ထွက်မယ်)"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(ttsImageLabel, rowParams(dp(8)))

        col.addView(sectionLabel("အသံ ရွေးပါ"), rowParams(dp(20)))
        col.addView(buildVoicePicker(true), rowParams(dp(8)))

        col.addView(sectionLabel("အသံ ပုံစံ"), rowParams(dp(20)))
        col.addView(buildStylePicker(), rowParams(dp(8)))

        ttsRateLabel = TextView(this).apply {
            text = "အမြန်နှုန်း: ပုံမှန်"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(ttsRateLabel, rowParams(dp(20)))
        val rateBar = SeekBar(this).apply { max = 20; progress = 10 }
        rateBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                ttsRate = (progress - 10) * 5
                ttsRateLabel.text = when {
                    ttsRate == 0 -> "အမြန်နှုန်း: ပုံမှန်"
                    ttsRate > 0 -> "အမြန်နှုန်း: +$ttsRate% မြန်"
                    else -> "အမြန်နှုန်း: $ttsRate% နှေး"
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        col.addView(rateBar, rowParams(dp(4)))

        ttsMakeButton = ctaButton("အသံထုတ်မယ်")
        ttsMakeButton.setOnClickListener { onTtsClicked() }
        col.addView(ttsMakeButton, rowParams(dp(16)))

        ttsProgressBar =
            ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = 0
            }
        col.addView(ttsProgressBar, rowParams(dp(16)))

        // v0.6.20: listen to the generated voice here (play/pause +
        // seek + time) before downloading anything.
        ttsPlayerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
        }
        ttsPlayButton = Button(this).apply {
            text = "▶"
            textSize = 18f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = pillBg(Color.rgb(30, 107, 74), Color.rgb(76, 175, 125), 2)
            setPadding(dp(16), dp(6), dp(16), dp(6))
            setOnClickListener { toggleTtsPlayback() }
        }
        ttsPlayerRow.addView(ttsPlayButton)
        ttsSeekBar = SeekBar(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            )
        }
        ttsSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    try {
                        ttsPlayer?.seekTo(progress)
                    } catch (e: Exception) {
                    }
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        ttsPlayerRow.addView(ttsSeekBar)
        ttsTimeText = TextView(this).apply {
            text = "00:00 / 00:00"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(dp(8), 0, 0, 0)
        }
        ttsPlayerRow.addView(ttsTimeText)
        col.addView(ttsPlayerRow, rowParams(dp(8)))

        ttsStatusText = TextView(this).apply {
            text = "စာသား ရိုက်ထည့်ပြီး အသံထုတ်ပါ။ (စာသား အရှည် ၁၅၀၀၀ လုံးထိ ရတယ်)"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(ttsStatusText, rowParams(dp(8)))

        ttsDownloadButton = pillButton("အသံဖိုင် ဒေါင်းလုပ်လုပ်ရန်", Color.WHITE, Color.BLACK, null)
        ttsDownloadButton.visibility = View.GONE
        ttsDownloadButton.setOnClickListener { onTtsDownloadClicked() }
        col.addView(ttsDownloadButton, rowParams(dp(12)))

        col.addView(backLink(), rowParams(dp(16)))
        return wrapScroll(col)
    }

    private fun buildVoiceoverScreen(): View {
        val col = screenColumn()
        col.addView(titleText("Video ကို မြန်မာအသံဖြင့် ပြောပြရန်", 22f))

        col.addView(
            infoCard("အသံပဲ ဆာဘာကို ပို့မယ် — မြန်မာအသံ ရရင် ဖုန်းမှာ Auto တွဲမယ်။ ပြီးရင် ဒေါင်းလုဒ်ခလုတ် နှိပ်မှ Download/zhang file ထဲ သိမ်းမယ်။"),
            rowParams(dp(16))
        )

        voPickButton = pillButton("Video ရွေးပါ", Color.WHITE, Color.BLACK, null)
        voPickButton.setOnClickListener { pickVoVideoLauncher.launch("video/*") }
        col.addView(voPickButton, rowParams(dp(20)))

        voVideoLabel = TextView(this).apply {
            text = "Video မရွေးရသေးဘူး"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(voVideoLabel, rowParams(dp(12)))

        col.addView(sectionLabel("အသံ ရွေးပါ"), rowParams(dp(16)))
        col.addView(buildVoicePicker(true), rowParams(dp(8)))

        voMakeButton = ctaButton("မြန်မာအသံထုတ်မယ်")
        voMakeButton.isEnabled = false
        voMakeButton.setOnClickListener { onVoiceoverClicked() }
        col.addView(voMakeButton, rowParams(dp(16)))

        voProgressBar =
            ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = 0
            }
        col.addView(voProgressBar, rowParams(dp(16)))

        voStatusText = TextView(this).apply {
            text = "Video ရွေးပါ။"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(voStatusText, rowParams(dp(8)))

        // v0.6.8: preview the finished video + SRT before downloading.
        voPreviewVideo = VideoView(this).apply {
            visibility = View.GONE
        }
        col.addView(
            voPreviewVideo,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(300)
            ).apply { topMargin = dp(12) }
        )

        voSrtText = TextView(this).apply {
            text = ""
            textSize = 14f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(120, 0, 0, 0))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            visibility = View.GONE
        }
        col.addView(voSrtText, rowParams(dp(12)))

        // v0.6.21: separate downloads — the user picks Video or SRT.
        voDownloadButton = pillButton(
            "Video ဒေါင်းလုဒ်လုပ်ရန်", Color.WHITE, Color.BLACK, null
        )
        voDownloadButton.visibility = View.GONE
        voDownloadButton.setOnClickListener { onVoVideoDownloadClicked() }
        col.addView(voDownloadButton, rowParams(dp(12)))

        voSrtDownloadButton = pillButton(
            "SRT ဒေါင်းလုဒ်လုပ်ရန်", Color.WHITE, Color.BLACK, null
        )
        voSrtDownloadButton.visibility = View.GONE
        voSrtDownloadButton.setOnClickListener { onVoSrtDownloadClicked() }
        col.addView(voSrtDownloadButton, rowParams(dp(12)))

        col.addView(backLink(), rowParams(dp(16)))
        voScrollView = wrapScroll(col)
        return voScrollView
    }

    // v0.6.19: prompt-video is now a chat-style "Video generation"
    // screen like the reference Zin sent — back + title on top, an
    // open middle area, and the prompt box pinned to the bottom
    // with a + button for scene images and a send button.
    private fun buildPromptVideoScreen(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(12))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // Header: back + title.
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val back = TextView(this).apply {
            text = "←"
            textSize = 24f
            setTextColor(Color.WHITE)
            setPadding(dp(4), dp(4), dp(16), dp(4))
            setOnClickListener { showScreen(menuScreen) }
        }
        header.addView(back)
        header.addView(titleText("Video generation", 22f).apply {
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            )
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
        })
        root.addView(
            header,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        // Middle area: hint, picked images, status, progress, download.
        val middleScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            ).apply { topMargin = dp(8) }
        }
        val middle = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        middleScroll.addView(middle)
        root.addView(middleScroll)

        pvHintText = TextView(this).apply {
            text = "ဥပမာ — ရွာက ကြောင်လေးတစ်ကောင် ဈေးထဲမှာ ငါးခိုးစားတဲ့ ဇာတ်လမ်း"
            textSize = 14f
            setTextColor(Color.rgb(180, 180, 180))
            gravity = Gravity.CENTER
        }
        middle.addView(pvHintText, rowParams(dp(16)))

        // v0.6.9: up to 3 scene images (server v26+); thumbnails
        // with a small X each (v0.6.10/v0.6.12).
        pvImageLabel = TextView(this).apply {
            text = "ပုံ မထည့်ရသေးဘူး — ပုံမထည့်ရင် AI က ပုံထုတ်ပေးမယ်"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        middle.addView(pvImageLabel, rowParams(dp(12)))
        pvImageRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_HORIZONTAL
            visibility = View.GONE
        }
        middle.addView(pvImageRow, rowParams(dp(4)))
        pvClearImagesButton = pillButton("ပုံတွေ ဖျက်မယ်", Color.WHITE, Color.BLACK, null)
        pvClearImagesButton.visibility = View.GONE
        pvClearImagesButton.setOnClickListener {
            pvImageUris.clear()
            updatePvImageLabel()
        }
        middle.addView(pvClearImagesButton, rowParams(dp(8)))

        pvStatusText = TextView(this).apply {
            text = "Prompt ရိုက်ထည့်ပြီး Video ထုတ်ပါ။"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        middle.addView(pvStatusText, rowParams(dp(16)))
        pvProgressBar =
            ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = 0
            }
        middle.addView(pvProgressBar, rowParams(dp(8)))
        pvDownloadButton = pillButton(
            "Video ဒေါင်းလုဒ်လုပ်ရန်", Color.WHITE, Color.BLACK, null
        )
        pvDownloadButton.visibility = View.GONE
        pvDownloadButton.setOnClickListener { onPvDownloadClicked() }
        middle.addView(pvDownloadButton, rowParams(dp(12)))

        // Bottom input card: prompt field + image button + send.
        pvInputCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(24).toFloat()
                setColor(Color.rgb(35, 35, 35))
            }
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        pvTextField = EditText(this).apply {
            hint = "ဒီနေ့ ဘာ Video လုပ်မလဲ?"
            textSize = 17f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(150, 150, 150))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 2
            maxLines = 5
            gravity = Gravity.TOP
            background = null
            setPadding(0, dp(4), 0, dp(4))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        pvInputCard.addView(pvTextField)
        val cardRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        pvPickImageButton = pillButton("+", Color.rgb(60, 60, 60), Color.WHITE, null).apply {
            textSize = 22f
            setPadding(dp(18), dp(2), dp(18), dp(2))
            setOnClickListener { pickPvImageLauncher.launch("image/*") }
        }
        cardRow.addView(pvPickImageButton)
        cardRow.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                0, 1, 1f
            )
        })
        // v0.6.12: no voice picker on this screen — the server (v28+)
        // assigns each character their own voice automatically.
        pvMakeButton = pillButton(
            "➤", Color.rgb(30, 107, 74), Color.WHITE, Color.rgb(76, 175, 125)
        ).apply {
            textSize = 20f
            setPadding(dp(18), dp(2), dp(18), dp(2))
            setOnClickListener { onPromptVideoClicked() }
        }
        cardRow.addView(pvMakeButton)
        pvInputCard.addView(
            cardRow,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) }
        )
        root.addView(
            pvInputCard,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        )
        return root
    }

    // v0.6.18: the timing screen is now a CapCut-style timeline
    // editor — preview on top, ruler + video strip + music track +
    // SRT track on one shared time axis, tools in a bottom toolbar
    // with one panel open at a time. All editor functions are
    // unchanged; only the layout moved.
    private fun buildTimingScreen(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            // v0.6.23: VN-style solid black page — the studio photo
            // must not show through the editor.
            setBackgroundColor(Color.BLACK)
            // v0.9.5: slim top/bottom margins — v0.9.4's taller
            // timeline crushed the panel area to ~0 height.
            setPadding(dp(16), dp(16), dp(16), dp(8))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // Header: back + title.
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val back = TextView(this).apply {
            text = "← Back"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(dp(4), dp(8), dp(12), dp(8))
            setOnClickListener { showScreen(menuScreen) }
        }
        header.addView(back)
        header.addView(titleText("Video Editor", 22f).apply {
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            )
            gravity = Gravity.CENTER
        })
        // v0.6.22: VN-style export button at the top-right corner.
        val exportTopButton = Button(this).apply {
            text = "⬆ Export"
            textSize = 14f
            isAllCaps = false
            setTextColor(Color.WHITE)
            // v0.9.0: VN/demo blue Export pill.
            background = pillBg(Color.rgb(33, 150, 243), null, 2)
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener { timingExportPanel?.let { showTimingPanel(it) } }
        }
        header.addView(exportTopButton)
        root.addView(
            header,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        // Preview: video + title text overlay + pick button (shown
        // only until a video is picked).
        timingPreviewFrame = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }
        timingPreviewVideo = VideoView(this)
        timingPreviewFrame.addView(
            timingPreviewVideo,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        // v0.9.3: magenta center guides, shown while dragging text
        // on the preview, VN-style.
        timingGuideV = View(this).apply {
            setBackgroundColor(Color.MAGENTA)
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(
                dp(1), ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER_HORIZONTAL
            )
        }
        timingPreviewFrame.addView(timingGuideV)
        timingGuideH = View(this).apply {
            setBackgroundColor(Color.MAGENTA)
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(1),
                Gravity.CENTER_VERTICAL
            )
        }
        timingPreviewFrame.addView(timingGuideH)
        // v0.9.4: sticker/overlay photo on the preview — draggable
        // and pinch-scalable, VN/CapCut-style. Sits below the
        // subtitle line, above the video.
        timingOverlayImage = ImageView(this).apply {
            visibility = View.GONE
            scaleType = ImageView.ScaleType.FIT_XY
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.START
            )
        }
        timingPreviewFrame.addView(timingOverlayImage)
        attachOverlayDrag(timingOverlayImage)
        timingTopTextPreview = TextView(this).apply {
            text = ""
            textSize = 18f
            setTextColor(Color.WHITE)
            setShadowLayer(6f, 0f, 2f, Color.BLACK)
            gravity = Gravity.CENTER
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.START
            ).apply { topMargin = dp(16) }
        }
        timingPreviewFrame.addView(timingTopTextPreview)
        attachPreviewTextDrag(timingTopTextPreview, true)
        // v0.9.1: beautiful empty state — icon + guidance + pick
        // button, grouped and centered, instead of a bare pill
        // floating in a black frame.
        timingPreviewPlaceholder = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        timingPreviewPlaceholder.addView(TextView(this).apply {
            text = "🎬"
            textSize = 48f
            gravity = Gravity.CENTER
        })
        timingPreviewPlaceholder.addView(TextView(this).apply {
            text = "Pick a video to start editing"
            textSize = 15f
            setTextColor(Color.rgb(180, 180, 180))
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(16))
        })
        timingPickVideoButton = pillButton("Pick a video", Color.WHITE, Color.BLACK, null).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { gravity = Gravity.CENTER_HORIZONTAL }
            setOnClickListener { pickTimingVideoLauncher.launch("video/*") }
        }
        timingPreviewPlaceholder.addView(timingPickVideoButton)
        timingPreviewFrame.addView(timingPreviewPlaceholder)
        root.addView(
            timingPreviewFrame,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(280)
            ).apply { topMargin = dp(8) }
        )

        // v0.8.0: live subtitle line overlaid at the bottom of the
        // preview, VN-style, instead of a row under it.
        timingCueText = TextView(this).apply {
            text = ""
            textSize = 16f
            minHeight = dp(32)
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            // v0.9.4: drawable background so refreshCueTextBorder
            // can swap a white box border in/out (CapCut style).
            background = GradientDrawable().apply {
                setColor(Color.argb(120, 0, 0, 0))
            }
            setPadding(dp(12), dp(8), dp(12), dp(8))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.START
            )
        }
        timingPreviewFrame.addView(timingCueText)
        attachPreviewTextDrag(timingCueText, false)


        // v0.9.0: speed badge, VN/demo-style, top-left of the preview.
        timingSpeedBadge = TextView(this).apply {
            text = "Speed: 1.0x"
            textSize = 13f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(140, 0, 0, 0))
            setPadding(dp(10), dp(4), dp(10), dp(4))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.START
            ).apply {
                topMargin = dp(8)
                marginStart = dp(8)
            }
        }
        timingPreviewFrame.addView(timingSpeedBadge)

        // v0.9.7: intro cover image, topmost — shown while the
        // playhead is inside the intro duration.
        timingCoverPreview = ImageView(this).apply {
            visibility = View.GONE
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        timingPreviewFrame.addView(timingCoverPreview)

        // Transport: play/pause + time + video name.
        val transport = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        timingPlayButton = Button(this).apply {
            text = "▶"
            textSize = 18f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = pillBg(Color.rgb(30, 107, 74), Color.rgb(76, 175, 125), 2)
            setPadding(dp(16), dp(6), dp(16), dp(6))
            setOnClickListener {
                if (timingVideoUri == null) return@setOnClickListener
                if (timingPreviewVideo.isPlaying) timingPreviewVideo.pause()
                else timingPreviewVideo.start()
            }
        }
        val skipBack = pillButton(
            "−5s", Color.rgb(30, 107, 74), Color.WHITE, Color.rgb(76, 175, 125)
        ).apply {
            textSize = 14f
            setPadding(dp(12), dp(6), dp(12), dp(6))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = dp(8) }
            setOnClickListener { skipTimingPreview(-5_000L) }
        }
        transport.addView(skipBack)
        transport.addView(timingPlayButton)
        val skipFwd = pillButton(
            "+5s", Color.rgb(30, 107, 74), Color.WHITE, Color.rgb(76, 175, 125)
        ).apply {
            textSize = 14f
            setPadding(dp(12), dp(6), dp(12), dp(6))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginStart = dp(8) }
            setOnClickListener { skipTimingPreview(5_000L) }
        }
        transport.addView(skipFwd)
        timingTimeText = TextView(this).apply {
            text = "00:00 /\n00:00.00"
            textSize = 14f
            maxLines = 2
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            // v0.9.5: vertical padding — the 2nd line was clipped
            // on phones with a tall system font.
            setPadding(dp(12), dp(4), dp(12), dp(4))
        }
        transport.addView(timingTimeText, 0)
        timingVideoLabel = TextView(this).apply {
            text = "No video picked"
            textSize = 14f
            setTextColor(Color.rgb(235, 235, 235))
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, 1f
            )
        }
        transport.addView(timingVideoLabel)
        root.addView(transport, rowParams(dp(8)))

        // v0.8.0: VN-style timeline — fixed row labels on the left
        // and one shared horizontally scrolling track column on
        // the right, so long videos get a usable timeline instead
        // of everything squashed into one screen width. Row order:
        // music, subtitle, sticker/overlay, video strip, time ruler
        // at the bottom (v0.9.4: overlay row + taller video row).
        val deck = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.argb(170, 0, 0, 0))
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        // Labels mirror the track heights + top margins exactly,
        // so each label stays lined up with its track.
        val labelColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        // v0.9.4: icon rail — one rounded-square button per row
        // (demo style): music, subtitle, sticker/overlay.
        val railButton: (String, Float, () -> Unit) -> TextView =
            { icon, size, onTap ->
                TextView(this).apply {
                    text = icon
                    textSize = size
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    background = pillBg(
                        Color.rgb(45, 45, 45), Color.rgb(130, 130, 130), 1
                    )
                    setOnClickListener { onTap() }
                }
            }
        labelColumn.addView(
            railButton("♪", 18f) { pickMusicLauncher.launch("audio/*") },
            LinearLayout.LayoutParams(dp(36), dp(32)).apply { topMargin = dp(2) }
        )
        labelColumn.addView(
            railButton("T", 18f) { pickSrtLauncher.launch("*/*") },
            LinearLayout.LayoutParams(dp(36), dp(40)).apply { topMargin = dp(2) }
        )
        labelColumn.addView(
            railButton("🖼️", 16f) { pickOverlayLauncher.launch("image/*") },
            LinearLayout.LayoutParams(dp(36), dp(40)).apply { topMargin = dp(2) }
        )
        // v0.9.4: video-row cell — Cover (v0.9.3) on top, mute
        // toggle below (demo rail's speaker icon).
        val coverCell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val coverTap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setOnClickListener { onTimingCoverClicked() }
        }
        coverTap.addView(TextView(this).apply {
            text = "🎬"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        })
        coverTap.addView(TextView(this).apply {
            text = "Cover"
            textSize = 7f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        })
        coverCell.addView(coverTap)
        timingRailMuteButton = TextView(this).apply {
            text = "🔊"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setOnClickListener {
                val muted = ::timingMuteCheck.isInitialized &&
                    timingMuteCheck.isChecked
                setRailMute(!muted)
            }
        }
        coverCell.addView(timingRailMuteButton)
        labelColumn.addView(
            coverCell,
            LinearLayout.LayoutParams(dp(36), dp(48)).apply { topMargin = dp(2) }
        )
        labelColumn.addView(
            View(this), LinearLayout.LayoutParams(dp(36), dp(16))
        )
        deck.addView(labelColumn)
        timingTimelineScroll = HorizontalScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            )
            isHorizontalScrollBarEnabled = false
        }
        val trackColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        timingMusicTrack = MusicTrackView(this).apply {
            onSeekTo = { ms -> seekTimingPreview(ms) }
            onAddMusic = { pickMusicLauncher.launch("audio/*") }
            onSelect = { idx -> setSelection(if (idx >= 0) 2 else 0, idx) }
            onMusicClipMoved = { idx, s, e, o ->
                onMusicClipMoved(idx, s, e, o)
            }
        }
        trackColumn.addView(
            timingMusicTrack,
            LinearLayout.LayoutParams(timelineContentWidthPx(), dp(32))
                .apply { topMargin = dp(2) }
        )
        timingSrtTrack = SrtTrackView(this).apply {
            onSeekTo = { ms -> seekTimingPreview(ms) }
            onAddSrt = { pickSrtLauncher.launch("*/*") }
            onSelect = { idx -> setSelection(if (idx >= 0) 3 else 0, idx) }
            onCueMoved = { idx, s, e -> onSrtCueMoved(idx, s, e) }
        }
        trackColumn.addView(
            timingSrtTrack,
            LinearLayout.LayoutParams(timelineContentWidthPx(), dp(40))
                .apply { topMargin = dp(2) }
        )
        timingOverlayTrack = OverlayTrackView(this).apply {
            onSeekTo = { ms -> seekTimingPreview(ms) }
            onAddOverlay = { pickOverlayLauncher.launch("image/*") }
            onSelect = { idx -> setSelection(if (idx >= 0) 4 else 0, idx) }
            onOverlayClipMoved = { idx, s, e -> onOverlayClipMoved(idx, s, e) }
        }
        trackColumn.addView(
            timingOverlayTrack,
            LinearLayout.LayoutParams(timelineContentWidthPx(), dp(40))
                .apply { topMargin = dp(2) }
        )
        timingVideoStrip = VideoStripView(this).apply {
            onSeekTo = { ms -> seekTimingPreview(ms) }
            onSelect = { idx -> setSelection(if (idx >= 0) 1 else 0, idx) }
            onSegmentResized = { idx, s, e -> onVideoSegmentResized(idx, s, e) }
        }
        trackColumn.addView(
            timingVideoStrip,
            LinearLayout.LayoutParams(timelineContentWidthPx(), dp(48))
                .apply { topMargin = dp(2) }
        )
        timingRuler = TimeRulerView(this)
        trackColumn.addView(
            timingRuler,
            LinearLayout.LayoutParams(timelineContentWidthPx(), dp(16))
        )
        timingTimelineScroll.addView(trackColumn)
        deck.addView(timingTimelineScroll)
        root.addView(deck, rowParams(dp(8)))
        updateTimelineWidths()

        // v0.7.0: selection bar — Split / Delete for the selected
        // segment (shown only while a segment is selected).
        timingSelectionScroll = HorizontalScrollView(this).apply {
            visibility = View.GONE
            // v0.8.1: teal action bar, VN/Gemini-zip style.
            setBackgroundColor(Color.rgb(30, 107, 74))
            setPadding(dp(8), dp(4), dp(8), dp(4))
            isHorizontalScrollBarEnabled = false
        }
        timingSelectionBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        timingSelectionLabel = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            // v0.8.2: one line only — a wrapped label ballooned
            // the whole bar and pushed the tracks off screen.
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            minWidth = dp(48)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = dp(8) }
        }
        timingSelectionBar.addView(timingSelectionLabel)
        timingSplitButton = pillButton(
            "Split", Color.rgb(30, 107, 74), Color.WHITE, Color.rgb(76, 175, 125)
        ).apply {
            textSize = 13f
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        timingSplitButton.setOnClickListener { onSplitSelected() }
        timingSelectionBar.addView(timingSplitButton)
        // v0.9.4: Volume (CapCut clip toolbar) — opens the Volume
        // panel for the selected video/music clip.
        timingVolumeBarButton = pillButton(
            "Volume", Color.rgb(30, 107, 74), Color.WHITE,
            Color.rgb(76, 175, 125)
        ).apply {
            textSize = 13f
            setPadding(dp(8), dp(6), dp(8), dp(6))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginStart = dp(8) }
        }
        timingVolumeBarButton.setOnClickListener {
            openVolumePanel(if (selectedTrack == 2) 2 else 1)
        }
        timingSelectionBar.addView(timingVolumeBarButton)
        timingDeleteSegmentButton = pillButton(
            "Delete", Color.WHITE, Color.BLACK, null
        ).apply {
            textSize = 13f
            setPadding(dp(8), dp(6), dp(8), dp(6))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginStart = dp(8) }
        }
        timingDeleteSegmentButton.setOnClickListener { onDeleteSelected() }
        timingSelectionBar.addView(timingDeleteSegmentButton)
        // v0.7.1: Undo right in the selection bar, so a mistaken
        // delete can be undone where it happened.
        timingUndoBarButton = pillButton(
            "↩️", Color.WHITE, Color.BLACK, null
        ).apply {
            textSize = 13f
            setPadding(dp(8), dp(6), dp(8), dp(6))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginStart = dp(8) }
        }
        timingUndoBarButton.setOnClickListener { undoLastEdit() }
        timingSelectionBar.addView(timingUndoBarButton)
        // v0.8.1: Redo, next to Undo.
        timingRedoBarButton = pillButton(
            "↪️", Color.WHITE, Color.BLACK, null
        ).apply {
            textSize = 13f
            setPadding(dp(8), dp(6), dp(8), dp(6))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginStart = dp(8) }
        }
        timingRedoBarButton.setOnClickListener { redoLastEdit() }
        timingSelectionBar.addView(timingRedoBarButton)
        // v0.8.0: the clip toolbar sits above the timeline,
        // VN-style, so it never pushes the panels off screen.
        // v0.9.4: wrapped in a horizontal scroller (contextual
        // buttons can exceed the screen width).
        timingSelectionScroll.addView(timingSelectionBar)
        root.addView(
            timingSelectionScroll, root.indexOfChild(deck), rowParams(dp(8))
        )

        // Panel area: one tool panel visible at a time.
        val panelScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            ).apply { topMargin = dp(8) }
        }
        val panelBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        panelBox.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        panelScroll.addView(panelBox)
        root.addView(panelScroll)
        // v0.9.2: scroll a typing field into view above the keyboard
        // (adjustResize alone left it hidden behind the keyboard).
        val scrollFieldIntoView: (View) -> Unit = { field ->
            val targetY = ((field.parent as? View)?.top ?: 0) +
                field.top - dp(8)
            val target = targetY.coerceAtLeast(0)
            panelScroll.post { panelScroll.smoothScrollTo(0, target) }
            panelScroll.postDelayed(
                { panelScroll.smoothScrollTo(0, target) }, 300L
            )
        }

        // Video panel: pick / change the video.
        val videoPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        videoPanel.addView(
            hintText("Pick a video — then tap the tracks to move in time."),
            rowParams(0)
        )
        timingChangeVideoButton = pillButton("Change video", Color.WHITE, Color.BLACK, null)
        timingChangeVideoButton.setOnClickListener { pickTimingVideoLauncher.launch("video/*") }
        videoPanel.addView(timingChangeVideoButton, rowParams(dp(12)))
        // v0.6.24: VN-style delete — remove the picked video.
        timingDeleteVideoButton = pillButton("Remove video", Color.WHITE, Color.BLACK, null)
        timingDeleteVideoButton.visibility = View.GONE
        timingDeleteVideoButton.setOnClickListener {
            timingPreviewVideo.stopPlayback()
            pauseTimingMusicPreview()
            timingMediaPlayer = null
            timingPreviewHandler.removeCallbacks(timingPreviewPoller)
            timingVideoUri = null
            timingVideoDurationMs = 0L
            timingVideoSegments = mutableListOf()
            timingVideoLabel.text = "No video picked"
            timingTimeText.text = "00:00 /\n00:00.00"
            timingPlayButton.text = "▶"
            timingCueText.text = ""
            timingOverlayClips = mutableListOf()
            if (::timingOverlayTrack.isInitialized) {
                timingOverlayTrack.clearOverlays()
            }
            if (::timingOverlayImage.isInitialized) {
                timingOverlayImage.visibility = View.GONE
            }
            timingVideoStrip.clear()
            updateTimelineWidths()
            timingPreviewPlaceholder.visibility = View.VISIBLE
            timingDeleteVideoButton.visibility = View.GONE
            refreshEditorModels()
            setSelection(0, -1)
            updateTimingEnabled()
        }
        videoPanel.addView(timingDeleteVideoButton, rowParams(dp(12)))
        // v0.9.2: separate video volume — preview + export.
        timingVideoVolumeLabel = TextView(this).apply {
            text = "Video volume: 100%"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        videoPanel.addView(timingVideoVolumeLabel, rowParams(dp(12)))
        timingVideoVolumeSlider = SeekBar(this).apply { max = 100; progress = 100 }
        timingVideoVolumeSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                timingVideoVolume = progress / 100f
                timingVideoVolumeLabel.text = "Video volume: $progress%"
                applyTimingPreviewVolume()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        videoPanel.addView(timingVideoVolumeSlider, rowParams(dp(4)))
        panelBox.addView(videoPanel, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        timingToolPanels.add(videoPanel)

        // Subtitle panel: SRT file + shift slider + info.
        val subtitlePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        timingSubtitlePanel = subtitlePanel
        // v0.9.2: no SRT-file row here (Zin) — SRT is added by
        // tapping the subtitle track. The button/label objects stay
        // (other code updates them) but are not shown.
        timingPickSrtButton = pillButton("Pick SRT file", Color.WHITE, Color.BLACK, null)
        timingPickSrtButton.setOnClickListener { pickSrtLauncher.launch("*/*") }
        timingSrtLabel = TextView(this).apply {
            text = "No SRT picked"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        // v0.6.24: VN-style delete — remove the loaded SRT.
        timingDeleteSrtButton = pillButton("Clear all subtitles", Color.WHITE, Color.BLACK, null)
        timingDeleteSrtButton.visibility = View.GONE
        timingDeleteSrtButton.setOnClickListener {
            timingCues = emptyList()
            timingSrtLabel.text = "No SRT picked"
            timingDeleteSrtButton.visibility = View.GONE
            setSelection(0, -1)
            updateTimingInfo()
            updateTimingEnabled()
        }
        subtitlePanel.addView(timingDeleteSrtButton, rowParams(dp(8)))
        // v0.7.8: manual captions — for people who don't want to use
        // an SRT file: type the text, add it at the playhead (3s).
        timingManualTextField = EditText(this).apply {
            hint = "Type subtitle text…"
            textSize = 16f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_TEXT
            maxLines = 1
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setOnFocusChangeListener { v, hasFocus ->
                if (hasFocus) scrollFieldIntoView(v)
            }
        }
        subtitlePanel.addView(timingManualTextField, rowParams(dp(16)))
        // v0.9.2: the Text style / Text color rows moved to the
        // fixed typing bar above the toolbar (visible while typing).
        // v0.7.9: VN-style — how long the typed caption shows (1-10s).
        timingCueDurationLabel = TextView(this).apply {
            text = "Show for: 3 seconds"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        subtitlePanel.addView(timingCueDurationLabel, rowParams(dp(12)))
        timingCueDurationSlider = SeekBar(this).apply { max = 18; progress = 4 }
        timingCueDurationSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val seconds = 1.0 + progress * 0.5
                timingManualCueDurationUs = (seconds * 1_000_000).toLong()
                timingCueDurationLabel.text =
                    "Show for: ${fmtSeconds(seconds)} seconds"
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        subtitlePanel.addView(timingCueDurationSlider, rowParams(dp(4)))
        timingAddCueButton = pillButton(
            "Add text at playhead", Color.WHITE, Color.BLACK, null
        )
        timingAddCueButton.setOnClickListener { onAddManualCue() }
        subtitlePanel.addView(timingAddCueButton, rowParams(dp(8)))
        timingEditCueButton = pillButton(
            "Edit selected subtitle", Color.WHITE, Color.BLACK, null
        )
        timingEditCueButton.setOnClickListener { onEditSelectedCueText() }
        subtitlePanel.addView(timingEditCueButton, rowParams(dp(8)))
        // v0.8.2: precise lengthen/shorten for the selected
        // subtitle — 0.5s steps, for cues too small to grab.
        val cueDurationRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        timingCueShorterButton = pillButton(
            "− 0.5s", Color.WHITE, Color.BLACK, null
        ).apply {
            textSize = 15f
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            ).apply { marginEnd = dp(8) }
        }
        timingCueShorterButton.setOnClickListener {
            onAdjustSelectedCueDuration(-500_000L)
        }
        cueDurationRow.addView(timingCueShorterButton)
        timingCueLongerButton = pillButton(
            "+ 0.5s", Color.WHITE, Color.BLACK, null
        ).apply {
            textSize = 15f
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            )
        }
        timingCueLongerButton.setOnClickListener {
            onAdjustSelectedCueDuration(500_000L)
        }
        cueDurationRow.addView(timingCueLongerButton)
        subtitlePanel.addView(cueDurationRow, rowParams(dp(8)))
        timingShiftLabel = TextView(this).apply {
            text = "Subtitle timing: normal (no shift)"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        subtitlePanel.addView(timingShiftLabel, rowParams(dp(20)))
        val shiftBar = SeekBar(this).apply { max = 40; progress = 20 }
        shiftBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val seconds = (progress - 20) * 0.5
                timingShiftUs = (seconds * 1_000_000).toLong()
                timingShiftLabel.text = when {
                    seconds == 0.0 -> "Subtitle timing: normal (no shift)"
                    seconds > 0 -> "Subtitle timing: +${fmtSeconds(seconds)}s late"
                    else -> "Subtitle timing: ${fmtSeconds(seconds)}s early"
                }
                updateTimingInfo()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        subtitlePanel.addView(shiftBar, rowParams(dp(4)))
        timingInfoText = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.rgb(255, 213, 74))
        }
        subtitlePanel.addView(timingInfoText, rowParams(dp(8)))
        // v0.9.0: Done closes the sheet, demo-style.
        val subtitleDoneButton = pillButton(
            "Done", Color.rgb(30, 107, 74), Color.WHITE, null
        ).apply { textSize = 16f }
        subtitleDoneButton.setOnClickListener { hideTimingPanels() }
        subtitlePanel.addView(subtitleDoneButton, rowParams(dp(12)))
        panelBox.addView(subtitlePanel, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        timingToolPanels.add(subtitlePanel)

        // Trim panel: keep only the video between start and end
        // seconds (blank end = to the end). Subtitles are cut and
        // rebased to match the trimmed video.
        val trimPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        trimPanel.addView(sectionLabel("Trim video (seconds)"), rowParams(0))
        val trimRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        timingTrimStartField = EditText(this).apply {
            hint = "Start (0)"
            textSize = 16f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
        }
        trimRow.addView(timingTrimStartField)
        timingTrimEndField = EditText(this).apply {
            hint = "End (all)"
            textSize = 16f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        trimRow.addView(timingTrimEndField)
        trimPanel.addView(trimRow, rowParams(dp(4)))
        panelBox.addView(trimPanel, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        timingToolPanels.add(trimPanel)

        // Speed panel: 4 presets.
        val speedPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        speedPanel.addView(sectionLabel("Speed"), rowParams(0))
        val speedRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        for ((label, speed) in listOf("0.5x" to 0.5f, "1x" to 1f, "1.5x" to 1.5f, "2x" to 2f)) {
            val button = pillButton(label, Color.WHITE, Color.BLACK, null).apply {
                textSize = 16f
                layoutParams = LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
                ).apply { marginEnd = dp(8) }
                setOnClickListener {
                    timingSpeed = speed
                    refreshSpeedButtons()
                }
            }
            timingSpeedButtons.add(button to speed)
            speedRow.addView(button)
        }
        speedPanel.addView(speedRow, rowParams(dp(4)))
        // v0.7.2: custom speed slider (0.25x–4x, 0.05 steps) — drag
        // for any speed; the preset pills above still jump to
        // their value and move the slider with them.
        timingSpeedLabel = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        speedPanel.addView(timingSpeedLabel, rowParams(dp(12)))
        timingSpeedSlider = SeekBar(this).apply {
            max = 75
            progress = 15
        }
        timingSpeedSlider.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(
                    seekBar: SeekBar?, progress: Int, fromUser: Boolean
                ) {
                    if (!fromUser) return
                    timingSpeed = 0.25f + progress * 0.05f
                    refreshSpeedButtons()
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            }
        )
        speedPanel.addView(timingSpeedSlider, rowParams(dp(4)))
        // v0.8.2: fine speed steps — 0.25x per tap, for landing
        // on an exact speed without fighting the slider.
        val speedStepRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val speedDown = pillButton(
            "− 0.25x", Color.WHITE, Color.BLACK, null
        ).apply {
            textSize = 15f
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            ).apply { marginEnd = dp(8) }
        }
        speedDown.setOnClickListener {
            timingSpeed = (timingSpeed - 0.25f).coerceIn(0.25f, 4f)
            refreshSpeedButtons()
        }
        speedStepRow.addView(speedDown)
        val speedUp = pillButton(
            "+ 0.25x", Color.WHITE, Color.BLACK, null
        ).apply {
            textSize = 15f
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            )
        }
        speedUp.setOnClickListener {
            timingSpeed = (timingSpeed + 0.25f).coerceIn(0.25f, 4f)
            refreshSpeedButtons()
        }
        speedStepRow.addView(speedUp)
        speedPanel.addView(speedStepRow, rowParams(dp(8)))
        refreshSpeedButtons()
        panelBox.addView(speedPanel, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        timingToolPanels.add(speedPanel)

        // Music panel: background music (loops) + mute original.
        val musicPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        musicPanel.addView(sectionLabel("Background music"), rowParams(0))
        val musicPickButton = pillButton("Pick music", Color.WHITE, Color.BLACK, null)
        musicPickButton.setOnClickListener { pickMusicLauncher.launch("audio/*") }
        musicPanel.addView(musicPickButton, rowParams(dp(4)))
        timingMusicLabel = TextView(this).apply {
            text = "No music picked"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        musicPanel.addView(timingMusicLabel, rowParams(dp(8)))
        timingMusicClearButton = pillButton("Remove music", Color.WHITE, Color.BLACK, null)
        timingMusicClearButton.visibility = View.GONE
        timingMusicClearButton.setOnClickListener {
            releaseTimingMusicPlayer()
            timingMusicUri = null
            timingMusicClips = mutableListOf()
            timingMusicDurationMs = 0L
            timingMusicName = ""
            timingMusicLabel.text = "No music picked"
            timingMusicClearButton.visibility = View.GONE
            timingMusicTrack.clearMusic()
            setSelection(0, -1)
        }
        musicPanel.addView(timingMusicClearButton, rowParams(dp(4)))
        timingMuteCheck = CheckBox(this).apply {
            text = "Mute original audio (music only)"
            textSize = 16f
            setTextColor(Color.WHITE)
            // v0.9.4: keep the rail mute icon + preview in step.
            setOnCheckedChangeListener { _, checked -> setRailMute(checked) }
        }
        musicPanel.addView(timingMuteCheck, rowParams(dp(4)))
        // v0.9.2: separate music volume (exported video).
        timingMusicVolumeLabel = TextView(this).apply {
            text = "Music volume: 100%"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        musicPanel.addView(timingMusicVolumeLabel, rowParams(dp(8)))
        timingMusicVolumeSlider = SeekBar(this).apply { max = 100; progress = 100 }
        timingMusicVolumeSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                timingMusicVolume = progress / 100f
                timingMusicVolumeLabel.text = "Music volume: $progress%"
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        musicPanel.addView(timingMusicVolumeSlider, rowParams(dp(4)))
        musicPanel.addView(
            hintText("Music volume applies to the exported video."),
            rowParams(dp(4))
        )
        panelBox.addView(musicPanel, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        timingToolPanels.add(musicPanel)

        // Text panel: title text shown at the top of the preview
        // and burned at the top of the exported video.
        val textPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        timingTitlePanel = textPanel
        textPanel.addView(sectionLabel("Video title — text shown on the video"), rowParams(0))
        timingTopTextField = EditText(this).apply {
            hint = "Optional"
            textSize = 16f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_TEXT
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setOnFocusChangeListener { v, hasFocus ->
                if (hasFocus) scrollFieldIntoView(v)
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(
                    s: CharSequence?, start: Int, count: Int, after: Int
                ) {
                }

                override fun onTextChanged(
                    s: CharSequence?, start: Int, before: Int, count: Int
                ) {
                }

                override fun afterTextChanged(s: Editable?) {
                    val text = s?.toString().orEmpty()
                    timingTopTextPreview.text = text
                    timingTopTextPreview.visibility =
                        if (text.isBlank()) View.GONE else View.VISIBLE
                    positionTimingTitle()
                }
            })
        }
        textPanel.addView(timingTopTextField, rowParams(dp(4)))
        // v0.6.24: VN-style delete — clear the title text.
        val deleteTextButton = pillButton("Clear text", Color.WHITE, Color.BLACK, null)
        deleteTextButton.setOnClickListener { timingTopTextField.setText("") }
        textPanel.addView(deleteTextButton, rowParams(dp(4)))
        panelBox.addView(textPanel, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        timingToolPanels.add(textPanel)

        // Volume panel (v0.9.4, CapCut style): 0–1000 slider + done
        // check. Opened from the selection-bar Volume button for the
        // selected video/music clip; writes the same volume fields
        // as the Video/Music panel sliders.
        timingVolumePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val volumeTitleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        volumeTitleRow.addView(TextView(this).apply {
            text = "Volume"
            textSize = 18f
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            )
        })
        val volumeDoneButton = pillButton(
            "✓", Color.rgb(30, 107, 74), Color.WHITE, Color.rgb(76, 175, 125)
        ).apply {
            textSize = 18f
            setPadding(dp(16), dp(6), dp(16), dp(6))
        }
        volumeDoneButton.setOnClickListener { hideTimingPanels() }
        volumeTitleRow.addView(volumeDoneButton)
        timingVolumePanel.addView(volumeTitleRow, rowParams(0))
        timingVolumeValueLabel = TextView(this).apply {
            text = "Volume: 1000"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        timingVolumePanel.addView(timingVolumeValueLabel, rowParams(dp(8)))
        timingVolumeSlider = SeekBar(this).apply { max = 1000; progress = 1000 }
        timingVolumeSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val gain = progress / 1000f
                timingVolumeValueLabel.text = "Volume: $progress"
                val pct = progress / 10
                if (timingVolumeTarget == 2) {
                    val clipIdx = timingVolumeClipIndex
                    if (clipIdx in timingMusicClips.indices) {
                        timingMusicClips[clipIdx] =
                            timingMusicClips[clipIdx].copy(volume = gain)
                    } else {
                        if (::timingMusicVolumeSlider.isInitialized &&
                            timingMusicVolumeSlider.progress != pct
                        ) {
                            timingMusicVolumeSlider.progress = pct
                        }
                        timingMusicVolume = gain
                        if (::timingMusicVolumeLabel.isInitialized) {
                            timingMusicVolumeLabel.text = "Music volume: $pct%"
                        }
                    }
                } else {
                    if (::timingVideoVolumeSlider.isInitialized &&
                        timingVideoVolumeSlider.progress != pct
                    ) {
                        timingVideoVolumeSlider.progress = pct
                    }
                    timingVideoVolume = gain
                    if (::timingVideoVolumeLabel.isInitialized) {
                        timingVideoVolumeLabel.text = "Video volume: $pct%"
                    }
                    applyTimingPreviewVolume()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        timingVolumePanel.addView(timingVolumeSlider, rowParams(dp(4)))
        timingVolumePanel.addView(
            hintText("1000 = full volume. 0 = silent."),
            rowParams(dp(4))
        )
        panelBox.addView(timingVolumePanel, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        timingToolPanels.add(timingVolumePanel)

        // Export panel: burn + SRT save + progress + download.
        val exportPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        timingBurnButton = pillButton(
            "Make video", Color.rgb(30, 107, 74), Color.WHITE, Color.rgb(76, 175, 125)
        )
        timingBurnButton.isEnabled = false
        timingBurnButton.setOnClickListener { onTimingBurnClicked() }
        exportPanel.addView(timingBurnButton, rowParams(0))
        timingSaveSrtButton = pillButton("Save SRT only", Color.WHITE, Color.BLACK, null)
        timingSaveSrtButton.isEnabled = false
        timingSaveSrtButton.setOnClickListener { onTimingSaveSrtClicked() }
        exportPanel.addView(timingSaveSrtButton, rowParams(dp(12)))
        timingCoverButton = pillButton("Save cover image", Color.WHITE, Color.BLACK, null)
        timingCoverButton.isEnabled = false
        timingCoverButton.setOnClickListener { onTimingCoverClicked() }
        exportPanel.addView(timingCoverButton, rowParams(dp(12)))

        // v0.9.7: intro cover image row — pick, duration, clear.
        val coverRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        coverRow.addView(TextView(this).apply {
            text = "Intro:"
            textSize = 15f
            setTextColor(Color.WHITE)
        })
        val coverPickButton =
            pillButton("Pick image", Color.WHITE, Color.BLACK, null).apply {
                textSize = 14f
                setPadding(dp(12), dp(6), dp(12), dp(6))
            }
        coverPickButton.setOnClickListener { pickCoverLauncher.launch("image/*") }
        coverRow.addView(
            coverPickButton,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginStart = dp(8) }
        )
        timingCoverDurationLabel = TextView(this).apply {
            text = coverDurationLabel()
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(dp(8), 0, dp(4), 0)
        }
        coverRow.addView(timingCoverDurationLabel)
        val coverMinusButton =
            pillButton("-", Color.rgb(30, 107, 74), Color.WHITE, null).apply {
                textSize = 15f
                setPadding(dp(12), dp(4), dp(12), dp(4))
            }
        coverMinusButton.setOnClickListener {
            timingCoverDurationUs =
                (timingCoverDurationUs - 500_000L).coerceAtLeast(500_000L)
            refreshCoverDurationLabel()
        }
        coverRow.addView(coverMinusButton)
        val coverPlusButton =
            pillButton("+", Color.rgb(30, 107, 74), Color.WHITE, null).apply {
                textSize = 15f
                setPadding(dp(12), dp(4), dp(12), dp(4))
            }
        coverPlusButton.setOnClickListener {
            timingCoverDurationUs =
                (timingCoverDurationUs + 500_000L).coerceAtMost(10_000_000L)
            refreshCoverDurationLabel()
        }
        coverRow.addView(coverPlusButton)
        val coverClearButton =
            pillButton("X", Color.rgb(120, 40, 40), Color.WHITE, null).apply {
                textSize = 14f
                setPadding(dp(12), dp(6), dp(12), dp(6))
            }
        coverClearButton.setOnClickListener {
            timingCoverImageUri = null
            if (::timingCoverPreview.isInitialized) {
                timingCoverPreview.visibility = View.GONE
            }
            timingStatusText.text = "Intro image removed."
        }
        coverRow.addView(
            coverClearButton,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginStart = dp(8) }
        )
        exportPanel.addView(coverRow, rowParams(dp(12)))
        timingProgressBar =
            ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = 0
            }
        exportPanel.addView(timingProgressBar, rowParams(dp(16)))
        timingStatusText = TextView(this).apply {
            text = "Pick a video and SRT."
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        exportPanel.addView(timingStatusText, rowParams(dp(8)))
        timingDownloadButton = pillButton("Download video", Color.WHITE, Color.BLACK, null)
        timingDownloadButton.visibility = View.GONE
        timingDownloadButton.setOnClickListener { onTimingDownloadClicked() }
        exportPanel.addView(timingDownloadButton, rowParams(dp(12)))
        panelBox.addView(exportPanel, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        timingToolPanels.add(exportPanel)
        timingExportPanel = exportPanel

        // v0.9.2: typing style bar — fixed above the toolbar so
        // size + color stay visible above the keyboard while typing
        // and apply live to the video preview. Shown only with the
        // Subtitle panel (see showTimingPanel).
        timingTypingBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.rgb(24, 24, 24))
            setPadding(dp(8), dp(8), dp(8), dp(8))
            visibility = View.GONE
        }
        for ((size, scale) in listOf(
            14f to 1f,
            18f to 1.2f,
            22f to 1.5f
        )) {
            val pill = Button(this).apply {
                text = "A"
                textSize = size
                isAllCaps = false
                setTextColor(Color.WHITE)
                setPadding(dp(12), dp(2), dp(12), dp(2))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = dp(6) }
            }
            pill.tag = scale
            pill.setOnClickListener {
                timingNewCueSizeScale = scale
                refreshTypingBar()
                onApplyCueStyle(null, scale)
            }
            timingTypingSizePills.add(pill)
            timingTypingBar.addView(pill)
        }
        timingTypingBar.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(1), dp(28)).apply {
                marginEnd = dp(8)
                marginStart = dp(2)
            }
            setBackgroundColor(Color.rgb(90, 90, 90))
        })
        for (color in timingSwatchColors) {
            val swatch = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(30), dp(30))
                    .apply { marginEnd = dp(8) }
                isClickable = true
                // NOT focusable: taps must not steal the text
                // field's focus, or the live typed preview hides.
                isFocusable = false
                setOnClickListener {
                    timingNewCueColor = color
                    refreshTypingBar()
                    onApplyCueStyle(color, null)
                }
            }
            swatch.tag = color
            timingTypingSwatches.add(swatch)
            timingTypingBar.addView(swatch)
        }
        refreshTypingBar()
        root.addView(timingTypingBar)

        // Bottom toolbar: one button per panel.
        val toolbarScroll = HorizontalScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
            isHorizontalScrollBarEnabled = false
        }
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        toolbarScroll.addView(toolbar)
        root.addView(toolbarScroll)
        for ((icon, label, panel) in listOf(
            Triple("🎬", "Video", videoPanel),
            Triple("💬", "Subtitle", subtitlePanel),
            Triple("✂️", "Trim", trimPanel),
            Triple("⏩", "Speed", speedPanel),
            Triple("🎵", "Music", musicPanel),
            Triple("🔤", "Title", textPanel),
            Triple("⬆️", "Export", exportPanel)
        )) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                // v0.9.5: compact cells — all 9 fit on screen, so
                // no toolbar button ever scrolls out of sight.
                minimumWidth = dp(40)
                setPadding(dp(4), dp(6), dp(4), dp(6))
                isClickable = true
                isFocusable = true
            }
            cell.addView(TextView(this).apply {
                text = icon
                textSize = 18f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
            })
            cell.addView(TextView(this).apply {
                text = label
                textSize = 10f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
            })
            cell.tag = panel
            cell.setOnClickListener { showTimingPanel(panel) }
            timingToolButtons.add(cell)
            toolbar.addView(cell)
        }

        // v0.7.0: Undo cell — one step back for split/delete edits.
        val undoCell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            minimumWidth = dp(40)
            setPadding(dp(4), dp(6), dp(4), dp(6))
            isClickable = true
            isFocusable = true
        }
        undoCell.addView(TextView(this).apply {
            text = "↩️"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        })
        undoCell.addView(TextView(this).apply {
            text = "Undo"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        })
        undoCell.setOnClickListener { undoLastEdit() }
        toolbar.addView(undoCell)

        // v0.8.1: Redo cell — one step forward for undone edits.
        val redoCell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            minimumWidth = dp(40)
            setPadding(dp(4), dp(6), dp(4), dp(6))
            isClickable = true
            isFocusable = true
        }
        redoCell.addView(TextView(this).apply {
            text = "↪️"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        })
        redoCell.addView(TextView(this).apply {
            text = "Redo"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        })
        redoCell.setOnClickListener { redoLastEdit() }
        toolbar.addView(redoCell)

        // v0.7.0: typed trim boxes write to the same segment
        // model when the user leaves the field.
        val applyOnBlur = View.OnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) applyTrimCutFields()
        }
        timingTrimStartField.onFocusChangeListener = applyOnBlur
        timingTrimEndField.onFocusChangeListener = applyOnBlur

        showTimingPanel(subtitlePanel)
        return root
    }

    /**
     * v0.6.22: size the preview video to its own aspect ratio and
     * center it in the preview frame (VN-style), so a portrait clip
     * is not stuck on one side with dead black space beside it.
     * Rotation metadata is honored, so a rotated clip is measured
     * by its displayed aspect, not its coded size.
     */
    private fun fitTimingPreview(videoW: Int, videoH: Int) {
        if (videoW <= 0 || videoH <= 0) return
        var w = videoW
        var h = videoH
        try {
            val uri = timingVideoUri
            if (uri != null) {
                val retr = MediaMetadataRetriever()
                retr.setDataSource(this, uri)
                val rot = retr.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION
                )?.toIntOrNull() ?: 0
                retr.release()
                if (rot == 90 || rot == 270) {
                    val t = w
                    w = h
                    h = t
                }
            }
        } catch (e: Exception) {
        }
        val frameW = timingPreviewFrame.width
        val frameH = timingPreviewFrame.height
        if (frameW <= 0 || frameH <= 0) return
        val aspect = w.toFloat() / h.toFloat()
        var viewW = frameW
        var viewH = (frameW / aspect).toInt()
        if (viewH > frameH) {
            viewH = frameH
            viewW = (frameH * aspect).toInt()
        }
        timingPreviewVideo.layoutParams =
            FrameLayout.LayoutParams(viewW, viewH, Gravity.CENTER)
        // v0.9.3: remember the picture rect inside the frame; the
        // title + subtitle lines anchor to the picture (not the
        // letterbox) at their dragged positions.
        timingPicLeft = (frameW - viewW) / 2
        timingPicTop = (frameH - viewH) / 2
        timingPicW = viewW
        timingPicH = viewH
        if (::timingCueText.isInitialized) timingCueText.maxWidth = viewW
        if (::timingTopTextPreview.isInitialized) {
            timingTopTextPreview.maxWidth = viewW
        }
        positionTimingTitle()
        repositionCueTextNow()
        if (::timingOverlayImage.isInitialized) positionTimingOverlay()
    }

    /** v0.9.3: places the live subtitle line at the given fractions
     * of the video picture (x = text center, y = text bottom edge).
     * Skipped while a drag owns the view; a zero-size view retries
     * on the next poller tick. */
    private fun placeCueText(xFrac: Float, yFrac: Float) {
        if (timingTextDragging) return
        if (!::timingCueText.isInitialized || timingPicW <= 0) return
        timingCueText.post {
            if (timingTextDragging) return@post
            val w = timingCueText.width
            val h = timingCueText.height
            if (w <= 0 || h <= 0) return@post
            val cx = timingPicLeft + xFrac * timingPicW
            val bottom = timingPicTop + yFrac * timingPicH
            val left = (cx - w / 2f).toInt()
                .coerceIn(0, (timingPreviewFrame.width - w).coerceAtLeast(0))
            val top = (bottom - h).toInt()
                .coerceIn(0, (timingPreviewFrame.height - h).coerceAtLeast(0))
            val lp = timingCueText.layoutParams as FrameLayout.LayoutParams
            if (lp.leftMargin != left || lp.topMargin != top ||
                lp.gravity != (Gravity.TOP or Gravity.START)
            ) {
                lp.leftMargin = left
                lp.topMargin = top
                lp.gravity = Gravity.TOP or Gravity.START
                timingCueText.layoutParams = lp
            }
        }
    }

    /** v0.9.3: repositions the live subtitle line from the cue
     * active at the playhead (used when the picture rect changes). */
    private fun repositionCueTextNow() {
        if (!::timingPreviewVideo.isInitialized) return
        val posUs = try {
            timingPreviewVideo.currentPosition.toLong() * 1_000L
        } catch (e: Exception) {
            return
        }
        val shifted = SrtParser.shifted(timingCues, timingShiftUs)
        val active = shifted.firstOrNull { posUs in it.startUs until it.endUs }
        placeCueText(
            active?.xFrac ?: timingNewCueXFrac,
            active?.yFrac ?: timingNewCueYFrac
        )
    }

    /** v0.9.3: places the title line at its dragged position
     * (fractions of the video picture). */
    private fun positionTimingTitle() {
        if (timingTextDragging) return
        if (!::timingTopTextPreview.isInitialized || timingPicW <= 0) return
        timingTopTextPreview.post {
            if (timingTextDragging) return@post
            val w = timingTopTextPreview.width
            val h = timingTopTextPreview.height
            if (w <= 0 || h <= 0) return@post
            val cx = timingPicLeft + timingTitleXFrac * timingPicW
            val top = timingPicTop + timingTitleTopFrac * timingPicH
            val left = (cx - w / 2f).toInt()
                .coerceIn(0, (timingPreviewFrame.width - w).coerceAtLeast(0))
            val topInt = top.toInt()
                .coerceIn(0, (timingPreviewFrame.height - h).coerceAtLeast(0))
            val lp = timingTopTextPreview.layoutParams
                as FrameLayout.LayoutParams
            if (lp.leftMargin != left || lp.topMargin != topInt ||
                lp.gravity != (Gravity.TOP or Gravity.START)
            ) {
                lp.leftMargin = left
                lp.topMargin = topInt
                lp.gravity = Gravity.TOP or Gravity.START
                timingTopTextPreview.layoutParams = lp
            }
        }
    }

    /** v0.9.3: VN-style text-box drag — drag the subtitle line or
     * the title on the preview to move it; the position is stored
     * on the cue (undoable) or the title, and honored by the burn.
     * Dragging the typed preview moves the default for new cues. */
    private fun attachPreviewTextDrag(view: TextView, isTitle: Boolean) {
        var downX = 0f
        var downY = 0f
        var startLeft = 0
        var startTop = 0
        var moved = false
        var pushed = false
        var cueIndex = -1
        var typing = false
        // v0.9.5: tap-only mode — the box has nothing to drag
        // (empty / no cue), but a tap must still open the editor
        // so the keyboard comes up for writing.
        var tapOnly = false
        view.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (timingPicW <= 0 ||
                        (isTitle && view.text.isNullOrEmpty())
                    ) {
                        false
                    } else {
                        typing = !isTitle &&
                            ::timingManualTextField.isInitialized &&
                            timingManualTextField.hasFocus() &&
                            timingManualTextField.text.toString().trim()
                                .isNotEmpty()
                        cueIndex = if (isTitle || typing) -1
                        else resolveDragCueIndex()
                        tapOnly = !isTitle && !typing && cueIndex < 0
                        downX = ev.rawX
                        downY = ev.rawY
                        val lp = v.layoutParams
                            as FrameLayout.LayoutParams
                        startLeft = lp.leftMargin
                        startTop = lp.topMargin
                        moved = false
                        pushed = false
                        v.parent.requestDisallowInterceptTouchEvent(true)
                        true
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (tapOnly) {
                        true
                    } else {
                    val dx = ev.rawX - downX
                    val dy = ev.rawY - downY
                    val slop = dp(6).toFloat()
                    if (!moved && dx * dx + dy * dy < slop * slop) {
                        true
                    } else {
                        if (!moved) {
                            moved = true
                            timingTextDragging = true
                            if (cueIndex >= 0 && !pushed) {
                                pushUndoSnapshot()
                                pushed = true
                            }
                        }
                        val lp = v.layoutParams as FrameLayout.LayoutParams
                        val maxLeft =
                            (timingPreviewFrame.width - v.width).coerceAtLeast(0)
                        val maxTop =
                            (timingPreviewFrame.height - v.height).coerceAtLeast(0)
                        lp.leftMargin =
                            (startLeft + dx.toInt()).coerceIn(0, maxLeft)
                        lp.topMargin =
                            (startTop + dy.toInt()).coerceIn(0, maxTop)
                        v.layoutParams = lp
                        applyDragPosition(v, isTitle, cueIndex, typing)
                        true
                    }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    // v0.9.4: a tap (no drag) opens the text editor
                    // for this box, CapCut-style.
                    val wasTap = !moved &&
                        ev.actionMasked == MotionEvent.ACTION_UP
                    timingTextDragging = false
                    if (::timingGuideV.isInitialized) {
                        timingGuideV.visibility = View.GONE
                    }
                    if (::timingGuideH.isInitialized) {
                        timingGuideH.visibility = View.GONE
                    }
                    v.parent.requestDisallowInterceptTouchEvent(false)
                    if (wasTap) openTextEditorForTap(isTitle)
                    true
                }
                else -> false
            }
        }
    }

    /** v0.9.3: stores the dragged box position (fractions of the
     * picture rect) on the cue, the new-cue default, or the title,
     * and shows the magenta center guides when aligned. */
    private fun applyDragPosition(
        view: View, isTitle: Boolean, cueIndex: Int, typing: Boolean
    ) {
        if (timingPicW <= 0 || timingPicH <= 0) return
        val lp = view.layoutParams as FrameLayout.LayoutParams
        val cx = (lp.leftMargin + view.width / 2f - timingPicLeft) / timingPicW
        val cxF = cx.coerceIn(0.05f, 0.95f)
        if (isTitle) {
            timingTitleXFrac = cxF
            timingTitleTopFrac =
                ((lp.topMargin - timingPicTop).toFloat() / timingPicH)
                    .coerceIn(0f, 0.9f)
        } else {
            val yF = ((lp.topMargin + view.height - timingPicTop).toFloat() /
                timingPicH).coerceIn(0.08f, 0.98f)
            if (typing) {
                timingNewCueXFrac = cxF
                timingNewCueYFrac = yF
            } else if (cueIndex in timingCues.indices) {
                val list = timingCues.toMutableList()
                list[cueIndex] = list[cueIndex].copy(xFrac = cxF, yFrac = yF)
                timingCues = list
            }
        }
        if (::timingGuideV.isInitialized) {
            timingGuideV.visibility =
                if (kotlin.math.abs(cx - 0.5f) < 0.02f) View.VISIBLE
                else View.GONE
        }
        if (::timingGuideH.isInitialized) {
            val centerY = lp.topMargin + view.height / 2f
            val frameCenterY = timingPreviewFrame.height / 2f
            timingGuideH.visibility =
                if (kotlin.math.abs(centerY - frameCenterY) < dp(8)) View.VISIBLE
                else View.GONE
        }
    }

    /** v0.9.3: stored-space index of the cue a preview drag should
     * move — the selected cue if one is selected, else the cue
     * active at the playhead, else -1. */
    private fun resolveDragCueIndex(): Int {
        val shifted = SrtParser.shifted(timingCues, timingShiftUs)
        val target = if (selectedTrack == 3 && selectedIndex in shifted.indices) {
            shifted[selectedIndex]
        } else {
            val posUs = try {
                timingPreviewVideo.currentPosition.toLong() * 1_000L
            } catch (e: Exception) {
                -1L
            }
            if (posUs < 0L) null
            else shifted.firstOrNull { posUs in it.startUs until it.endUs }
        } ?: return -1
        val stored = target.copy(
            startUs = target.startUs - timingShiftUs,
            endUs = target.endUs - timingShiftUs
        )
        return timingCues.indexOf(stored)
    }

    // ---- v0.9.4: sticker/overlay row, Volume panel, rail mute ----

    /** Adds a 3-second sticker clip at the playhead (VN default). */
    private fun onOverlayPhotoPicked(uri: Uri) {
        val durationUs = timingVideoDurationMs * 1_000L
        if (durationUs <= 0L) {
            timingStatusText.text = "Pick a video first."
            return
        }
        val p = playheadUs().coerceIn(0L, durationUs)
        var start = p
        var end = minOf(p + 3_000_000L, durationUs)
        if (end - start < 500_000L) {
            end = durationUs
            start = (durationUs - 3_000_000L).coerceAtLeast(0L)
        }
        pushUndoSnapshot()
        timingOverlayClips.add(OverlayClip(uri, start, end))
        timingOverlayClips.sortBy { it.startUs }
        val index = timingOverlayClips.indexOfFirst {
            it.uri == uri && it.startUs == start
        }
        refreshEditorModels()
        refreshTimingOverlay()
        setSelection(4, index)
        updateTimingEnabled()
        timingStatusText.text = "Sticker added — drag it on the video to move it."
    }

    /** Applies a timeline drag of a sticker clip (move / stretch). */
    private fun onOverlayClipMoved(index: Int, newStartUs: Long, newEndUs: Long) {
        if (index !in timingOverlayClips.indices) return
        val orig = timingOverlayClips[index]
        val moved = orig.copy(startUs = newStartUs, endUs = newEndUs)
        if (moved == orig) return
        pushUndoSnapshot()
        timingOverlayClips[index] = moved
        refreshEditorModels()
        setSelection(4, index)
    }

    /** Overlay ranges on the export timeline (segments, speed) —
     * mirrors burnCues so stickers stay in sync with subtitles. */
    private fun burnPhotoOverlays(cutRequested: Boolean, shiftUs: Long = 0L): List<PhotoOverlay> {
        if (timingOverlayClips.isEmpty()) return emptyList()
        val segments = currentSegmentsForCues()
        if (segments.isEmpty()) return emptyList()
        val offsets = ArrayList<Long>(segments.size)
        var acc = 0L
        for ((s, e) in segments) {
            offsets.add(acc - s)
            acc += (e - s)
        }
        val out = mutableListOf<PhotoOverlay>()
        for (clip in timingOverlayClips) {
            for (i in segments.indices) {
                val (s, e) = segments[i]
                if (clip.endUs <= s || clip.startUs >= e) continue
                var start = maxOf(clip.startUs, s) + offsets[i]
                var end = minOf(clip.endUs, e) + offsets[i]
                if (end <= start) continue
                if (cutRequested && timingSpeed != 1f && timingSpeed > 0f) {
                    start = (start / timingSpeed).toLong()
                    end = (end / timingSpeed).toLong()
                }
                if (end <= start) continue
                out.add(
                    PhotoOverlay(
                        applicationContext, clip.uri, start + shiftUs, end + shiftUs,
                        clip.xFrac, clip.yFrac, clip.scale
                    )
                )
            }
        }
        return out
    }

    /** The sticker shown on the preview: the selected clip, else
     * the clip active at the playhead. */
    private fun visibleOverlayClip(): OverlayClip? {
        if (timingVideoUri == null) return null
        if (selectedTrack == 4 && selectedIndex in timingOverlayClips.indices) {
            return timingOverlayClips[selectedIndex]
        }
        val posUs = playheadUs()
        return timingOverlayClips.firstOrNull {
            posUs in it.startUs until it.endUs
        }
    }

    /** Shows/hides the preview sticker for the current playhead. */
    private fun refreshTimingOverlay() {
        if (!::timingOverlayImage.isInitialized) return
        val clip = visibleOverlayClip()
        if (clip == null) {
            timingOverlayImage.visibility = View.GONE
            timingOverlayShownUri = null
            return
        }
        if (timingOverlayShownUri != clip.uri) {
            timingOverlayShownUri = clip.uri
            ensureOverlayBitmap(clip.uri) { bmp ->
                if (timingOverlayShownUri != clip.uri) return@ensureOverlayBitmap
                if (!::timingOverlayImage.isInitialized) return@ensureOverlayBitmap
                timingOverlayAspect =
                    bmp.width.toFloat() / bmp.height.coerceAtLeast(1)
                timingOverlayImage.setImageBitmap(bmp)
                timingOverlayImage.visibility = View.VISIBLE
                positionTimingOverlay()
            }
        } else if (timingOverlayImage.visibility != View.VISIBLE) {
            timingOverlayImage.visibility = View.VISIBLE
        }
        if (!timingOverlayDragging) positionTimingOverlay()
    }

    /** Places the preview sticker at its clip's fractions of the
     * video picture (center + width scale). */
    private fun positionTimingOverlay() {
        positionTimingOverlay(visibleOverlayClip())
    }

    private fun positionTimingOverlay(clip: OverlayClip?) {
        if (!::timingOverlayImage.isInitialized || timingPicW <= 0) return
        if (clip == null) return
        val w = (clip.scale * timingPicW).toInt().coerceAtLeast(dp(24))
        val h = (w / timingOverlayAspect.coerceAtLeast(0.1f)).toInt()
            .coerceAtLeast(dp(24))
        val cx = timingPicLeft + clip.xFrac * timingPicW
        val cy = timingPicTop + clip.yFrac * timingPicH
        val maxLeft = (timingPreviewFrame.width - w).coerceAtLeast(0)
        val maxTop = (timingPreviewFrame.height - h).coerceAtLeast(0)
        val left = (cx - w / 2f).toInt().coerceIn(0, maxLeft)
        val top = (cy - h / 2f).toInt().coerceIn(0, maxTop)
        val lp = timingOverlayImage.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w || lp.height != h ||
            lp.leftMargin != left || lp.topMargin != top
        ) {
            lp.width = w
            lp.height = h
            lp.leftMargin = left
            lp.topMargin = top
            lp.gravity = Gravity.TOP or Gravity.START
            timingOverlayImage.layoutParams = lp
        }
    }

    /** Decodes a sticker bitmap (sampled to ≤1024px, cached, capped
     * at 6). The callback always runs on the main thread. */
    private fun ensureOverlayBitmap(uri: Uri, onLoaded: (Bitmap) -> Unit) {
        val cached = timingOverlayBitmaps[uri]
        if (cached != null) {
            onLoaded(cached)
            return
        }
        if (timingOverlayLoading.contains(uri)) return
        timingOverlayLoading.add(uri)
        Thread {
            try {
                val bounds = BitmapFactory.Options().apply {
                    inJustDecodeBounds = true
                }
                contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, bounds)
                }
                var sample = 1
                while ((bounds.outWidth / sample > 1024 ||
                        bounds.outHeight / sample > 1024) && sample < 64
                ) {
                    sample *= 2
                }
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, opts)
                }
                runOnUiThread {
                    timingOverlayLoading.remove(uri)
                    if (bmp != null) {
                        timingOverlayBitmaps[uri] = bmp
                        while (timingOverlayBitmaps.size > 6) {
                            val eldest = timingOverlayBitmaps.keys.first()
                            if (eldest == uri) break
                            timingOverlayBitmaps.remove(eldest)
                        }
                        onLoaded(bmp)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { timingOverlayLoading.remove(uri) }
            }
        }.start()
    }

    /** Drag (one finger) + pinch-scale (two fingers) for the preview
     * sticker, VN/CapCut-style. Position/scale write live to the
     * clip; the first move/scale takes one undo snapshot. */
    private fun attachOverlayDrag(view: ImageView) {
        var downX = 0f
        var downY = 0f
        var startLeft = 0
        var startTop = 0
        var moved = false
        var pushed = false
        var clipIndex = -1
        var scaling = false
        var startScale = 0.5f
        var startSpan = 0f
        val scaleDetector = ScaleGestureDetector(
            this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                    if (clipIndex !in timingOverlayClips.indices) return false
                    scaling = true
                    timingOverlayDragging = true
                    if (!pushed) {
                        pushUndoSnapshot()
                        pushed = true
                    }
                    startScale = timingOverlayClips[clipIndex].scale
                    startSpan = detector.currentSpan
                    return true
                }

                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    if (!scaling || clipIndex !in timingOverlayClips.indices) {
                        return false
                    }
                    if (startSpan <= 0f) return false
                    val factor = detector.currentSpan / startSpan
                    val newScale = (startScale * factor).coerceIn(0.1f, 1.5f)
                    val list = timingOverlayClips.toMutableList()
                    list[clipIndex] = list[clipIndex].copy(scale = newScale)
                    timingOverlayClips = list
                    positionTimingOverlay(list[clipIndex])
                    return true
                }

                override fun onScaleEnd(detector: ScaleGestureDetector) {
                    scaling = false
                }
            }
        )
        view.setOnTouchListener { v, ev ->
            scaleDetector.onTouchEvent(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    clipIndex = if (selectedTrack == 4 &&
                        selectedIndex in timingOverlayClips.indices
                    ) {
                        selectedIndex
                    } else {
                        val posUs = playheadUs()
                        timingOverlayClips.indexOfFirst {
                            posUs in it.startUs until it.endUs
                        }
                    }
                    if (clipIndex < 0 || timingPicW <= 0) {
                        false
                    } else {
                        downX = ev.rawX
                        downY = ev.rawY
                        val lp = v.layoutParams as FrameLayout.LayoutParams
                        startLeft = lp.leftMargin
                        startTop = lp.topMargin
                        moved = false
                        pushed = false
                        scaling = false
                        v.parent.requestDisallowInterceptTouchEvent(true)
                        true
                    }
                }
                MotionEvent.ACTION_POINTER_DOWN,
                MotionEvent.ACTION_POINTER_UP -> true
                MotionEvent.ACTION_MOVE -> {
                    if (scaling || ev.pointerCount > 1) {
                        true
                    } else {
                        val dx = ev.rawX - downX
                        val dy = ev.rawY - downY
                        val slop = dp(6).toFloat()
                        if (!moved && dx * dx + dy * dy < slop * slop) {
                            true
                        } else {
                            if (!moved) {
                                moved = true
                                timingOverlayDragging = true
                                if (!pushed) {
                                    pushUndoSnapshot()
                                    pushed = true
                                }
                            }
                            val lp =
                                v.layoutParams as FrameLayout.LayoutParams
                            val maxLeft =
                                (timingPreviewFrame.width - v.width)
                                    .coerceAtLeast(0)
                            val maxTop =
                                (timingPreviewFrame.height - v.height)
                                    .coerceAtLeast(0)
                            lp.leftMargin =
                                (startLeft + dx.toInt()).coerceIn(0, maxLeft)
                            lp.topMargin =
                                (startTop + dy.toInt()).coerceIn(0, maxTop)
                            v.layoutParams = lp
                            applyOverlayDragPosition(v, clipIndex)
                            true
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    timingOverlayDragging = false
                    if (::timingGuideV.isInitialized) {
                        timingGuideV.visibility = View.GONE
                    }
                    if (::timingGuideH.isInitialized) {
                        timingGuideH.visibility = View.GONE
                    }
                    v.parent.requestDisallowInterceptTouchEvent(false)
                    true
                }
                else -> false
            }
        }
    }

    /** Stores the dragged sticker's center fractions on its clip and
     * shows the magenta center guides when aligned. */
    private fun applyOverlayDragPosition(view: View, clipIndex: Int) {
        if (timingPicW <= 0 || timingPicH <= 0) return
        if (clipIndex !in timingOverlayClips.indices) return
        val lp = view.layoutParams as FrameLayout.LayoutParams
        val cx = (lp.leftMargin + view.width / 2f - timingPicLeft) / timingPicW
        val cy = (lp.topMargin + view.height / 2f - timingPicTop) / timingPicH
        val list = timingOverlayClips.toMutableList()
        list[clipIndex] = list[clipIndex].copy(
            xFrac = cx.coerceIn(0.05f, 0.95f),
            yFrac = cy.coerceIn(0.05f, 0.95f)
        )
        timingOverlayClips = list
        if (::timingGuideV.isInitialized) {
            timingGuideV.visibility =
                if (kotlin.math.abs(cx - 0.5f) < 0.02f) View.VISIBLE else View.GONE
        }
        if (::timingGuideH.isInitialized) {
            val frameCenterY = timingPreviewFrame.height / 2f
            val centerY = lp.topMargin + view.height / 2f
            timingGuideH.visibility =
                if (kotlin.math.abs(centerY - frameCenterY) < dp(8)) {
                    View.VISIBLE
                } else {
                    View.GONE
                }
        }
    }

    /** Swaps the white box border on/off the preview subtitle line
     * (CapCut text-box style); no-op when unchanged. */
    private fun refreshCueTextBorder(bordered: Boolean) {
        if (!::timingCueText.isInitialized) return
        if (bordered == timingCueTextBordered) return
        timingCueTextBordered = bordered
        timingCueText.background = GradientDrawable().apply {
            setColor(Color.argb(120, 0, 0, 0))
            if (bordered) setStroke(dp(2), Color.WHITE)
        }
    }

    /** Tap on a preview text box opens its editor (CapCut style). */
    private fun openTextEditorForTap(isTitle: Boolean) {
        if (isTitle) {
            if (::timingTitlePanel.isInitialized) {
                showTimingPanel(timingTitlePanel)
            }
            if (::timingTopTextField.isInitialized) {
                timingTopTextField.requestFocus()
                showKeyboardFor(timingTopTextField)
            }
        } else {
            if (::timingSubtitlePanel.isInitialized) {
                showTimingPanel(timingSubtitlePanel)
            }
            if (::timingManualTextField.isInitialized) {
                timingManualTextField.requestFocus()
                showKeyboardFor(timingManualTextField)
            }
        }
    }

    private fun showKeyboardFor(view: View) {
        view.post {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    /** Opens the Volume panel for the video (1) or music (2) track.
     * v0.9.7: with a music clip selected, the panel edits that clip's
     * own volume instead of the whole track's. */
    private fun openVolumePanel(target: Int) {
        timingVolumeTarget = target
        timingVolumeClipIndex = if (target == 2 && selectedTrack == 2 &&
            selectedIndex in timingMusicClips.indices
        ) {
            pushUndoSnapshot()
            selectedIndex
        } else {
            -1
        }
        val volume = if (timingVolumeClipIndex >= 0) {
            timingMusicClips[timingVolumeClipIndex].volume
        } else if (target == 2) {
            timingMusicVolume
        } else {
            timingVideoVolume
        }
        if (::timingVolumeSlider.isInitialized) {
            timingVolumeSlider.progress =
                (volume * 1000f).toInt().coerceIn(0, 1000)
        }
        if (::timingVolumeValueLabel.isInitialized) {
            timingVolumeValueLabel.text = "Volume: ${(volume * 1000f).toInt()}"
        }
        if (::timingVolumePanel.isInitialized) {
            showTimingPanel(timingVolumePanel)
        }
    }

    /** Rail mute toggle: checkbox + icon + preview volume in step. */
    private fun setRailMute(muted: Boolean) {
        if (::timingMuteCheck.isInitialized) {
            timingMuteCheck.isChecked = muted
        }
        if (::timingRailMuteButton.isInitialized) {
            timingRailMuteButton.text = if (muted) "🔇" else "🔊"
        }
        applyTimingPreviewVolume()
    }

    /** Preview volume: 0 when muted, else the video volume. */
    private fun applyTimingPreviewVolume() {
        val muted = ::timingMuteCheck.isInitialized && timingMuteCheck.isChecked
        val vol = if (muted) 0f else timingVideoVolume
        timingMediaPlayer?.setVolume(vol, vol)
    }

    /** v0.9.8: the preview player for the added song, created
     * lazily and rebuilt when the picked song changes. Prepared
     * async so the UI never blocks on a slow file. */
    private fun ensureTimingMusicPlayer(): MediaPlayer? {
        val uri = timingMusicUri ?: run {
            releaseTimingMusicPlayer()
            return null
        }
        val existing = timingMusicPlayer
        if (existing != null && timingMusicPlayerUri == uri) return existing
        releaseTimingMusicPlayer()
        return try {
            MediaPlayer().apply {
                setDataSource(this@MainActivity, uri)
                setOnPreparedListener { timingMusicPlayerReady = true }
                setOnErrorListener { _, _, _ ->
                    timingMusicPlayerReady = false
                    true
                }
                prepareAsync()
                timingMusicPlayer = this
                timingMusicPlayerUri = uri
                timingMusicPlayerReady = false
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun pauseTimingMusicPreview() {
        try {
            timingMusicPlayer?.let { if (it.isPlaying) it.pause() }
        } catch (e: Exception) {
        }
    }

    private fun releaseTimingMusicPlayer() {
        try {
            timingMusicPlayer?.release()
        } catch (e: Exception) {
        }
        timingMusicPlayer = null
        timingMusicPlayerUri = null
        timingMusicPlayerReady = false
    }

    /** v0.9.8: called from the preview poller. Plays the song
     * only while the video preview is playing and the playhead
     * sits inside a music clip, at the clip's position inside
     * the song (looping like the export), at clip x music
     * volume. Mute affects the original audio only, as in the
     * export, so the song still previews while muted. */
    private fun syncTimingMusicPreview() {
        try {
            val player = ensureTimingMusicPlayer() ?: return
            if (!timingMusicPlayerReady) return
            val songDurUs = timingMusicDurationMs * 1_000L
            if (songDurUs <= 0L) {
                pauseTimingMusicPreview()
                return
            }
            if (!timingPreviewVideo.isPlaying) {
                pauseTimingMusicPreview()
                return
            }
            val posUs = playheadUs()
            val clip = timingMusicClips.sortedBy { it.startUs }
                .firstOrNull { posUs >= it.startUs && posUs < it.endUs }
            if (clip == null) {
                pauseTimingMusicPreview()
                return
            }
            // Same looping as the export: the song restarts
            // inside a clip that runs past the end of the file.
            val expectedUs =
                (clip.offsetUs + (posUs - clip.startUs)) % songDurUs
            val vol = (timingMusicVolume * clip.volume).coerceIn(0f, 1f)
            player.setVolume(vol, vol)
            val expectedMs = (expectedUs / 1_000L).toInt()
            if (!player.isPlaying) {
                player.seekTo(expectedMs)
                player.start()
            } else {
                val driftMs =
                    kotlin.math.abs(player.currentPosition - expectedMs)
                if (driftMs > 400) player.seekTo(expectedMs)
            }
        } catch (e: Exception) {
            // Preview music must never break the poller.
        }
    }

    /** Shows one editor tool panel and highlights its toolbar button. */
    /** v0.9.0: hide every tool panel (Done button). */
    private fun hideTimingPanels() {
        for (p in timingToolPanels) p.visibility = View.GONE
        for (b in timingToolButtons) b.background = null
    }

    /** v0.9.0: template row highlight follows the chosen size. */
    /** v0.9.2: typing-bar highlight follows the chosen size/color. */
    private fun refreshTypingBar() {
        for (pill in timingTypingSizePills) {
            val selected = (pill.tag as? Float) == timingNewCueSizeScale
            pill.background = pillBg(
                if (selected) Color.rgb(30, 107, 74) else Color.rgb(42, 42, 42),
                if (selected) Color.rgb(76, 175, 125) else null,
                2
            )
        }
        for (swatch in timingTypingSwatches) {
            val color = swatch.tag as? Int ?: Color.WHITE
            val selected = color == timingNewCueColor
            swatch.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
                if (selected) setStroke(dp(3), Color.WHITE)
            }
        }
    }

    /** v0.9.0: apply a style to the selected subtitle (undoable).
     * With no selection it only sets the new-cue style, which the
     * template/swatch tap already did. */
    private fun onApplyCueStyle(color: Int?, sizeScale: Float?) {
        if (selectedTrack != 3) return
        val shifted = SrtParser.shifted(timingCues, timingShiftUs)
        if (selectedIndex !in shifted.indices) return
        val cue = shifted[selectedIndex]
        val styled = cue.copy(
            color = color ?: cue.color,
            sizeScale = sizeScale ?: cue.sizeScale
        )
        if (styled == cue) return
        pushUndoSnapshot()
        val updated = shifted.toMutableList()
        updated[selectedIndex] = styled
        val stored = SrtParser.shifted(updated, -timingShiftUs)
            .sortedBy { it.startUs }
        timingCues = stored
        val storedStyled = styled.copy(
            startUs = styled.startUs - timingShiftUs,
            endUs = styled.endUs - timingShiftUs
        )
        refreshEditorModels()
        setSelection(3, stored.indexOf(storedStyled))
    }

    /** v0.9.0: jump the playhead by deltaMs (transport skip buttons). */
    private fun skipTimingPreview(deltaMs: Long) {
        if (timingVideoUri == null) return
        val pos = try {
            timingPreviewVideo.currentPosition.toLong()
        } catch (e: Exception) {
            return
        }
        val target = (pos + deltaMs).coerceIn(0L, timingVideoDurationMs)
        seekTimingPreview(target.toInt())
    }

    private fun showTimingPanel(panel: View) {
        for (p in timingToolPanels) {
            p.visibility = if (p === panel) View.VISIBLE else View.GONE
        }
        for (b in timingToolButtons) {
            b.background = if (b.tag === panel) {
                pillBg(Color.rgb(30, 107, 74), Color.rgb(76, 175, 125), 2)
            } else {
                null
            }
        }
        // v0.9.2: the typing style bar shows with the Subtitle panel.
        if (::timingTypingBar.isInitialized &&
            ::timingSubtitlePanel.isInitialized
        ) {
            timingTypingBar.visibility =
                if (panel === timingSubtitlePanel) View.VISIBLE else View.GONE
        }
    }

    /** The small fixed-width label at the left of a timeline track. */
    private fun trackLabel(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 16f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        layoutParams = LinearLayout.LayoutParams(
            dp(36), ViewGroup.LayoutParams.MATCH_PARENT
        )
    }

    /** The 4 voice-option buttons; shared selection state across screens. */
    /** Voice picker shared by the TTS and voiceover screens.
     * The auto button (AI splits voices by character) is offered on both;
     * prompt-video always uses auto mode (server v28+) with no picker. */
    private fun buildVoicePicker(showAuto: Boolean): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (showAuto) {
            val auto = pillButton(
                "AI က ဇာတ်ကောင် အလိုက် ခွဲပေးမယ်", Color.WHITE, Color.BLACK, null
            )
            auto.textSize = 16f
            auto.setOnClickListener {
                autoVoice = true
                // Auto split is edge-only; a Gemini style would not apply.
                ttsEngine = "edge"
                ttsStyle = "natural"
                refreshStyleButtons()
                refreshVoiceButtons()
            }
            autoVoiceButtons.add(auto)
            box.addView(auto, rowParams(0))
        }
        for ((index, option) in voiceOptions.withIndex()) {
            val b = pillButton(option.label, Color.WHITE, Color.BLACK, null)
            b.textSize = 16f
            b.setOnClickListener {
                selectedVoiceIndex = index
                autoVoice = false
                refreshVoiceButtons()
            }
            voiceOptionButtons.add(b to index)
            box.addView(b, rowParams(dp(10)))
        }
        refreshVoiceButtons()
        return box
    }

    private fun refreshVoiceButtons() {
        for (button in autoVoiceButtons) {
            button.background = pillBg(
                if (autoVoice) Color.rgb(30, 107, 74) else Color.WHITE,
                if (autoVoice) Color.rgb(76, 175, 125) else null,
                2
            )
            button.setTextColor(if (autoVoice) Color.WHITE else Color.BLACK)
        }
        for ((button, index) in voiceOptionButtons) {
            val selected = !autoVoice && index == selectedVoiceIndex
            button.background = pillBg(
                if (selected) Color.rgb(30, 107, 74) else Color.WHITE,
                if (selected) Color.rgb(76, 175, 125) else null,
                2
            )
            button.setTextColor(if (selected) Color.WHITE else Color.BLACK)
        }
    }

    /** Narration style picker (TTS screen only, v0.6.5). */
    private fun buildStylePicker(): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val styles = listOf(
            "edge" to "ပုံမှန် အသံ",
            "natural" to "သဘာဝ အသံနိမ့်အမြင့်",
            "spooky" to "သရဲ ဇာတ်လမ်း အသံ"
        )
        for ((key, label) in styles) {
            val b = pillButton(label, Color.WHITE, Color.BLACK, null)
            b.textSize = 16f
            b.setOnClickListener {
                if (key == "edge") {
                    ttsEngine = "edge"
                    ttsStyle = "natural"
                } else {
                    ttsEngine = "gemini"
                    ttsStyle = key
                    // Gemini is single-voice; the auto split is edge-only.
                    autoVoice = false
                    refreshVoiceButtons()
                }
                refreshStyleButtons()
            }
            styleButtons.add(b to key)
            box.addView(b, rowParams(dp(10)))
        }
        refreshStyleButtons()
        return box
    }

    private fun refreshStyleButtons() {
        val current = if (ttsEngine == "edge") "edge" else ttsStyle
        for ((button, key) in styleButtons) {
            val selected = key == current
            button.background = pillBg(
                if (selected) Color.rgb(30, 107, 74) else Color.WHITE,
                if (selected) Color.rgb(76, 175, 125) else null,
                2
            )
            button.setTextColor(if (selected) Color.WHITE else Color.BLACK)
        }
    }

    private fun backLink(): TextView = TextView(this).apply {
        text = "← Menu သို့ ပြန်သွားမယ်"
        textSize = 15f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(12), dp(12), dp(12))
        setOnClickListener { showScreen(menuScreen) }
    }

    // ---------- actions ----------

    private fun onLoginClicked() {
        val key = keyField.text.toString().trim()
        if (key.isEmpty()) {
            loginStatus.text = "API Key ထည့်ပါ။"
            return
        }
        // Hide the keyboard: it used to stay open over the menu screen.
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(keyField.windowToken, 0)
        apiKey = key
        prefs.edit().putString("gemini_api_key", key).apply()
        loginStatus.text = ""
        showScreen(menuScreen)
    }

    private fun openWork(targetMode: Int) {
        mode = targetMode
        if (mode == modeSrt) {
            workTitle.text = "SRT သီးသန့်ထုတ်ရန်"
            makeButton.text = "SRT ထုတ်မယ်"
        } else {
            workTitle.text = "Video ကို မြန်မာစာတန်းထိုးပေးရန်"
            makeButton.text = "စာတန်းထိုးထားသော Video လုပ်မယ်"
        }
        // v0.9.9: the cover toggle only matters for the burn path.
        workCoverCheck.visibility =
            if (mode == modeSrt) View.GONE else View.VISIBLE
        setStatus("Video ရွေးပါ။")
        progressBar.progress = 0
        updateMakeEnabled()
        showScreen(workScreen)
    }

    private fun onMakeClicked() {
        val video = videoUri ?: return
        setBusy(true)
        progressBar.progress = 0
        workDownloadButton.visibility = View.GONE
        if (::workPreviewVideo.isInitialized) {
            workPreviewVideo.stopPlayback()
            workPreviewVideo.visibility = View.GONE
        }
        workLastOutput = null
        workLastSrt = null
        setStatus("Video တင်နေတယ်…")
        Thread {
            try {
                val fileName = video.lastPathSegment ?: "video.mp4"
                val client = TranscribeClient(contentResolver)
                val srtText = when (val res = client.submit(video, fileName, apiKey) { pct ->
                    runOnUiThread {
                        progressBar.isIndeterminate = false
                        progressBar.progress = pct
                        setStatus("Video တင်နေတယ်… $pct%")
                    }
                }) {
                    is TranscribeClient.SubmitResult.Ready -> res.srt
                    is TranscribeClient.SubmitResult.Job -> {
                        runOnUiThread { progressBar.isIndeterminate = true }
                        postStatus("Gemini က အသံနားထောင်နေတယ်… (၁-၃ မိနစ် ကြာနိုင်တယ်)")
                        waitForJob(client, res.jobId)
                    }
                }
                val cues = SrtParser.parse(srtText)
                if (cues.isEmpty()) {
                    postError("ဒီ Video မှာ အသံမတွေ့ဘူး။")
                    return@Thread
                }
                if (mode == modeSrt) {
                    // v0.6.2: SRT waits for the download button too.
                    workLastSrt = srtText
                    runOnUiThread {
                        setBusy(false)
                        progressBar.progress = 100
                        workDownloadButton.text = "SRT ဒေါင်းလုဒ်လုပ်ရန်"
                        workDownloadButton.visibility = View.VISIBLE
                        setStatus("ပြီးပြီ — ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။")
                    }
                    return@Thread
                }
                // Transformer must start on the main thread.
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    try {
                        val typeface = loadMyanmarTypeface()
                        val outputFile = newOutputFile()
                        val newBurner = SubtitleBurner(this)
                        burner = newBurner
                        progressBar.isIndeterminate = false
                        setStatus("စာတန်းထည့်နေတယ်… 0%")
                        newBurner.start(
                            video, cues, typeface, outputFile, burnCallback,
                            coverOriginalSubs = workCoverCheck.isChecked
                        )
                    } catch (e: Exception) {
                        setBusy(false)
                        setStatus("အမှား: ${e.message ?: "unknown error"}")
                    }
                }
            } catch (e: Exception) {
                postError(e.message ?: "unknown error")
            }
        }.start()
    }

    private fun onTtsClicked() {
        val text = ttsTextField.text.toString().trim()
        if (text.isEmpty()) {
            ttsStatusText.text = "စာသား ရိုက်ထည့်ပါ။"
            return
        }
        val option = voiceOptions[selectedVoiceIndex]
        val rate = ttsRate
        val mode = if (autoVoice) "auto" else "manual"
        val imageUri = ttsImageUri
        ttsMakeButton.isEnabled = false
        ttsDownloadButton.visibility = View.GONE
        stopTtsPlayer()
        ttsPlayerRow.visibility = View.GONE
        ttsLastAudio = null
        ttsLastSrt = null
        ttsLastVideo = null
        ttsLastVideoUrl = null
        ttsProgressBar.isIndeterminate = true
        ttsStatusText.text = "အသံထုတ်နေတယ်…"
        Thread {
            try {
                val client = TranscribeClient(contentResolver)
                if (imageUri != null) {
                    // Image picked: the server builds a finished video
                    // (image + narration + burned subtitles).
                    runOnUiThread { ttsStatusText.text = "ပုံ တင်နေတယ်…" }
                    val fileName = imageUri.lastPathSegment ?: "image.jpg"
                    val jobId = client.submitNarrateImage(
                        imageUri, fileName, text, apiKey, option.voice, rate, 0, mode,
                        ttsEngine, ttsStyle,
                        onUploadProgress = { pct ->
                            runOnUiThread {
                                ttsProgressBar.isIndeterminate = false
                                ttsProgressBar.progress = pct
                                ttsStatusText.text = "ပုံ တင်နေတယ်… $pct%"
                            }
                        }
                    )
                    runOnUiThread {
                        ttsProgressBar.isIndeterminate = true
                        ttsStatusText.text = "Video ထုတ်နေတယ်… (မိနစ် အနည်းငယ် ကြာနိုင်တယ်)"
                    }
                    val state = pollUntilDone(client, jobId, maxWaits = 450)
                    val videoUrl = state.videoUrl
                        ?: throw IOException("Server က Video ပြန်မပေးဘူး။")
                    runOnUiThread { ttsStatusText.text = "Video ပြန်ယူနေတယ်…" }
                    val tmp = File(cacheDir, "narrated-image-${stamp()}.mp4")
                    client.downloadToFile(videoUrl, tmp)
                    ttsLastVideo = tmp
                    ttsLastVideoUrl = videoUrl
                    ttsLastSrt = state.srt?.takeIf { it.isNotBlank() }
                } else if (ttsEngine == "gemini") {
                    // Expressive Gemini TTS (single voice + style).
                    val geminiVoice = if (selectedVoiceIndex == 0) {
                        TtsClient.GEMINI_VOICE_FEMALE
                    } else {
                        TtsClient.GEMINI_VOICE_MALE
                    }
                    val jobId = TtsClient().submitGemini(
                        text, geminiVoice, ttsStyle, apiKey
                    )
                    runOnUiThread { ttsStatusText.text = "Gemini အသံထုတ်နေတယ်…" }
                    val state = pollUntilDone(client, jobId)
                    val audioUrl = state.audioUrl
                        ?: throw IOException("Server က အသံဖိုင် ပြန်မပေးဘူး။")
                    val audio = TtsClient().downloadAudio(audioUrl)
                    ttsLastAudio = audio
                    ttsLastSrt = state.srt?.takeIf { it.isNotBlank() }
                } else {
                    val jobId = TtsClient().submit(text, option.voice, rate, 0, mode, apiKey)
                    runOnUiThread { ttsStatusText.text = "AI အသံဖတ်ပြနေတယ်…" }
                    val state = pollUntilDone(client, jobId)
                    val audioUrl = state.audioUrl
                        ?: throw IOException("Server က အသံဖိုင် ပြန်မပေးဘူး။")
                    val audio = TtsClient().downloadAudio(audioUrl)
                    // v0.6.2: keep the audio until the user taps download.
                    ttsLastAudio = audio
                    ttsLastSrt = state.srt?.takeIf { it.isNotBlank() }
                }
                runOnUiThread {
                    ttsMakeButton.isEnabled = true
                    ttsProgressBar.isIndeterminate = false
                    ttsProgressBar.progress = 100
                    ttsDownloadButton.text = if (ttsLastVideo != null) {
                        "Video ဒေါင်းလုဒ်လုပ်ရန်"
                    } else {
                        "အသံဖိုင် ဒေါင်းလုပ်လုပ်ရန်"
                    }
                    ttsDownloadButton.visibility = View.VISIBLE
                    val audio = ttsLastAudio
                    if (audio != null) {
                        setupTtsPlayer(audio)
                        ttsStatusText.text =
                            "ပြီးပြီ — ▶ နှိပ်ပြီး အသံနားထောင်ကြည့်ပါ၊ ပြီးရင် ဒေါင်းလုပ်လုပ်ပါ။"
                    } else {
                        ttsStatusText.text =
                            "ပြီးပြီ — ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    ttsMakeButton.isEnabled = true
                    ttsProgressBar.isIndeterminate = false
                    ttsProgressBar.progress = 0
                    ttsStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    /** Prepares the listen-here player for freshly generated audio. */
    private fun setupTtsPlayer(audio: ByteArray) {
        stopTtsPlayer()
        try {
            val file = File(cacheDir, "tts-preview-${stamp()}.mp3")
            file.writeBytes(audio)
            ttsPlayerFile = file
            val mp = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                prepare()
                setOnCompletionListener {
                    ttsPlayButton.text = "▶"
                    ttsSeekBar.progress = 0
                    ttsPlayerHandler.removeCallbacks(ttsPlayerPoller)
                }
            }
            ttsPlayer = mp
            ttsSeekBar.max = mp.duration
            ttsSeekBar.progress = 0
            ttsTimeText.text = "00:00 / ${formatClockUs(mp.duration * 1_000L)}"
            ttsPlayButton.text = "▶"
            ttsPlayerRow.visibility = View.VISIBLE
        } catch (e: Exception) {
            ttsPlayerRow.visibility = View.GONE
        }
    }

    private fun toggleTtsPlayback() {
        val mp = ttsPlayer ?: return
        try {
            if (mp.isPlaying) {
                mp.pause()
                ttsPlayButton.text = "▶"
                ttsPlayerHandler.removeCallbacks(ttsPlayerPoller)
            } else {
                mp.start()
                ttsPlayButton.text = "⏸"
                ttsPlayerHandler.removeCallbacks(ttsPlayerPoller)
                ttsPlayerHandler.post(ttsPlayerPoller)
            }
        } catch (e: Exception) {
        }
    }

    /** Pauses playback when leaving the TTS screen, keeping the
     * player ready so listening can resume on return. */
    private fun pauseTtsPlayer() {
        ttsPlayerHandler.removeCallbacks(ttsPlayerPoller)
        try {
            if (ttsPlayer?.isPlaying == true) ttsPlayer?.pause()
        } catch (e: Exception) {
        }
        if (::ttsPlayButton.isInitialized) ttsPlayButton.text = "▶"
    }

    private fun stopTtsPlayer() {
        ttsPlayerHandler.removeCallbacks(ttsPlayerPoller)
        try {
            ttsPlayer?.stop()
        } catch (e: Exception) {
        }
        try {
            ttsPlayer?.release()
        } catch (e: Exception) {
        }
        ttsPlayer = null
        ttsPlayerFile?.delete()
        ttsPlayerFile = null
    }

    /** Copies the video's audio track into [outFile] (.m4a) without
     * re-encoding, so only a few megabytes go up to the server. */
    @Throws(IOException::class)
    private fun extractAudioToM4a(videoUri: Uri, outFile: File) {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(this, videoUri, null)
            var audioTrack = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME).orEmpty().startsWith("audio/")) {
                    audioTrack = i
                    format = f
                    break
                }
            }
            if (audioTrack < 0 || format == null) {
                throw IOException("ဒီ Video မှာ အသံ မပါဘူး။ အသံပါတဲ့ Video ရွေးပါ။")
            }
            extractor.selectTrack(audioTrack)
            val muxer = MediaMuxer(
                outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
            )
            try {
                val outTrack = muxer.addTrack(format)
                muxer.start()
                val buffer = ByteBuffer.allocate(512 * 1024)
                val info = MediaCodec.BufferInfo()
                while (true) {
                    val size = extractor.readSampleData(buffer, 0)
                    if (size < 0) break
                    info.set(0, size, extractor.sampleTime, extractor.sampleFlags)
                    muxer.writeSampleData(outTrack, buffer, info)
                    extractor.advance()
                }
                muxer.stop()
            } finally {
                try {
                    muxer.release()
                } catch (e: Exception) {
                }
            }
        } finally {
            extractor.release()
        }
    }

    /** Muxes the original video track + the narration audio into
     * [outFile], copying both tracks without re-encoding. The narration
     * replaces the original audio. Samples are interleaved by timestamp. */
    @Throws(IOException::class)
    private fun muxNarrationOntoVideo(videoUri: Uri, narrationFile: File, outFile: File) {
        var rotation = 0
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, videoUri)
            rotation = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION
            )?.toIntOrNull() ?: 0
        } catch (e: Exception) {
        } finally {
            try {
                retriever.release()
            } catch (e: Exception) {
            }
        }
        val muxer = MediaMuxer(
            outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
        )
        if (rotation != 0) muxer.setOrientationHint(rotation)
        val vExtractor = MediaExtractor()
        val aExtractor = MediaExtractor()
        try {
            vExtractor.setDataSource(this, videoUri, null)
            var vTrack = -1
            var vFormat: MediaFormat? = null
            for (i in 0 until vExtractor.trackCount) {
                val f = vExtractor.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME).orEmpty().startsWith("video/")) {
                    vTrack = i
                    vFormat = f
                    break
                }
            }
            if (vTrack < 0 || vFormat == null) {
                throw IOException("Video track ရှာမတွေ့ဘူး။")
            }
            vExtractor.selectTrack(vTrack)
            val outVideo = muxer.addTrack(vFormat)
            aExtractor.setDataSource(narrationFile.absolutePath)
            var aTrack = -1
            var aFormat: MediaFormat? = null
            for (i in 0 until aExtractor.trackCount) {
                val f = aExtractor.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME).orEmpty().startsWith("audio/")) {
                    aTrack = i
                    aFormat = f
                    break
                }
            }
            if (aTrack < 0 || aFormat == null) {
                throw IOException("အသံ track ရှာမတွေ့ဘူး။")
            }
            aExtractor.selectTrack(aTrack)
            val outAudio = muxer.addTrack(aFormat)
            muxer.start()
            val buffer = ByteBuffer.allocate(2 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            var vTime = vExtractor.sampleTime
            var aTime = aExtractor.sampleTime
            var vDone = vTime < 0L
            var aDone = aTime < 0L
            while (!vDone || !aDone) {
                if (!vDone && (aDone || vTime <= aTime)) {
                    val size = vExtractor.readSampleData(buffer, 0)
                    if (size < 0) {
                        vDone = true
                    } else {
                        info.set(0, size, vTime, vExtractor.sampleFlags)
                        muxer.writeSampleData(outVideo, buffer, info)
                        vExtractor.advance()
                        vTime = vExtractor.sampleTime
                        if (vTime < 0L) vDone = true
                    }
                } else if (!aDone) {
                    val size = aExtractor.readSampleData(buffer, 0)
                    if (size < 0) {
                        aDone = true
                    } else {
                        info.set(0, size, aTime, aExtractor.sampleFlags)
                        muxer.writeSampleData(outAudio, buffer, info)
                        aExtractor.advance()
                        aTime = aExtractor.sampleTime
                        if (aTime < 0L) aDone = true
                    }
                }
            }
            muxer.stop()
        } finally {
            try {
                vExtractor.release()
            } catch (e: Exception) {
            }
            try {
                aExtractor.release()
            } catch (e: Exception) {
            }
            try {
                muxer.release()
            } catch (e: Exception) {
            }
        }
    }

    // v0.9.7: audio-only voiceover. The phone extracts the audio, the
    // server returns Myanmar narration + SRT, and the phone muxes the
    // narration onto the original video — no big video upload/download.
    private fun onVoiceoverClicked() {
        val video = voVideoUri ?: return
        val option = voiceOptions[selectedVoiceIndex]
        voPickButton.isEnabled = false
        voMakeButton.isEnabled = false
        voDownloadButton.visibility = View.GONE
        voSrtDownloadButton.visibility = View.GONE
        voPreviewVideo.stopPlayback()
        voPreviewVideo.visibility = View.GONE
        voSrtText.visibility = View.GONE
        voProgressBar.isIndeterminate = true
        voStatusText.text = "Video ကနေ အသံ ထုတ်နေတယ်…"
        Thread {
            try {
                val audioFile = File(cacheDir, "vo-audio-${stamp()}.m4a")
                extractAudioToM4a(video, audioFile)
                runOnUiThread {
                    voProgressBar.isIndeterminate = false
                    voProgressBar.progress = 0
                    voStatusText.text = "အသံ တင်နေတယ်… (Video ထက် အများကြီး မြန်တယ်)"
                }
                val client = TranscribeClient(contentResolver)
                val jobId = client.submitVoiceoverAudio(
                    audioFile, "audio.m4a", apiKey, option.voice, 0, 0,
                    if (autoVoice) "auto" else "manual",
                    onUploadProgress = { pct ->
                        runOnUiThread {
                            voProgressBar.progress = pct
                            voStatusText.text = "အသံ တင်နေတယ်… $pct%"
                        }
                    }
                )
                runOnUiThread {
                    voProgressBar.isIndeterminate = true
                    voStatusText.text = "မြန်မာအသံ ထည့်နေတယ်… (၁-၃ မိနစ် ကြာနိုင်တယ်)"
                }
                // Timed narration (server v24) synthesizes per speech block,
                // so a long video can take a while — allow up to ~30 min.
                val state = pollUntilDone(client, jobId, 450)
                val narrationUrl = state.audioM4aUrl
                    ?: throw IOException("Server က မြန်မာအသံ ပြန်မပေးဘူး။")
                runOnUiThread { voStatusText.text = "မြန်မာအသံ ပြန်ယူနေတယ်…" }
                val narration = File(cacheDir, "vo-narration-${stamp()}.m4a")
                client.downloadToFile(narrationUrl, narration)
                runOnUiThread { voStatusText.text = "Video နဲ့ အသံ တွဲနေတယ်…" }
                val tmp = File(cacheDir, "voiceover-${stamp()}.mp4")
                muxNarrationOntoVideo(video, narration, tmp)
                runOnUiThread {
                    voPickButton.isEnabled = true
                    voMakeButton.isEnabled = true
                    voProgressBar.isIndeterminate = false
                    voProgressBar.progress = 100
                    voLastTmp = tmp
                    voLastVideoUrl = null
                    voLastSrt = state.srt
                    voDownloadButton.visibility = View.VISIBLE
                    // Preview first: play the finished video here, and show
                    // the full SRT text on the page, before downloading.
                    val hasSrt = !state.srt.isNullOrBlank()
                    voSrtText.text = state.srt.orEmpty()
                    voSrtText.visibility = if (hasSrt) View.VISIBLE else View.GONE
                    voSrtDownloadButton.visibility =
                        if (hasSrt) View.VISIBLE else View.GONE
                    voPreviewVideo.setVideoURI(Uri.fromFile(tmp))
                    voPreviewVideo.setMediaController(
                        MediaController(this).apply { setAnchorView(voPreviewVideo) }
                    )
                    voPreviewVideo.visibility = View.VISIBLE
                    voPreviewVideo.start()
                    voStatusText.text = "ပြီးပြီ — Video နဲ့ SRT ကို ကြည့်ပြီး၊ လိုချင်တာကို ဒေါင်းလုပ်လုပ်ပါ။"
                    // Bring the finished video into view.
                    voScrollView.post {
                        voScrollView.smoothScrollTo(0, voPreviewVideo.top)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    voPickButton.isEnabled = true
                    voMakeButton.isEnabled = voVideoUri != null
                    voProgressBar.isIndeterminate = false
                    voProgressBar.progress = 0
                    voPreviewVideo.stopPlayback()
                    voPreviewVideo.visibility = View.GONE
                    voSrtText.visibility = View.GONE
                    voDownloadButton.visibility = View.GONE
                    voSrtDownloadButton.visibility = View.GONE
                    voStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    private fun setPvRunning(running: Boolean) {
        val formVisibility = if (running) View.GONE else View.VISIBLE
        pvInputCard.visibility = formVisibility
        pvHintText.visibility = formVisibility
        if (running) {
            pvImageLabel.visibility = View.GONE
            pvImageRow.visibility = View.GONE
            pvClearImagesButton.visibility = View.GONE
        } else {
            pvImageLabel.visibility = View.VISIBLE
            updatePvImageLabel()
        }
    }

    private fun onPromptVideoClicked() {
        val prompt = pvTextField.text.toString().trim()
        if (prompt.isEmpty()) {
            pvStatusText.text = "Prompt ရိုက်ထည့်ပါ။"
            return
        }
        val imageUris = pvImageUris.toList()
        pvMakeButton.isEnabled = false
        pvDownloadButton.visibility = View.GONE
        setPvRunning(true)
        pvProgressBar.isIndeterminate = true
        pvStatusText.text = "ဇာတ်လမ်း ရေးနေတယ်…"
        Thread {
            try {
                val imageFiles = imageUris.mapIndexed { idx, uri ->
                    copyUriToCache(uri, "pv-image-$idx")
                }
                // Auto mode (server v28+): the AI splits the narration by
                // character and gives each their own voice. The voice sent
                // here is only the fallback if the split fails.
                val jobId = TtsClient().submitPromptVideo(
                    prompt, apiKey, TtsClient.VOICE_NILAR, 0, 0, imageFiles, "auto"
                )
                runOnUiThread {
                    pvStatusText.text = "ပုံထုတ် + အသံထည့် + Video ပေါင်းနေတယ်… (မိနစ် အနည်းငယ် ကြာနိုင်တယ်)"
                }
                val client = TranscribeClient(contentResolver)
                // Prompt-video assembles 3 scenes on the free server, so it
                // may take longer than a transcription: allow ~30 minutes.
                val state = pollUntilDone(client, jobId, maxWaits = 450)
                val videoUrl = state.videoUrl
                    ?: throw IOException("Server က Video ပြန်မပေးဘူး။")
                runOnUiThread { pvStatusText.text = "Video ပြန်ယူနေတယ်…" }
                val tmp = File(cacheDir, "prompt-video-${stamp()}.mp4")
                client.downloadToFile(videoUrl, tmp)
                runOnUiThread {
                    pvMakeButton.isEnabled = true
                    setPvRunning(false)
                    pvProgressBar.isIndeterminate = false
                    pvProgressBar.progress = 100
                    pvLastTmp = tmp
                    pvLastVideoUrl = videoUrl
                    pvLastSrt = state.srt
                    pvDownloadButton.visibility = View.VISIBLE
                    pvStatusText.text = "ပြီးပြီ — ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    pvMakeButton.isEnabled = true
                    setPvRunning(false)
                    pvProgressBar.isIndeterminate = false
                    pvProgressBar.progress = 0
                    pvStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    // v0.6.2: finished files are saved to Downloads only when the user
    // taps the separate download button on each screen.
    private fun onWorkDownloadClicked() {
        val srt = workLastSrt
        val output = workLastOutput
        if (srt == null && output == null) return
        workDownloadButton.isEnabled = false
        setStatus("Download/zhang file ထဲ သိမ်းနေတယ်…")
        Thread {
            try {
                val savedName = if (srt != null) {
                    saveSrtToDownloads(srt)
                } else {
                    copyToDownloads(output!!, "video/mp4")
                }
                runOnUiThread {
                    workDownloadButton.isEnabled = true
                    if (savedName != null) {
                        setStatus("ပြီးပြီ — Download/zhang file ထဲ သိမ်းပြီးပြီ:\n$savedName")
                    } else {
                        setStatus("အမှား: သိမ်းလို့ မရဘူး။")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    workDownloadButton.isEnabled = true
                    setStatus("အမှား: ${e.message ?: "unknown error"}")
                }
            }
        }.start()
    }

    private fun onMtvClicked() {
        val imageUri = mtvImageUri
        val song = mtvSongField.text.toString().trim()
        val link = mtvLinkField.text.toString().trim()
        if (imageUri == null) {
            mtvStatusText.text = "လူပုံ အရင် ရွေးပါ။"
            return
        }
        if (song.isEmpty() && link.isEmpty()) {
            mtvStatusText.text = "သီချင်းနာမည် (သို့) Link တစ်ခု ထည့်ပါ။"
            return
        }
        mtvMakeButton.isEnabled = false
        mtvDownloadButton.visibility = View.GONE
        mtvLastVideo = null
        mtvLastVideoUrl = null
        mtvProgressBar.isIndeterminate = true
        mtvStatusText.text = "ပုံ တင်နေတယ်…"
        Thread {
            try {
                val client = TranscribeClient(contentResolver)
                val fileName = imageUri.lastPathSegment ?: "image.jpg"
                val jobId = client.submitMtv(
                    imageUri, fileName, song, link.ifEmpty { null },
                    onUploadProgress = { pct ->
                        runOnUiThread {
                            mtvProgressBar.isIndeterminate = false
                            mtvProgressBar.progress = pct
                            mtvStatusText.text = "ပုံ တင်နေတယ်… $pct%"
                        }
                    }
                )
                runOnUiThread {
                    mtvProgressBar.isIndeterminate = true
                    mtvStatusText.text = "သီချင်းရှာပြီး MTV ထုတ်နေတယ်… (မိနစ် အနည်းငယ် ကြာနိုင်တယ်)"
                }
                val state = pollUntilDone(client, jobId, maxWaits = 450)
                val videoUrl = state.videoUrl
                    ?: throw IOException("Server က Video ပြန်မပေးဘူး။")
                runOnUiThread { mtvStatusText.text = "Video ပြန်ယူနေတယ်…" }
                val tmp = File(cacheDir, "mtv-${stamp()}.mp4")
                client.downloadToFile(videoUrl, tmp)
                mtvLastVideo = tmp
                mtvLastVideoUrl = videoUrl
                val title = state.title?.takeIf { it.isNotBlank() }
                runOnUiThread {
                    mtvMakeButton.isEnabled = true
                    mtvProgressBar.isIndeterminate = false
                    mtvProgressBar.progress = 100
                    mtvDownloadButton.visibility = View.VISIBLE
                    mtvStatusText.text = if (title != null) {
                        "ပြီးပြီ — $title\nဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။"
                    } else {
                        "ပြီးပြီ — ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    mtvMakeButton.isEnabled = true
                    mtvProgressBar.isIndeterminate = false
                    mtvProgressBar.progress = 0
                    mtvStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    private fun onMtvDownloadClicked() {
        val video = mtvLastVideo ?: return
        mtvDownloadButton.isEnabled = false
        mtvStatusText.text = "Download/zhang file ထဲ သိမ်းနေတယ်…"
        Thread {
            try {
                val file = if (video.exists()) {
                    video
                } else {
                    val videoUrl = mtvLastVideoUrl
                        ?: throw IOException("Video ပြန်ယူလို့ မရဘူး။")
                    val fresh = File(cacheDir, "mtv-${stamp()}.mp4")
                    TranscribeClient(contentResolver).downloadToFile(videoUrl, fresh)
                    mtvLastVideo = fresh
                    fresh
                }
                val name = copyToDownloads(file, "video/mp4")
                runOnUiThread {
                    mtvDownloadButton.isEnabled = true
                    mtvStatusText.text = if (name != null) {
                        "ပြီးပြီ — Download/zhang file ထဲ သိမ်းပြီးပြီ:\n$name"
                    } else {
                        "အမှား: သိမ်းလို့ မရဘူး။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    mtvDownloadButton.isEnabled = true
                    mtvStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    private fun onTtsDownloadClicked() {
        val video = ttsLastVideo
        val audio = ttsLastAudio
        if (video == null && audio == null) return
        ttsDownloadButton.isEnabled = false
        ttsStatusText.text = "Download/zhang file ထဲ သိမ်းနေတယ်…"
        Thread {
            try {
                val mainName: String?
                if (video != null) {
                    val file = if (video.exists()) {
                        video
                    } else {
                        val videoUrl = ttsLastVideoUrl
                            ?: throw IOException("Video ပြန်ယူလို့ မရဘူး။")
                        val fresh = File(cacheDir, "narrated-image-${stamp()}.mp4")
                        TranscribeClient(contentResolver).downloadToFile(videoUrl, fresh)
                        ttsLastVideo = fresh
                        fresh
                    }
                    mainName = copyToDownloads(file, "video/mp4")
                } else {
                    mainName = saveBytesToDownloads(
                        audio!!, "zhang-studio-voice-${stamp()}.mp3", "audio/mpeg"
                    )
                }
                val srtName = ttsLastSrt?.let { saveSrtToDownloads(it) }
                runOnUiThread {
                    ttsDownloadButton.isEnabled = true
                    if (mainName != null) {
                        ttsStatusText.text = "ပြီးပြီ — Download/zhang file ထဲ သိမ်းပြီးပြီ:\n$mainName" +
                            (if (srtName != null) "\n$srtName" else "")
                    } else {
                        ttsStatusText.text = "အမှား: သိမ်းလို့ မရဘူး။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    ttsDownloadButton.isEnabled = true
                    ttsStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    private fun onTimingDownloadClicked() {
        val output = timingLastOutput ?: return
        timingDownloadButton.isEnabled = false
        timingStatusText.text = "Saving to Download/zhang file…"
        Thread {
            try {
                val savedName = copyToDownloads(output, "video/mp4")
                runOnUiThread {
                    timingDownloadButton.isEnabled = true
                    if (savedName != null) {
                        timingStatusText.text =
                            "Done — saved to Download/zhang file:\n$savedName"
                    } else {
                        timingStatusText.text = "Error: could not save."
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    timingDownloadButton.isEnabled = true
                    timingStatusText.text = "Error: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    // Download the last finished video without re-running the job:
    // the cached file is copied to Downloads (no data used), or the
    // video is fetched again from the saved server URL if the cache is gone.
    /** Downloads only the finished voiceover video. */
    private fun onVoVideoDownloadClicked() {
        val tmp = voLastTmp
        val videoUrl = voLastVideoUrl
        if (tmp == null) return
        voDownloadButton.isEnabled = false
        voStatusText.text = "Video ဒေါင်းလုဒ်လုပ်နေတယ်…"
        Thread {
            try {
                val file = if (tmp.exists()) {
                    tmp
                } else if (videoUrl != null) {
                    val fresh = File(cacheDir, "voiceover-${stamp()}.mp4")
                    TranscribeClient(contentResolver).downloadToFile(videoUrl, fresh)
                    voLastTmp = fresh
                    fresh
                } else {
                    throw IOException("Video ဖိုင် မရှိတော့ဘူး။ ပြန်လုပ်ပါ။")
                }
                val savedName = copyToDownloads(file, "video/mp4")
                runOnUiThread {
                    voDownloadButton.isEnabled = true
                    voStatusText.text = if (savedName != null) {
                        "ပြီးပြီ — Download/zhang file ထဲ သိမ်းပြီးပြီ:\n$savedName"
                    } else {
                        "အမှား: Video သိမ်းလို့ မရဘူး။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    voDownloadButton.isEnabled = true
                    voStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    /** Downloads only the SRT, for users who want to add it themselves. */
    private fun onVoSrtDownloadClicked() {
        val srt = voLastSrt?.takeIf { it.isNotBlank() } ?: return
        voSrtDownloadButton.isEnabled = false
        voStatusText.text = "SRT သိမ်းနေတယ်…"
        Thread {
            try {
                val savedName = saveSrtToDownloads(srt)
                runOnUiThread {
                    voSrtDownloadButton.isEnabled = true
                    voStatusText.text = if (savedName != null) {
                        "ပြီးပြီ — Download/zhang file ထဲ သိမ်းပြီးပြီ:\n$savedName"
                    } else {
                        "အမှား: SRT သိမ်းလို့ မရဘူး။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    voSrtDownloadButton.isEnabled = true
                    voStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    private fun onPvDownloadClicked() {
        val tmp = pvLastTmp
        val videoUrl = pvLastVideoUrl
        if (tmp == null || videoUrl == null) return
        pvDownloadButton.isEnabled = false
        pvStatusText.text = "Video ဒေါင်းလုဒ်လုပ်နေတယ်…"
        Thread {
            try {
                val file = if (tmp.exists()) {
                    tmp
                } else {
                    val fresh = File(cacheDir, "prompt-video-${stamp()}.mp4")
                    TranscribeClient(contentResolver).downloadToFile(videoUrl, fresh)
                    pvLastTmp = fresh
                    fresh
                }
                val savedName = copyToDownloads(file, "video/mp4")
                val srtName = pvLastSrt?.takeIf { it.isNotBlank() }
                    ?.let { saveSrtToDownloads(it) }
                runOnUiThread {
                    pvDownloadButton.isEnabled = true
                    pvStatusText.text = if (savedName != null) {
                        "ပြီးပြီ — Download/zhang file ထဲ သိမ်းပြီးပြီ:\n$savedName" +
                            (if (srtName != null) "\n$srtName" else "")
                    } else {
                        "အမှား: Video သိမ်းလို့ မရဘူး။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    pvDownloadButton.isEnabled = true
                    pvStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    // ---- v0.7.0: VN-style segment editing ----

    /** Pushes the segment models into the timeline views. */
    private fun refreshEditorModels() {
        if (::timingVideoStrip.isInitialized) {
            timingVideoStrip.setSegments(timingVideoSegments)
        }
        if (::timingMusicTrack.isInitialized) {
            timingMusicTrack.setClips(
                timingMusicClips, timingMusicName.takeIf { it.isNotEmpty() }
            )
        }
        if (::timingOverlayTrack.isInitialized) {
            timingOverlayTrack.setClips(timingOverlayClips)
        }
        // The SRT track refreshes via updateTimingInfo -> setCues.
    }

    private fun setSelection(track: Int, index: Int) {
        selectedTrack = track
        selectedIndex = index
        timingVideoStrip.setSelectedIndex(if (track == 1) index else -1)
        timingMusicTrack.setSelectedIndex(if (track == 2) index else -1)
        timingSrtTrack.setSelectedIndex(if (track == 3) index else -1)
        if (::timingOverlayTrack.isInitialized) {
            timingOverlayTrack.setSelectedIndex(if (track == 4) index else -1)
        }
        refreshSelectionBar()
        // v0.7.9: selecting a cue loads its text into the manual
        // field, VN-style, ready to edit.
        if (track == 3 && index >= 0 && ::timingManualTextField.isInitialized) {
            val cues = SrtParser.shifted(timingCues, timingShiftUs)
            if (index in cues.indices) {
                timingManualTextField.setText(cues[index].text)
            }
        }
    }

    private fun refreshSelectionBar() {
        // v0.8.2: the subtitle length buttons work only while a
        // subtitle is selected.
        if (::timingCueShorterButton.isInitialized) {
            val cueSelected = selectedTrack == 3 && selectedIndex >= 0
            timingCueShorterButton.isEnabled = cueSelected
            timingCueLongerButton.isEnabled = cueSelected
        }
        if (selectedTrack == 0 || selectedIndex < 0) {
            timingSelectionScroll.visibility = View.GONE
            return
        }
        timingSelectionScroll.visibility = View.VISIBLE
        timingSelectionLabel.text = when (selectedTrack) {
            1 -> "Clip ${selectedIndex + 1}/${timingVideoSegments.size}"
            2 -> "Music ${selectedIndex + 1}/${timingMusicClips.size}"
            4 -> "Overlay ${selectedIndex + 1}/${timingOverlayClips.size}"
            else -> {
                val count =
                    SrtParser.shifted(timingCues, timingShiftUs).size
                "Sub ${selectedIndex + 1}/$count"
            }
        }
        // v0.9.4: contextual buttons (CapCut clip toolbar) —
        // Split for video/music/subtitle, Volume for video/music,
        // Delete/Undo/Redo for everything selected.
        timingSplitButton.visibility =
            if (selectedTrack == 4) View.GONE else View.VISIBLE
        timingVolumeBarButton.visibility =
            if (selectedTrack == 1 || selectedTrack == 2) {
                View.VISIBLE
            } else {
                View.GONE
            }
        timingSplitButton.isEnabled = canSplitSelection()
    }

    private fun playheadUs(): Long {
        if (!::timingPreviewVideo.isInitialized) return 0L
        return try {
            timingPreviewVideo.currentPosition.toLong() * 1_000L
        } catch (e: Exception) {
            0L
        }
    }

    /** The playhead must sit strictly inside the selected piece,
     * with a small margin, for Split to make sense. */
    private fun canSplitSelection(): Boolean {
        val p = playheadUs()
        return when (selectedTrack) {
            1 -> selectedIndex in timingVideoSegments.indices &&
                p > timingVideoSegments[selectedIndex].first + 300_000L &&
                p < timingVideoSegments[selectedIndex].second - 300_000L
            2 -> selectedIndex in timingMusicClips.indices &&
                p > timingMusicClips[selectedIndex].startUs + 300_000L &&
                p < timingMusicClips[selectedIndex].endUs - 300_000L
            3 -> {
                val cues = SrtParser.shifted(timingCues, timingShiftUs)
                selectedIndex in cues.indices &&
                    p > cues[selectedIndex].startUs + 200_000L &&
                    p < cues[selectedIndex].endUs - 200_000L
            }
            else -> false
        }
    }

    private fun currentSnapshot() = EditorSnapshot(
        timingVideoSegments.toList(),
        timingMusicClips.toList(),
        timingCues.toList(),
        timingOverlayClips.toList()
    )

    private fun pushUndoSnapshot() {
        timingUndoStack.addLast(currentSnapshot())
        while (timingUndoStack.size > 20) timingUndoStack.removeFirst()
        timingRedoStack.clear()
    }

    private fun restoreSnapshot(snap: EditorSnapshot) {
        timingVideoSegments = snap.videoSegments.toMutableList()
        timingMusicClips = snap.musicClips.toMutableList()
        timingCues = snap.cues
        timingOverlayClips = snap.overlayClips.toMutableList()
        clearTrimCutFields()
        refreshEditorModels()
        refreshTimingOverlay()
        setSelection(0, -1)
        updateTimingInfo()
        updateTimingEnabled()
    }

    private fun undoLastEdit() {
        if (timingUndoStack.isEmpty()) return
        timingRedoStack.addLast(currentSnapshot())
        restoreSnapshot(timingUndoStack.removeLast())
    }

    /** v0.8.1: redo the last undone edit. */
    private fun redoLastEdit() {
        if (timingRedoStack.isEmpty()) return
        timingUndoStack.addLast(currentSnapshot())
        restoreSnapshot(timingRedoStack.removeLast())
    }

    private fun clearTrimCutFields() {
        timingTrimStartField.setText("")
        timingTrimEndField.setText("")
    }

    /** Splits the selected piece into two at the playhead. */
    private fun onSplitSelected() {
        val p = playheadUs()
        when (selectedTrack) {
            1 -> {
                if (selectedIndex !in timingVideoSegments.indices) return
                val (s, e) = timingVideoSegments[selectedIndex]
                if (p <= s + 300_000L || p >= e - 300_000L) return
                pushUndoSnapshot()
                timingVideoSegments[selectedIndex] = s to p
                timingVideoSegments.add(selectedIndex + 1, p to e)
                clearTrimCutFields()
                refreshEditorModels()
                setSelection(1, selectedIndex)
            }
            2 -> {
                if (selectedIndex !in timingMusicClips.indices) return
                val clip = timingMusicClips[selectedIndex]
                if (p <= clip.startUs + 300_000L ||
                    p >= clip.endUs - 300_000L
                ) return
                pushUndoSnapshot()
                timingMusicClips[selectedIndex] =
                    MusicClip(clip.startUs, p, clip.offsetUs)
                timingMusicClips.add(
                    selectedIndex + 1,
                    MusicClip(p, clip.endUs, clip.offsetUs + (p - clip.startUs))
                )
                clearTrimCutFields()
                refreshEditorModels()
                setSelection(2, selectedIndex)
            }
            3 -> {
                val shifted = SrtParser.shifted(timingCues, timingShiftUs)
                if (selectedIndex !in shifted.indices) return
                val cue = shifted[selectedIndex]
                if (p <= cue.startUs + 200_000L ||
                    p >= cue.endUs - 200_000L
                ) return
                pushUndoSnapshot()
                val split = SrtParser.splitCue(shifted, selectedIndex, p)
                timingCues = SrtParser.shifted(split, -timingShiftUs)
                clearTrimCutFields()
                setSelection(3, selectedIndex)
            }
            else -> return
        }
        updateTimingInfo()
        updateTimingEnabled()
    }

    /** Deletes the selected piece. Video pieces ripple-join on export;
     * music pieces leave silence; SRT pieces just disappear. */
    private fun onDeleteSelected() {
        when (selectedTrack) {
            1 -> {
                if (selectedIndex !in timingVideoSegments.indices) return
                pushUndoSnapshot()
                timingVideoSegments.removeAt(selectedIndex)
                clearTrimCutFields()
                refreshEditorModels()
            }
            2 -> {
                if (selectedIndex !in timingMusicClips.indices) return
                pushUndoSnapshot()
                timingMusicClips.removeAt(selectedIndex)
                if (timingMusicClips.isEmpty()) {
                    releaseTimingMusicPlayer()
                    timingMusicUri = null
                    timingMusicDurationMs = 0L
                    timingMusicName = ""
                    timingMusicLabel.text = "No music picked"
                    timingMusicClearButton.visibility = View.GONE
                }
                clearTrimCutFields()
                refreshEditorModels()
            }
            4 -> {
                if (selectedIndex !in timingOverlayClips.indices) return
                pushUndoSnapshot()
                timingOverlayClips.removeAt(selectedIndex)
                clearTrimCutFields()
                refreshEditorModels()
                refreshTimingOverlay()
            }
            3 -> {
                val shifted = SrtParser.shifted(timingCues, timingShiftUs)
                if (selectedIndex !in shifted.indices) return
                pushUndoSnapshot()
                val kept = shifted.toMutableList()
                kept.removeAt(selectedIndex)
                timingCues = SrtParser.shifted(kept, -timingShiftUs)
                clearTrimCutFields()
            }
            else -> return
        }
        setSelection(0, -1)
        updateTimingInfo()
        updateTimingEnabled()
    }

    private fun trimCutFieldsHaveInput(): Boolean {
        return timingTrimStartField.text.toString().isNotBlank() ||
            timingTrimEndField.text.toString().isNotBlank()
    }

    /**
     * Applies the typed trim boxes to the segment model. Returns
     * false (with a status message) when the numbers are invalid.
     * Blank boxes mean "no field edit" and leave the model alone, so
     * split/delete edits are never overwritten by stale boxes.
     */
    private fun applyTrimCutFields(): Boolean {
        if (!trimCutFieldsHaveInput()) return true
        val (trimStartUs, trimEndUs) = timingTrimRange()
        if (trimEndUs != Long.MAX_VALUE && trimEndUs <= trimStartUs) {
            timingStatusText.text = "End time must be after start time."
            return false
        }
        val durationUs = timingVideoDurationMs * 1_000L
        val endUs = if (trimEndUs != Long.MAX_VALUE) trimEndUs else durationUs
        if (endUs <= 0L) return true
        pushUndoSnapshot()
        val segments = mutableListOf<Pair<Long, Long>>()
        if (endUs > trimStartUs) segments.add(trimStartUs to endUs)
        timingVideoSegments = segments
        refreshEditorModels()
        setSelection(0, -1)
        return true
    }

    /** Segments for cue math: the model, or the full video when no
     * edit exists yet (so the info line works before a video pick). */
    private fun currentSegmentsForCues(): List<Pair<Long, Long>> {
        if (timingVideoSegments.isNotEmpty()) return timingVideoSegments
        val durationUs = timingVideoDurationMs * 1_000L
        return if (durationUs > 0L) {
            listOf(0L to durationUs)
        } else {
            listOf(0L to Long.MAX_VALUE)
        }
    }

    private fun musicDurationMs(uri: Uri): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(this, uri)
            retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            try {
                retriever.release()
            } catch (e: Exception) {
            }
        }
    }

    /**
     * Builds the export music sequence: song ranges for the clips
     * (looping the song inside each clip from its offset), silence
     * for the gaps, covering the whole video. Null when there is no
     * music, or when the song length is unknown (the caller then
     * falls back to the old full-loop music path).
     */
    private fun buildMusicItems(): List<MusicItem>? {
        val uri = timingMusicUri ?: return null
        if (timingMusicClips.isEmpty()) return null
        val videoDurUs = timingVideoDurationMs * 1_000L
        if (videoDurUs <= 0L) return null
        val songDurUs = timingMusicDurationMs * 1_000L
        if (songDurUs <= 0L) return null
        val items = mutableListOf<MusicItem>()
        var cursor = 0L
        for (clip in timingMusicClips.sortedBy { it.startUs }) {
            val cs = clip.startUs.coerceIn(0L, videoDurUs)
            val ce = clip.endUs.coerceIn(0L, videoDurUs)
            if (cs > cursor) addSilenceItems(items, cursor, cs)
            if (ce > cs) {
                var pos = clip.offsetUs % songDurUs
                var remain = ce - cs
                while (remain > 0L) {
                    val chunk = minOf(remain, songDurUs - pos)
                    items.add(MusicItem(uri, pos, pos + chunk, false, clip.volume))
                    remain -= chunk
                    pos = 0L
                }
            }
            if (ce > cursor) cursor = ce
        }
        if (cursor < videoDurUs) addSilenceItems(items, cursor, videoDurUs)
        return items
    }

    private fun addSilenceItems(
        items: MutableList<MusicItem>,
        fromUs: Long,
        toUs: Long
    ) {
        var remain = toUs - fromUs
        val maxChunk = 30_000_000L
        while (remain > 0L) {
            val chunk = minOf(remain, maxChunk)
            items.add(MusicItem(null, 0L, chunk, true))
            remain -= chunk
        }
    }

    // ---- end v0.7.0 ----

    private fun onTimingBurnClicked() {
        val video = timingVideoUri ?: return
        if (!applyTrimCutFields()) return
        if (timingVideoSegments.isEmpty()) {
            timingStatusText.text = "No video left after trimming."
            return
        }
        val useCover = timingCoverImageUri != null && timingCoverDurationUs > 0L
        val coverUs = if (useCover) timingCoverDurationUs else 0L
        val multiSegment = timingVideoSegments.size > 1 || useCover
        val cues = burnCues(multiSegment).let { list ->
            if (useCover) {
                list.map {
                    it.copy(startUs = it.startUs + coverUs, endUs = it.endUs + coverUs)
                }
            } else {
                list
            }
        }
        // v0.9.8: no subtitle/overlay gate here — a trim, music,
        // speed, mute or cover-only edit is a valid export.
        val photos = burnPhotoOverlays(multiSegment, coverUs)
        timingBusy = true
        updateTimingEnabled()
        timingDownloadButton.visibility = View.GONE
        timingLastOutput = null
        timingProgressBar.progress = 0
        timingStatusText.text = "Burning subtitles… 0%"
        timingPreviewVideo.stopPlayback()
        pauseTimingMusicPreview()
        timingPreviewHandler.removeCallbacks(timingPreviewPoller)
        try {
            val typeface = loadMyanmarTypeface()
            val outputFile = newOutputFile()
            val newBurner = SubtitleBurner(this)
            timingBurner = newBurner
            // v0.7.0: one segment = the proven single-item path (clip
            // bounds); several = the Composition join path.
            val (clipStartUs, clipEndUs) = if (multiSegment) {
                0L to androidx.media3.common.C.TIME_END_OF_SOURCE
            } else {
                timingVideoSegments.single()
            }
            val segmentsArg =
                if (multiSegment) timingVideoSegments.toList() else null
            val musicItems = buildMusicItems()?.let { items ->
                if (useCover) {
                    listOf(MusicItem(null, 0L, coverUs, true)) + items
                } else {
                    items
                }
            }
            val useLegacyMusic = musicItems == null &&
                timingMusicUri != null && timingMusicClips.isNotEmpty()
            val topText = timingTopTextField.text.toString().trim()
                .takeIf { it.isNotEmpty() }
            newBurner.start(
                video, cues, typeface, outputFile, timingBurnCallback,
                clipStartUs, clipEndUs, topText,
                segmentsArg, timingSpeed,
                if (useLegacyMusic) timingMusicUri else null,
                timingMuteCheck.isChecked, multiSegment,
                musicItems, timingVideoVolume, timingMusicVolume,
                timingTitleXFrac, timingTitleTopFrac, photos,
                timingCoverImageUri?.takeIf { useCover }, coverUs
            )
        } catch (e: Exception) {
            timingBusy = false
            updateTimingEnabled()
            timingStatusText.text = "Error: ${e.message ?: "unknown error"}"
        }
    }

    private fun onTimingSaveSrtClicked() {
        if (!applyTrimCutFields()) return
        val cues = effectiveTimingCues()
        if (cues.isEmpty()) {
            timingStatusText.text = "No subtitles left after shifting."
            return
        }
        timingBusy = true
        updateTimingEnabled()
        timingStatusText.text = "Saving SRT…"
        Thread {
            val savedName = saveSrtToDownloads(SrtParser.toSrtText(cues))
            runOnUiThread {
                timingBusy = false
                updateTimingEnabled()
                timingProgressBar.progress = 100
                if (savedName != null) {
                    timingStatusText.text =
                        "Done — SRT saved to Download/zhang file:\n$savedName"
                } else {
                    timingStatusText.text = "Error: could not save SRT."
                }
            }
        }.start()
    }

    /** v0.7.8: adds a typed caption at the playhead (3 seconds),
     * so subtitles can be made without an SRT file. The cue joins
     * timingCues, so it burns, saves, splits and deletes like any
     * loaded cue. Cues are stored unshifted; the playhead is on the
     * shifted (display) timeline, so shift is subtracted back. */
    private fun onAddManualCue() {
        val text = timingManualTextField.text.toString().trim()
        if (text.isEmpty()) {
            timingStatusText.text = "Type some text."
            return
        }
        val durationUs = timingVideoDurationMs * 1_000L
        if (durationUs <= 0L) {
            timingStatusText.text = "Pick a video first."
            return
        }
        val p = playheadUs().coerceIn(0L, durationUs)
        val shiftedEnd = minOf(p + timingManualCueDurationUs, durationUs)
        if (shiftedEnd <= p) {
            timingStatusText.text = "The playhead is at the end of the video."
            return
        }
        pushUndoSnapshot()
        val cue = SubtitleCue(
            p - timingShiftUs, shiftedEnd - timingShiftUs, text,
            timingNewCueColor, timingNewCueSizeScale,
            timingNewCueXFrac, timingNewCueYFrac
        )
        timingCues = (timingCues + cue).sortedBy { it.startUs }
        timingManualTextField.setText("")
        timingSrtLabel.text = "${timingCues.size} subtitles"
        timingDeleteSrtButton.visibility = View.VISIBLE
        setSelection(0, -1)
        refreshEditorModels()
        updateTimingInfo()
        updateTimingEnabled()
        timingStatusText.text =
            "Text added — shows at ${formatClockUs(p)} for " +
            "${fmtSeconds(timingManualCueDurationUs / 1_000_000.0)} seconds."
    }

    /** v0.7.9: VN-style cue drag — the track reports the moved cue in
     * shifted (display) space; convert back to stored space, keep the
     * list sorted, and keep the moved cue selected. */
    /** v0.8.1: a video segment was edge-trimmed on the strip. */
    private fun onVideoSegmentResized(index: Int, newStartUs: Long, newEndUs: Long) {
        if (index !in timingVideoSegments.indices) return
        val (s, e) = timingVideoSegments[index]
        if (newStartUs == s && newEndUs == e) return
        pushUndoSnapshot()
        timingVideoSegments[index] = newStartUs to newEndUs
        refreshEditorModels()
        setSelection(1, index)
        updateTimingInfo()
        updateTimingEnabled()
    }

    /** v0.8.2: lengthen/shorten the selected subtitle by deltaUs
     * (buttons in the subtitle panel — the precise route for tiny
     * cues that are hard to grab on the track). */
    private fun onAdjustSelectedCueDuration(deltaUs: Long) {
        if (selectedTrack != 3) return
        val shifted = SrtParser.shifted(timingCues, timingShiftUs)
        if (selectedIndex !in shifted.indices) return
        val cue = shifted[selectedIndex]
        val minEnd = cue.startUs + 500_000L
        val nextStart = shifted.getOrNull(selectedIndex + 1)?.startUs
            ?: Long.MAX_VALUE
        val cap = maxOf(minEnd, nextStart)
        val newEnd = (cue.endUs + deltaUs).coerceIn(minEnd, cap)
        if (newEnd == cue.endUs) return
        val moved = cue.copy(endUs = newEnd)
        pushUndoSnapshot()
        val updated = shifted.toMutableList()
        updated[selectedIndex] = moved
        val stored = SrtParser.shifted(updated, -timingShiftUs)
            .sortedBy { it.startUs }
        timingCues = stored
        val storedMoved = moved.copy(
            startUs = moved.startUs - timingShiftUs,
            endUs = moved.endUs - timingShiftUs
        )
        refreshEditorModels()
        setSelection(3, stored.indexOf(storedMoved))
    }

    /** v0.9.2: a music clip was moved/resized on the track. */
    private fun onMusicClipMoved(
        index: Int, newStartUs: Long, newEndUs: Long, newOffsetUs: Long
    ) {
        if (index !in timingMusicClips.indices) return
        val orig = timingMusicClips[index]
        val moved = orig.copy(
            startUs = newStartUs, endUs = newEndUs, offsetUs = newOffsetUs
        )
        if (moved == orig) return
        pushUndoSnapshot()
        timingMusicClips[index] = moved
        refreshEditorModels()
        setSelection(2, index)
    }

    private fun onSrtCueMoved(index: Int, newStartUs: Long, newEndUs: Long) {
        val shifted = SrtParser.shifted(timingCues, timingShiftUs)
        if (index !in shifted.indices) return
        val moved = shifted[index].copy(startUs = newStartUs, endUs = newEndUs)
        if (moved.startUs == shifted[index].startUs &&
            moved.endUs == shifted[index].endUs
        ) return
        pushUndoSnapshot()
        val updated = shifted.toMutableList()
        updated[index] = moved
        val stored = SrtParser.shifted(updated, -timingShiftUs)
            .sortedBy { it.startUs }
        timingCues = stored
        val storedMoved = moved.copy(
            startUs = moved.startUs - timingShiftUs,
            endUs = moved.endUs - timingShiftUs
        )
        setSelection(3, stored.indexOf(storedMoved))
        refreshEditorModels()
        updateTimingInfo()
        updateTimingEnabled()
    }

    /** v0.7.9: VN-style Edit — rewrite the selected cue's text from
     * the manual text field (prefilled when the cue is selected). */
    private fun onEditSelectedCueText() {
        val text = timingManualTextField.text.toString().trim()
        if (selectedTrack != 3 || selectedIndex < 0) {
            timingStatusText.text = "Tap the subtitle you want to edit first."
            return
        }
        if (text.isEmpty()) {
            timingStatusText.text = "Type some text."
            return
        }
        val shifted = SrtParser.shifted(timingCues, timingShiftUs)
        if (selectedIndex !in shifted.indices) return
        pushUndoSnapshot()
        val updated = shifted.toMutableList()
        updated[selectedIndex] = updated[selectedIndex].copy(text = text)
        timingCues = SrtParser.shifted(updated, -timingShiftUs)
        refreshEditorModels()
        updateTimingInfo()
        timingStatusText.text = "Text updated."
    }

    /** v0.7.8: saves the frame at the playhead as a cover JPG in
     * Download/zhang file/. */
    /** v0.9.7: intro cover image picked — shown at the export start. */
    private fun onCoverImagePicked(uri: Uri) {
        timingCoverImageUri = uri
        if (::timingCoverPreview.isInitialized) {
            timingCoverPreview.setImageURI(uri)
        }
        refreshCoverDurationLabel()
        timingStatusText.text =
            "Intro image set — shows for the first ${coverDurationLabel()} of the export."
    }

    private fun coverDurationLabel(): String {
        val tenths = timingCoverDurationUs / 100_000L
        return "${tenths / 10}.${tenths % 10}s"
    }

    private fun refreshCoverDurationLabel() {
        if (::timingCoverDurationLabel.isInitialized) {
            timingCoverDurationLabel.text = coverDurationLabel()
        }
    }

    private fun onTimingCoverClicked() {
        val uri = timingVideoUri ?: return
        val posUs = playheadUs()
        timingCoverButton.isEnabled = false
        timingStatusText.text = "Making the cover image…"
        Thread {
            try {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(this, uri)
                    val frame = retriever.getFrameAtTime(
                        posUs, MediaMetadataRetriever.OPTION_CLOSEST
                    ) ?: throw IOException("Could not grab a frame.")
                    val stream = ByteArrayOutputStream()
                    frame.compress(Bitmap.CompressFormat.JPEG, 90, stream)
                    val name = saveBytesToDownloads(
                        stream.toByteArray(),
                        "zhang-studio-cover-${stamp()}.jpg",
                        "image/jpeg"
                    )
                    runOnUiThread {
                        timingCoverButton.isEnabled = true
                        timingStatusText.text = if (name != null) {
                            "Done — saved to Download/zhang file:\n$name"
                        } else {
                            "Error: could not save."
                        }
                    }
                } finally {
                    try {
                        retriever.release()
                    } catch (e: Exception) {
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    timingCoverButton.isEnabled = true
                    timingStatusText.text = "Error: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    /** v0.8.0: VN-style timeline width — at least the viewport,
     * and ~12dp per second of video, so long videos scroll
     * instead of squashing every cue into a sliver. */
    private fun timelineContentWidthPx(): Int {
        val density = resources.displayMetrics.density
        val viewportPx =
            (resources.displayMetrics.widthPixels - dp(84)).coerceAtLeast(1)
        val durationPx = (timingVideoDurationMs * 0.012f * density).toInt()
        return maxOf(viewportPx, durationPx)
    }

    /** v0.8.0: applies the timeline width to all four track views. */
    private fun updateTimelineWidths() {
        timingTrackContentWidthPx = timelineContentWidthPx()
        val w = timingTrackContentWidthPx
        if (::timingMusicTrack.isInitialized) setTrackWidth(timingMusicTrack, w)
        if (::timingSrtTrack.isInitialized) setTrackWidth(timingSrtTrack, w)
        if (::timingOverlayTrack.isInitialized) setTrackWidth(timingOverlayTrack, w)
        if (::timingVideoStrip.isInitialized) setTrackWidth(timingVideoStrip, w)
        if (::timingRuler.isInitialized) setTrackWidth(timingRuler, w)
    }

    private fun setTrackWidth(view: View, widthPx: Int) {
        val lp = view.layoutParams ?: return
        if (lp.width != widthPx) {
            lp.width = widthPx
            view.layoutParams = lp
        }
    }

    /** v0.8.0: seek + keep the playhead on screen (VN-style). */
    private fun seekTimingPreview(ms: Int) {
        timingPreviewVideo.seekTo(ms)
        ensurePlayheadVisible(ms.toLong())
    }

    private fun ensurePlayheadVisible(posMs: Long) {
        if (!::timingTimelineScroll.isInitialized) return
        if (timingVideoDurationMs <= 0) return
        val contentW = timingTrackContentWidthPx
        if (contentW <= 0) return
        val scroll = timingTimelineScroll
        val viewW = scroll.width
        if (viewW <= 0) return
        val px = (posMs.toFloat() / timingVideoDurationMs * contentW).toInt()
        val x = scroll.scrollX
        val margin = dp(40)
        when {
            px < x + margin -> scroll.scrollTo((px - margin).coerceAtLeast(0), 0)
            px > x + viewW - margin -> scroll.scrollTo(px - viewW + margin, 0)
        }
    }

    private fun updateTimingEnabled() {
        // v0.9.8: exporting needs only a picked video. Trim-only,
        // music-only, speed-only, mute-only and cover-only edits
        // are all real exports (VN/CapCut behave the same); the
        // old subtitles-or-overlays gate left Export dead for
        // exactly those edits. Saving an SRT still needs cues.
        val ready = !timingBusy && timingVideoUri != null
        timingBurnButton.isEnabled = ready
        timingSaveSrtButton.isEnabled =
            !timingBusy && timingVideoUri != null && timingCues.isNotEmpty()
        if (::timingCoverButton.isInitialized) {
            timingCoverButton.isEnabled = !timingBusy && timingVideoUri != null
        }
        timingPickVideoButton.isEnabled = !timingBusy
        timingChangeVideoButton.isEnabled = !timingBusy
        timingPickSrtButton.isEnabled = !timingBusy
    }

    private fun refreshSpeedButtons() {
        for ((button, speed) in timingSpeedButtons) {
            val selected = Math.abs(speed - timingSpeed) < 0.01f
            button.background = pillBg(
                if (selected) Color.rgb(30, 107, 74) else Color.WHITE,
                if (selected) Color.rgb(76, 175, 125) else null,
                2
            )
            button.setTextColor(if (selected) Color.WHITE else Color.BLACK)
        }
        if (::timingSpeedLabel.isInitialized) {
            timingSpeedLabel.text =
                "Speed: ${"%.2f".format(timingSpeed)}x"
        }
        if (::timingSpeedBadge.isInitialized) {
            timingSpeedBadge.text = "Speed: ${formatSpeedLabel(timingSpeed)}x"
        }
        if (::timingSpeedSlider.isInitialized) {
            val progress = Math.round((timingSpeed - 0.25f) / 0.05f)
                .coerceIn(0, 75)
            if (timingSpeedSlider.progress != progress) {
                timingSpeedSlider.progress = progress
            }
        }
    }

    /** v0.9.8: Myanmar digits (\u1040-\u1049) from a Myanmar
     * keyboard parse as 0-9, so the trim boxes never silently
     * ignore them. */
    private fun normalizeTrimDigits(s: String): String {
        val out = StringBuilder(s.length)
        for (ch in s) {
            out.append(
                if (ch in '\u1040'..'\u1049') '0' + (ch - '\u1040')
                else ch
            )
        }
        return out.toString()
    }

    /** Trim range from the trim fields, in microseconds. Blank/invalid
     * start = 0; blank/invalid end = no end trim (Long.MAX_VALUE). */
    private fun timingTrimRange(): Pair<Long, Long> {
        val startSecs = normalizeTrimDigits(
            timingTrimStartField.text.toString().trim()
        ).toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
        val endSecs = normalizeTrimDigits(
            timingTrimEndField.text.toString().trim()
        ).toDoubleOrNull()?.coerceAtLeast(0.0)
        val startUs = (startSecs * 1_000_000).toLong()
        val endUs = if (endSecs == null) Long.MAX_VALUE else (endSecs * 1_000_000).toLong()
        return startUs to endUs
    }

    /** Cues on the OUTPUT timeline (shift, segments, speed) — what
     * the SRT save and the info line use. */
    private fun effectiveTimingCues(): List<SubtitleCue> {
        val cues = SrtParser.rebased(
            SrtParser.shifted(timingCues, timingShiftUs),
            currentSegmentsForCues()
        )
        return SrtParser.scaled(cues, timingSpeed)
    }

    /** Cues for the burn. With a multi-segment edit the overlay runs
     * at Composition level on the output timeline (scaled); otherwise
     * it runs at item level on content timestamps (unscaled). */
    private fun burnCues(cutRequested: Boolean): List<SubtitleCue> {
        val cues = SrtParser.rebased(
            SrtParser.shifted(timingCues, timingShiftUs),
            currentSegmentsForCues()
        )
        return if (cutRequested) SrtParser.scaled(cues, timingSpeed) else cues
    }

    private fun updateTimingInfo() {
        if (::timingSrtTrack.isInitialized) {
            timingSrtTrack.setCues(SrtParser.shifted(timingCues, timingShiftUs))
        }
        if (timingCues.isEmpty()) {
            timingInfoText.text = ""
            return
        }
        val shifted = effectiveTimingCues()
        if (shifted.isEmpty()) {
            timingInfoText.text = "No subtitles left after shifting."
            return
        }
        timingInfoText.text =
            "${shifted.size} subtitles — first one starts at ${formatClockUs(shifted.first().startUs)}"
    }

    /** Polls the server until the job finishes (about 10 minutes max). */
    private fun pollUntilDone(
        client: TranscribeClient,
        jobId: String,
        maxWaits: Int = 150
    ): TranscribeClient.JobState {
        var failures = 0
        var waited = 0
        while (waited < maxWaits) {
            val state = try {
                client.poll(jobId)
            } catch (e: IOException) {
                failures++
                // v0.9.9: 12 x 4s — his connection regularly dies for
                // 30-60s at a time; 5 was giving up too early.
                if (failures > 12) {
                    throw IOException("Server နဲ့ အဆက်ပြတ်သွားတယ်။ ထပ်စမ်းပါ။")
                }
                null
            }
            if (state != null) {
                failures = 0
                when (state.status) {
                    "done" -> return state
                    "error" -> throw IOException(state.error ?: "Server error")
                    // "pending": keep waiting.
                }
            }
            Thread.sleep(4000)
            waited++
        }
        throw IOException("အချိန်ကြာလွန်းတယ်။ ထပ်စမ်းပါ။")
    }

    private fun waitForJob(client: TranscribeClient, jobId: String): String {
        val state = pollUntilDone(client, jobId)
        return state.srt ?: throw IOException("Server returned no subtitles")
    }

    private fun postStatus(text: String) {
        runOnUiThread { setStatus(text) }
    }

    private fun postError(message: String) {
        runOnUiThread {
            setBusy(false)
            setStatus("အမှား: $message")
        }
    }

    // ---------- helpers ----------

    private fun titleText(text: String, size: Float): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
    }

    private fun sectionLabel(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 17f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(Color.WHITE)
    }

    private fun hintText(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(Color.rgb(235, 235, 235))
        gravity = Gravity.CENTER
    }

    private fun pillBg(color: Int, strokeColor: Int?, strokeWidthDp: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(30).toFloat()
            setColor(color)
            if (strokeColor != null) setStroke(dp(strokeWidthDp), strokeColor)
        }

    private fun pillButton(text: String, bg: Int, fg: Int, stroke: Int?): Button =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 18f
            setTextColor(fg)
            background = pillBg(bg, stroke, 2)
            setPadding(dp(20), dp(12), dp(20), dp(12))
        }

    private fun menuCard(emoji: String, title: String, subtitle: String, onClick: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(18).toFloat()
                setColor(Color.WHITE)
            }
            setPadding(dp(16), dp(14), dp(16), dp(14))
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        }
        val chip = TextView(this).apply {
            text = emoji
            textSize = 26f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(12).toFloat()
                setColor(Color.rgb(228, 244, 234))
            }
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        row.addView(chip)
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        texts.addView(TextView(this).apply {
            text = title
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.rgb(18, 32, 25))
        })
        texts.addView(TextView(this).apply {
            text = subtitle
            textSize = 13f
            setTextColor(Color.rgb(90, 107, 96))
        })
        row.addView(texts)
        return row
    }

    private fun ctaBg(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(Color.rgb(47, 163, 107), Color.rgb(30, 107, 74))
    ).apply {
        cornerRadius = dp(30).toFloat()
    }

    private fun ctaButton(text: String): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 18f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(Color.WHITE)
        background = ctaBg()
        setPadding(dp(20), dp(12), dp(20), dp(12))
    }

    private fun cardBg(): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(16).toFloat()
        setColor(Color.rgb(21, 36, 29))
        setStroke(dp(2), Color.rgb(42, 63, 52))
    }

    private fun infoCard(text: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = cardBg()
        setPadding(dp(16), dp(14), dp(16), dp(14))
        addView(TextView(context).apply {
            this.text = text
            textSize = 15f
            setTextColor(Color.rgb(220, 235, 225))
            gravity = Gravity.CENTER
        })
    }

    private fun rowParams(topDp: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(topDp) }

    /**
     * Bundled Noto Sans Myanmar (shapes Myanmar correctly with
     * StaticLayout). Falls back to the system default typeface if the
     * asset is missing — most Android devices ship a Myanmar font.
     */
    private fun loadMyanmarTypeface(): Typeface {
        return try {
            Typeface.createFromAsset(assets, "NotoSansMyanmar-Regular.ttf")
        } catch (e: Exception) {
            Typeface.DEFAULT
        }
    }

    companion object {
        // All downloads go into a "zhang file" folder inside Downloads,
        // so the app's videos, audio and SRTs stay together in one place.
        // MediaStore creates the subfolder automatically on Android 10+.
        const val DOWNLOADS_FOLDER = "Download/zhang file"
    }

    /**
     * Copies [source] into the public Downloads folder (MediaStore, no
     * storage permission needed for the app's own files on Android 10+).
     * Returns the file name on success, null on failure (or on Android
     * older than 10, where the private path is reported instead). The
     * private temp file is deleted after a successful copy.
     */
    private fun copyToDownloads(source: File, mimeType: String): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, source.name)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, DOWNLOADS_FOLDER)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return null
            contentResolver.openOutputStream(uri)?.use { out ->
                FileInputStream(source).use { it.copyTo(out) }
            } ?: return null
            source.delete()
            source.name
        } catch (e: Exception) {
            null
        }
    }

    /** Writes bytes straight into the public Downloads folder. */
    private fun saveBytesToDownloads(bytes: ByteArray, name: String, mimeType: String): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, DOWNLOADS_FOLDER)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return null
            contentResolver.openOutputStream(uri)?.use { out ->
                out.write(bytes)
            } ?: return null
            name
        } catch (e: Exception) {
            null
        }
    }

    /** Writes SRT text straight into the public Downloads folder. */
    private fun saveSrtToDownloads(srtText: String): String? {
        return saveBytesToDownloads(
            srtText.toByteArray(Charsets.UTF_8),
            "zhang-studio-${stamp()}.srt",
            "application/x-subrip"
        )
    }

    private fun stamp(): String =
        SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())

    /** Copies a picked content Uri to a cache file for upload. */
    @Throws(IOException::class)
    private fun copyUriToCache(uri: Uri, prefix: String): File {
        val tmp = File(cacheDir, "$prefix-${stamp()}.jpg")
        contentResolver.openInputStream(uri)?.use { input ->
            tmp.outputStream().use { output -> input.copyTo(output) }
        } ?: throw IOException("Could not open the image")
        return tmp
    }

    /** Output goes to the app's private Movies folder (no storage permission needed). */
    private fun newOutputFile(): File {
        val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: cacheDir
        if (!dir.exists()) dir.mkdirs()
        return File(dir, "zhang-studio-subtitled-${stamp()}.mp4")
    }

    private fun formatClockUs(timeUs: Long): String {
        val totalSeconds = timeUs / 1_000_000L
        val minutes = totalSeconds / 60L
        val seconds = totalSeconds % 60L
        return "%02d:%02d".format(minutes, seconds)
    }

    /** v0.9.4: MM:SS.cc (demo-style total time). */
    private fun formatClockUsCs(timeUs: Long): String {
        val totalCs = timeUs / 10_000L
        val minutes = totalCs / 6000L
        val seconds = (totalCs % 6000L) / 100L
        val cs = totalCs % 100L
        return "%02d:%02d.%02d".format(minutes, seconds, cs)
    }

    /** v0.9.4: speed label with 1 decimal when exact ("1.0"),
     * else 2 ("1.25") — the demo badge shows "Speed: 1.0x". */
    private fun formatSpeedLabel(speed: Float): String {
        val one = "%.1f".format(speed)
        return if (one.toFloatOrNull() == speed) one else "%.2f".format(speed)
    }

    private fun fmtSeconds(seconds: Double): String {
        return if (seconds == seconds.toInt().toDouble()) {
            seconds.toInt().toString()
        } else {
            "%.1f".format(seconds)
        }
    }

    private fun updateMakeEnabled() {
        makeButton.isEnabled = videoUri != null
    }

    private fun setBusy(busy: Boolean) {
        pickVideoButton.isEnabled = !busy
        makeButton.isEnabled = !busy && videoUri != null
    }

    private fun setStatus(text: String) {
        statusText.text = text
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
