package com.zhangstudio.app

import android.content.ContentValues
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.util.UnstableApi
import java.io.File
import java.io.FileInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Automatic flow: pick a video, tap one button, get a subtitled video.
 * The app uploads the video to the Zhang Studio server (Gemini listens
 * and returns Myanmar subtitles), then burns those subtitles into the
 * video on the phone CPU (Media3 Transformer, hardware encoding).
 *
 * No SRT file step — the server produces the subtitles. The Gemini API
 * key lives on the server only, never in the app.
 *
 * All errors surface as status text — the app never crashes on bad input.
 * Rotating the phone during a burn cancels the export (same as before).
 */
@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {

    private var videoUri: Uri? = null
    private var burner: SubtitleBurner? = null

    private lateinit var pickVideoButton: Button
    private lateinit var videoLabel: TextView
    private lateinit var makeButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView

    private val pickVideoLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                videoUri = uri
                videoLabel.text = "Video: ${uri.lastPathSegment ?: uri}"
                updateMakeEnabled()
            }
        }

    private val burnCallback = object : SubtitleBurner.Callback {
        override fun onProgress(percent: Int) {
            progressBar.progress = percent
            setStatus("Burning subtitles… $percent%")
        }

        override fun onCompleted(outputPath: String) {
            // Move the finished video into the public Downloads folder so it
            // is easy to find (copy runs off the main thread: big files).
            Thread {
                val savedName = copyToDownloads(File(outputPath))
                runOnUiThread {
                    setBusy(false)
                    progressBar.progress = 100
                    if (savedName != null) {
                        setStatus("Done — saved in Downloads:\n$savedName")
                    } else {
                        setStatus("Done — output saved at:\n$outputPath")
                    }
                }
            }.start()
        }

        override fun onError(message: String) {
            setBusy(false)
            setStatus("Error: $message")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = dp(16)
            setPadding(pad, pad, pad, pad)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val title = TextView(this).apply {
            text = "Zhang Studio — Subtitle Burner"
            textSize = 20f
        }
        pickVideoButton = Button(this).apply { text = "Pick video" }
        videoLabel = TextView(this).apply { text = "No video selected" }
        makeButton = Button(this).apply {
            text = "Make subtitled video"
            isEnabled = false
        }
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        statusText = TextView(this).apply { text = "Pick a video to start." }

        pickVideoButton.setOnClickListener { pickVideoLauncher.launch("video/*") }
        makeButton.setOnClickListener { onMakeClicked() }

        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
        root.addView(title, params)
        root.addView(pickVideoButton, params)
        root.addView(videoLabel, params)
        root.addView(makeButton, params)
        root.addView(progressBar, params)
        root.addView(statusText, params)

        setContentView(root)
    }

    override fun onDestroy() {
        burner?.cancel()
        burner = null
        super.onDestroy()
    }

    private fun onMakeClicked() {
        val video = videoUri ?: return
        setBusy(true)
        progressBar.progress = 0
        setStatus("Uploading video…")
        Thread {
            try {
                val fileName = video.lastPathSegment ?: "video.mp4"
                postStatus("Listening with Gemini… (may take 1–3 min)")
                val srtText = TranscribeClient(contentResolver).transcribe(video, fileName)
                val cues = SrtParser.parse(srtText)
                if (cues.isEmpty()) {
                    postError("No speech found in this video.")
                    return@Thread
                }
                // Transformer must start on the main thread.
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    try {
                        val typeface = loadMyanmarTypeface()
                        val outputFile = newOutputFile()
                        val newBurner = SubtitleBurner(this)
                        burner = newBurner
                        setStatus("Burning subtitles… 0%")
                        newBurner.start(video, cues, typeface, outputFile, burnCallback)
                    } catch (e: Exception) {
                        setBusy(false)
                        setStatus("Error: ${e.message ?: "unknown error"}")
                    }
                }
            } catch (e: Exception) {
                postError(e.message ?: "unknown error")
            }
        }.start()
    }

    private fun postStatus(text: String) {
        runOnUiThread { setStatus(text) }
    }

    private fun postError(message: String) {
        runOnUiThread {
            setBusy(false)
            setStatus("Error: $message")
        }
    }

    /**
     * Bundled Noto Sans Myanmar (shapes Myanmar correctly with
     * StaticLayout). Falls back to the system default typeface if the
     * asset is missing — most Android devices ship a Myanmar font.
     */
    private fun loadMyanmarTypeface(): Typeface {
        return try {
            Typeface.createFromAsset(assets, "NotoSansMyanmar-Regular.ttf")
        } catch (e: Exception) {
            Typeface.DEFAULT
        }
    }

    /**
     * Copies [source] into the public Downloads folder (MediaStore, no
     * storage permission needed for the app's own files on Android 10+).
     * Returns the file name on success, null on failure (or on Android
     * older than 10, where the private path is reported instead). The
     * private temp file is deleted after a successful copy.
     */
    private fun copyToDownloads(source: File): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, source.name)
                put(MediaStore.Downloads.MIME_TYPE, "video/mp4")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return null
            contentResolver.openOutputStream(uri)?.use { out ->
                FileInputStream(source).use { it.copyTo(out) }
            } ?: return null
            source.delete()
            source.name
        } catch (e: Exception) {
            null
        }
    }

    /** Output goes to the app's private Movies folder (no storage permission needed). */
    private fun newOutputFile(): File {
        val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: cacheDir
        if (!dir.exists()) dir.mkdirs()
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        return File(dir, "zhang-studio-subtitled-$stamp.mp4")
    }

    private fun updateMakeEnabled() {
        makeButton.isEnabled = videoUri != null
    }

    private fun setBusy(busy: Boolean) {
        pickVideoButton.isEnabled = !busy
        makeButton.isEnabled = !busy && videoUri != null
    }

    private fun setStatus(text: String) {
        statusText.text = text
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
