package com.zhangstudio.app

import android.content.ContentValues
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.util.UnstableApi
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Zhang Studio v0.3.0 — three screens over the studio photo background:
 * 1. Login: Gemini API Key, entered once and remembered.
 * 2. Menu: the five features (two work now; the rest say "coming soon").
 * 3. Work: pick a video, tap one button.
 *    - Subtitle mode: upload -> Gemini SRT -> burn on the phone CPU ->
 *      finished video straight into Downloads.
 *    - SRT mode: upload -> Gemini SRT -> SRT file straight into Downloads.
 *
 * The server is polled for job status (async jobs), so slow connections
 * never hit a single long request that times out. A sync (v13) server
 * still works: the submit call then returns the SRT directly.
 *
 * All errors surface as status text — the app never crashes on bad input.
 * Rotating the phone during a burn cancels the export.
 */
@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {

    private val modeSubtitle = 1
    private val modeSrt = 2
    private var mode = modeSubtitle

    private var videoUri: Uri? = null
    private var burner: SubtitleBurner? = null
    private var apiKey: String = ""

    private val prefs by lazy { getSharedPreferences("zhang_studio", MODE_PRIVATE) }

    private lateinit var loginScreen: View
    private lateinit var menuScreen: View
    private lateinit var workScreen: View
    private lateinit var keyField: EditText
    private lateinit var loginStatus: TextView
    private lateinit var workTitle: TextView
    private lateinit var pickVideoButton: Button
    private lateinit var videoLabel: TextView
    private lateinit var makeButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView

    private val pickVideoLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                videoUri = uri
                videoLabel.text = "Video: ${uri.lastPathSegment ?: uri}"
                updateMakeEnabled()
            }
        }

    private val burnCallback = object : SubtitleBurner.Callback {
        override fun onProgress(percent: Int) {
            progressBar.progress = percent
            setStatus("စာတန်းထည့်နေတယ်… $percent%")
        }

        override fun onCompleted(outputPath: String) {
            // Move the finished video into the public Downloads folder so
            // it is easy to find (copy runs off the main thread: big files).
            Thread {
                val savedName = copyToDownloads(File(outputPath), "video/mp4")
                runOnUiThread {
                    setBusy(false)
                    progressBar.progress = 100
                    if (savedName != null) {
                        setStatus("ပြီးပြီ — Downloads ထဲ သိမ်းပြီးပြီ:\n$savedName")
                    } else {
                        setStatus("ပြီးပြီ — သိမ်းထားတဲ့ နေရာ:\n$outputPath")
                    }
                }
            }.start()
        }

        override fun onError(message: String) {
            setBusy(false)
            setStatus("အမှား: $message")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        apiKey = prefs.getString("gemini_api_key", "").orEmpty()

        val root = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.rgb(17, 20, 24))
        }

        // Studio photo background + dark overlay for readable text.
        try {
            val bmp = assets.open("studio_bg.jpg").use { BitmapFactory.decodeStream(it) }
            if (bmp != null) {
                root.addView(ImageView(this).apply {
                    setImageBitmap(bmp)
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                })
            }
        } catch (e: Exception) {
            // No background image: the dark solid color stays.
        }
        root.addView(View(this).apply {
            setBackgroundColor(Color.argb(110, 0, 0, 0))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        })

        loginScreen = buildLoginScreen()
        menuScreen = buildMenuScreen()
        workScreen = buildWorkScreen()
        root.addView(loginScreen)
        root.addView(menuScreen)
        root.addView(workScreen)
        setContentView(root)

        if (apiKey.isBlank()) showScreen(loginScreen) else showScreen(menuScreen)
    }

    override fun onDestroy() {
        burner?.cancel()
        burner = null
        super.onDestroy()
    }

    // ---------- screens ----------

    private fun showScreen(screen: View) {
        loginScreen.visibility = if (screen === loginScreen) View.VISIBLE else View.GONE
        menuScreen.visibility = if (screen === menuScreen) View.VISIBLE else View.GONE
        workScreen.visibility = if (screen === workScreen) View.VISIBLE else View.GONE
    }

    private fun screenColumn(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val pad = dp(24)
        setPadding(pad, dp(48), pad, pad)
        layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    private fun wrapScroll(column: LinearLayout): ScrollView = ScrollView(this).apply {
        layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        addView(column)
    }

    private fun buildLoginScreen(): View {
        val col = screenColumn()
        col.addView(titleText("ZHANG Studio", 32f))
        col.addView(titleText("မှ ကြိုဆိုပါတယ်", 26f))

        val banner = TextView(this).apply {
            text = "Gemini API Key ထည့်ပြီး\nစတင် အသုံးပြုနိုင်ပါပြီ"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = pillBg(Color.rgb(13, 84, 96), Color.rgb(72, 199, 214), 2)
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        col.addView(banner, rowParams(dp(40)))

        keyField = EditText(this).apply {
            hint = "API Key"
            textSize = 18f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            setSingleLine(true)
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(22), dp(14), dp(22), dp(14))
            if (apiKey.isNotBlank()) setText(apiKey)
        }
        col.addView(keyField, rowParams(dp(24)))

        val loginButton = pillButton("Login", Color.rgb(35, 35, 35), Color.WHITE, null)
        loginButton.setOnClickListener { onLoginClicked() }
        col.addView(loginButton, rowParams(dp(16)))

        loginStatus = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.rgb(255, 213, 74))
            gravity = Gravity.CENTER
        }
        col.addView(loginStatus, rowParams(dp(12)))

        col.addView(hintText("Key ကို aistudio.google.com/apikey မှာ အခမဲ့ ရယူနိုင်ပါတယ်"),
            rowParams(dp(24)))
        return wrapScroll(col)
    }

    private fun buildMenuScreen(): View {
        val col = screenColumn()
        col.addView(titleText("ZHANG Studio", 30f))
        col.addView(titleText("လုပ်ဆောင်ချက်များ ရွေးချယ်ပါ", 20f))

        val green = Color.rgb(30, 107, 74)
        val greenStroke = Color.rgb(76, 175, 125)
        val items = listOf(
            "SRT သီးသန့်ထုတ်ရန်" to modeSrt,
            "Video ကို မြန်မာစာတန်းထိုးပေးရန်" to modeSubtitle,
            "ရေးထားသောစာများကို\nAI အသံဖြင့် ဖတ်ပြရန်" to 0,
            "Video များကို မြန်မာအသံဖြင့်\nပြောပြပေးရန်" to 0,
            "SRT နှင့် Video တွဲရန် နှင့်\nစာသား အတိုအရှည် စိတ်ကြိုက်ချိန်ရန်" to 0
        )
        for ((label, targetMode) in items) {
            val b = pillButton(label, Color.WHITE, green, greenStroke)
            b.setOnClickListener {
                if (targetMode == 0) {
                    Toast.makeText(this, "ဒီလုပ်ဆောင်ချက် မကြာမီ လာမည်", Toast.LENGTH_SHORT).show()
                } else {
                    openWork(targetMode)
                }
            }
            col.addView(b, rowParams(dp(18)))
        }

        val changeKey = TextView(this).apply {
            text = "API Key ပြောင်းရန်"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        changeKey.setOnClickListener {
            keyField.setText(apiKey)
            loginStatus.text = ""
            showScreen(loginScreen)
        }
        col.addView(changeKey, rowParams(dp(18)))
        return wrapScroll(col)
    }

    private fun buildWorkScreen(): View {
        val col = screenColumn()
        workTitle = titleText("", 22f)
        col.addView(workTitle)

        pickVideoButton = pillButton("Video ရွေးပါ", Color.WHITE, Color.BLACK, null)
        pickVideoButton.setOnClickListener { pickVideoLauncher.launch("video/*") }
        col.addView(pickVideoButton, rowParams(dp(24)))

        videoLabel = TextView(this).apply {
            text = "Video မရွေးရသေးဘူး"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(videoLabel, rowParams(dp(12)))

        makeButton = pillButton("", Color.rgb(13, 84, 96), Color.WHITE, Color.rgb(72, 199, 214))
        makeButton.isEnabled = false
        makeButton.setOnClickListener { onMakeClicked() }
        col.addView(makeButton, rowParams(dp(12)))

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        col.addView(progressBar, rowParams(dp(16)))

        statusText = TextView(this).apply {
            text = "Video ရွေးပါ။"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(statusText, rowParams(dp(8)))

        val back = TextView(this).apply {
            text = "← Menu သို့ ပြန်သွားမယ်"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        back.setOnClickListener { showScreen(menuScreen) }
        col.addView(back, rowParams(dp(16)))
        return wrapScroll(col)
    }

    // ---------- actions ----------

    private fun onLoginClicked() {
        val key = keyField.text.toString().trim()
        if (key.isEmpty()) {
            loginStatus.text = "API Key ထည့်ပါ။"
            return
        }
        apiKey = key
        prefs.edit().putString("gemini_api_key", key).apply()
        loginStatus.text = ""
        showScreen(menuScreen)
    }

    private fun openWork(targetMode: Int) {
        mode = targetMode
        if (mode == modeSrt) {
            workTitle.text = "SRT သီးသန့်ထုတ်ရန်"
            makeButton.text = "SRT ထုတ်မယ်"
        } else {
            workTitle.text = "Video ကို မြန်မာစာတန်းထိုးပေးရန်"
            makeButton.text = "စာတန်းထိုးထားသော Video လုပ်မယ်"
        }
        setStatus("Video ရွေးပါ။")
        progressBar.progress = 0
        updateMakeEnabled()
        showScreen(workScreen)
    }

    private fun onMakeClicked() {
        val video = videoUri ?: return
        setBusy(true)
        progressBar.progress = 0
        setStatus("Video တင်နေတယ်…")
        Thread {
            try {
                val fileName = video.lastPathSegment ?: "video.mp4"
                val client = TranscribeClient(contentResolver)
                val srtText = when (val res = client.submit(video, fileName, apiKey)) {
                    is TranscribeClient.SubmitResult.Ready -> res.srt
                    is TranscribeClient.SubmitResult.Job -> {
                        postStatus("Gemini က အသံနားထောင်နေတယ်… (၁-၃ မိနစ် ကြာနိုင်တယ်)")
                        waitForJob(client, res.jobId)
                    }
                }
                val cues = SrtParser.parse(srtText)
                if (cues.isEmpty()) {
                    postError("ဒီ Video မှာ အသံမတွေ့ဘူး။")
                    return@Thread
                }
                if (mode == modeSrt) {
                    val savedName = saveSrtToDownloads(srtText)
                    runOnUiThread {
                        setBusy(false)
                        progressBar.progress = 100
                        if (savedName != null) {
                            setStatus("ပြီးပြီ — SRT ကို Downloads ထဲ သိမ်းပြီးပြီ:\n$savedName")
                        } else {
                            setStatus("အမှား: SRT သိမ်းလို့ မရဘူး။")
                        }
                    }
                    return@Thread
                }
                // Transformer must start on the main thread.
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    try {
                        val typeface = loadMyanmarTypeface()
                        val outputFile = newOutputFile()
                        val newBurner = SubtitleBurner(this)
                        burner = newBurner
                        setStatus("စာတန်းထည့်နေတယ်… 0%")
                        newBurner.start(video, cues, typeface, outputFile, burnCallback)
                    } catch (e: Exception) {
                        setBusy(false)
                        setStatus("အမှား: ${e.message ?: "unknown error"}")
                    }
                }
            } catch (e: Exception) {
                postError(e.message ?: "unknown error")
            }
        }.start()
    }

    /** Polls the server until the job finishes (about 10 minutes max). */
    private fun waitForJob(client: TranscribeClient, jobId: String): String {
        var failures = 0
        var waited = 0
        while (waited < 150) {
            val state = try {
                client.poll(jobId)
            } catch (e: IOException) {
                failures++
                if (failures > 5) {
                    throw IOException("Server နဲ့ အဆက်ပြတ်သွားတယ်။ ထပ်စမ်းပါ။")
                }
                null
            }
            if (state != null) {
                failures = 0
                when (state.status) {
                    "done" -> return state.srt ?: throw IOException("Server returned no subtitles")
                    "error" -> throw IOException(state.error ?: "Server error")
                    // "pending": keep waiting.
                }
            }
            Thread.sleep(4000)
            waited++
        }
        throw IOException("အချိန်ကြာလွန်းတယ်။ ထပ်စမ်းပါ။")
    }

    private fun postStatus(text: String) {
        runOnUiThread { setStatus(text) }
    }

    private fun postError(message: String) {
        runOnUiThread {
            setBusy(false)
            setStatus("အမှား: $message")
        }
    }

    // ---------- helpers ----------

    private fun titleText(text: String, size: Float): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
    }

    private fun hintText(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(Color.rgb(235, 235, 235))
        gravity = Gravity.CENTER
    }

    private fun pillBg(color: Int, strokeColor: Int?, strokeWidthDp: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(30).toFloat()
            setColor(color)
            if (strokeColor != null) setStroke(dp(strokeWidthDp), strokeColor)
        }

    private fun pillButton(text: String, bg: Int, fg: Int, stroke: Int?): Button =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 18f
            setTextColor(fg)
            background = pillBg(bg, stroke, 2)
            setPadding(dp(20), dp(12), dp(20), dp(12))
        }

    private fun rowParams(topDp: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(topDp) }

    /**
     * Bundled Noto Sans Myanmar (shapes Myanmar correctly with
     * StaticLayout). Falls back to the system default typeface if the
     * asset is missing — most Android devices ship a Myanmar font.
     */
    private fun loadMyanmarTypeface(): Typeface {
        return try {
            Typeface.createFromAsset(assets, "NotoSansMyanmar-Regular.ttf")
        } catch (e: Exception) {
            Typeface.DEFAULT
        }
    }

    /**
     * Copies [source] into the public Downloads folder (MediaStore, no
     * storage permission needed for the app's own files on Android 10+).
     * Returns the file name on success, null on failure (or on Android
     * older than 10, where the private path is reported instead). The
     * private temp file is deleted after a successful copy.
     */
    private fun copyToDownloads(source: File, mimeType: String): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, source.name)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return null
            contentResolver.openOutputStream(uri)?.use { out ->
                FileInputStream(source).use { it.copyTo(out) }
            } ?: return null
            source.delete()
            source.name
        } catch (e: Exception) {
            null
        }
    }

    /** Writes SRT text straight into the public Downloads folder. */
    private fun saveSrtToDownloads(srtText: String): String? {
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val name = "zhang-studio-$stamp.srt"
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/x-subrip")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return null
            contentResolver.openOutputStream(uri)?.use { out ->
                out.write(srtText.toByteArray(Charsets.UTF_8))
            } ?: return null
            name
        } catch (e: Exception) {
            null
        }
    }

    /** Output goes to the app's private Movies folder (no storage permission needed). */
    private fun newOutputFile(): File {
        val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: cacheDir
        if (!dir.exists()) dir.mkdirs()
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        return File(dir, "zhang-studio-subtitled-$stamp.mp4")
    }

    private fun updateMakeEnabled() {
        makeButton.isEnabled = videoUri != null
    }

    private fun setBusy(busy: Boolean) {
        pickVideoButton.isEnabled = !busy
        makeButton.isEnabled = !busy && videoUri != null
    }

    private fun setStatus(text: String) {
        statusText.text = text
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
