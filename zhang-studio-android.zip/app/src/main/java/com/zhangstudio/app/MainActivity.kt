package com.zhangstudio.app

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Transformer
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Zhang Studio v0.6.24 — seven screens over the studio photo background:
 * 1. Login: Gemini API Key, entered once and remembered. A "Key သွားယူရန်"
 *    link opens the AI Studio key page so new users can get a key.
 * 2. Menu: all six features, all working now.
 * 3. Work (modes 1-2): pick a video -> Gemini SRT -> burn on the phone CPU
 *    (subtitle mode) or SRT alone (SRT mode). Finished files wait for the
 *    separate download button — nothing is saved to Downloads by itself.
 * 4. TTS (mode 3): type text -> AI voice reads it aloud (2 voices + speed
 *    slider, or AI auto mode: Gemini splits the text by character and
 *    assigns male/female voices per part) -> MP3 + SRT on demand, or a
 *    finished video when a character image is picked (image + narration
 *    + burned subtitles). Style picker: plain edge-tts voice, or
 *    expressive Gemini TTS (natural / spooky ghost-story style).
 *    Server: POST /api/tts, POST /api/gemini-tts, POST /api/narrate-image.
 * 5. Prompt-video (mode 6): chat-style "Video generation" screen —
 *    type a prompt in the bottom box -> 3-scene video with Myanmar
 *    narration + subtitles, on demand. Server: POST /api/prompt-video.
 *
 * Server jobs are polled (async), so slow connections never hit a single
 * long request that times out. A sync (v13) transcribe server still works.
 * All errors surface as status text — the app never crashes on bad input.
 * Rotating the phone during a burn cancels the export.
 */
@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {

    private val modeSubtitle = 1
    private val modeSrt = 2
    private val modeTts = 3
    private val modePromptVideo = 6
    private val modeMtv = 7
    private val modeCombo = 8
    private var mode = modeSubtitle

    private var videoUri: Uri? = null
    private var burner: SubtitleBurner? = null
    private var apiKey: String = ""

    // Two real Myanmar edge-tts voices (Nilar = female, Thiha = male).
    // Auto mode (v0.6.3): AI splits the text by character instead.
    private data class VoiceOption(val label: String, val voice: String)
    private val voiceOptions = listOf(
        VoiceOption("မိန်းကလေး အသံ", TtsClient.VOICE_NILAR),
        VoiceOption("ယောက်ျားလေး အသံ", TtsClient.VOICE_THIHA)
    )
    private var selectedVoiceIndex = 0
    private val voiceOptionButtons = mutableListOf<Pair<Button, Int>>()
    private var autoVoice = false
    private val autoVoiceButtons = mutableListOf<Button>()
    // Narration style (v0.6.5): "edge" = plain edge-tts voice; "gemini" =
    // expressive Gemini TTS with a style direction. Gemini and the auto
    // character split exclude each other (Gemini is single-voice).
    private var ttsEngine: String = "edge"
    private var ttsStyle: String = "natural"
    private val styleButtons = mutableListOf<Pair<Button, String>>()
    private var ttsRate: Int = 0
    private var ttsPitch: Int = 0

    private val prefs by lazy { getSharedPreferences("zhang_studio", MODE_PRIVATE) }

    private lateinit var loginScreen: View
    private lateinit var menuScreen: View
    private lateinit var workScreen: View
    private lateinit var ttsScreen: View
    private lateinit var promptVideoScreen: View
    private lateinit var mtvScreen: View
    private lateinit var keyField: EditText
    private lateinit var loginStatus: TextView
    private lateinit var workTitle: TextView
    private lateinit var pickVideoButton: Button
    private lateinit var videoLabel: TextView
    private lateinit var makeButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var workStatusCard: LinearLayout
    private lateinit var workStatusLog: TextView
    private lateinit var workDownloadButton: Button
    // v0.9.9: hide-original-subtitles toggle + finished-video preview.
    private lateinit var workCoverCheck: CheckBox
    // v0.10.9: Myanmar movie-title input + top-logo cover toggle.
    // v0.10.10: auto title from the resolved link (server v43+).
    @Volatile
    private var workAutoTitle: String? = null
    private lateinit var workTitleField: EditText
    private lateinit var workTopBandCheck: CheckBox
    private lateinit var workPreviewVideo: VideoView
    private var workLastOutput: File? = null
    private var workLastSrt: String? = null
    // v0.10.23: subtitle-mode SRT, kept apart from workLastSrt on
    // purpose — onWorkDownloadClicked prefers the SRT whenever
    // workLastSrt is set, which would break the video download.
    // v0.10.15: the source video of the running burn — the audio-repair
    // fallback re-extracts audio from it if the burn drops the track.
    private var workLastSourceUri: Uri? = null

    // v0.11.0: Function 1 — video + Myanmar subtitles + Myanmar voice,
    // all in one screen (Zin, 15 Nov: no other app needed).
    private lateinit var comboScreen: View
    private var comboVideoUri: Uri? = null
    private lateinit var comboPickButton: Button
    private lateinit var comboVideoLabel: TextView
    private lateinit var comboMakeButton: Button
    private lateinit var comboProgressBar: ProgressBar
    private lateinit var comboStatusText: TextView
    private lateinit var comboStatusCard: LinearLayout
    private lateinit var comboStatusLog: TextView
    private lateinit var comboDownloadButton: Button
    private lateinit var comboPreviewVideo: VideoView
    private lateinit var comboScrollView: ScrollView
    private var comboLastOutput: File? = null
    private var comboSrtText: String? = null
    private var comboVideoDurationSec: Double = 0.0
    private val comboVoiceButtons = mutableListOf<Button>()
    // 0 = lively girl, 1 = normal girl, 2 = lively boy, 3 = normal boy.
    // Lively = a little faster + a little higher; normal = defaults.
    private var comboVoiceIndex: Int = 1
    // v0.13.0: subtitle text color picker (Zin, 16 Nov) — one choice,
    // shared by the subtitle + combo screens, remembered in prefs.
    // Index 0 = red (the standing default).
    private val subtitleColors = listOf(
        0xFFFF0000.toInt(), // red
        0xFFFFFFFF.toInt(), // white
        0xFFFFFF00.toInt(), // yellow
        0xFF00E676.toInt(), // green
        0xFF00E5FF.toInt(), // cyan
        0xFFFF4081.toInt(), // pink
        0xFFFF9100.toInt(), // orange
        0xFF000000.toInt() // black (v0.13.1: Zin asked for it)
    )
    private var subtitleColorIndex: Int = 0
    private val subtitleColorSwatches = mutableListOf<Pair<View, Int>>()
    private val comboVoices = listOf(
        Triple(TtsClient.VOICE_NILAR, 20, 10),
        Triple(TtsClient.VOICE_NILAR, 0, 0),
        Triple(TtsClient.VOICE_THIHA, 20, 10),
        Triple(TtsClient.VOICE_THIHA, 0, 0)
    )
    private lateinit var ttsTextField: EditText
    // v0.10.19: SRT-vs-plain-text TTS modes (Zin) — an SRT file can
    // be the voice source even when the video has no audio at all.
    private var ttsSrtMode: Boolean = false
    private var ttsSrtText: String? = null
    private lateinit var ttsSrtLabel: TextView
    private lateinit var ttsRateLabel: TextView
    private lateinit var ttsPitchLabel: TextView
    private lateinit var ttsMakeButton: Button
    private lateinit var ttsProgressBar: ProgressBar
    private lateinit var ttsStatusText: TextView
    private lateinit var ttsDownloadButton: Button
    private var ttsLastAudio: ByteArray? = null
    private var ttsLastSrt: String? = null
    // v0.6.20: listen to the generated voice here before downloading.
    private lateinit var ttsPlayerRow: LinearLayout
    private lateinit var ttsPlayButton: Button
    private lateinit var ttsSeekBar: SeekBar
    private lateinit var ttsTimeText: TextView
    private var ttsPlayer: MediaPlayer? = null
    private var ttsPlayerFile: File? = null
    private val ttsPlayerHandler = Handler(Looper.getMainLooper())
    private val ttsPlayerPoller = object : Runnable {
        override fun run() {
            val mp = ttsPlayer ?: return
            if (!::ttsSeekBar.isInitialized) return
            try {
                if (mp.isPlaying) {
                    ttsSeekBar.progress = mp.currentPosition
                    ttsTimeText.text =
                        "${formatClockUs(mp.currentPosition * 1_000L)} / ${formatClockUs(mp.duration * 1_000L)}"
                    ttsPlayerHandler.postDelayed(this, 250L)
                } else {
                    ttsPlayButton.text = "▶"
                }
            } catch (e: Exception) {
            }
        }
    }
    private var ttsImageUri: Uri? = null
    private lateinit var ttsImageButton: Button
    private lateinit var ttsImageLabel: TextView
    private var ttsLastVideo: File? = null
    private var ttsLastVideoUrl: String? = null
    // v0.7.4: MTV screen — person photo + song name -> 20s MTV.
    private var mtvImageUri: Uri? = null
    private lateinit var mtvImageButton: Button
    private lateinit var mtvImageLabel: TextView
    private lateinit var mtvSongField: EditText
    private lateinit var mtvLinkField: EditText
    private lateinit var mtvMakeButton: Button
    private lateinit var mtvProgressBar: ProgressBar
    private lateinit var mtvStatusText: TextView
    private lateinit var mtvDownloadButton: Button
    private var mtvLastVideo: File? = null
    private var mtvLastVideoUrl: String? = null
    private var selectedTrack: Int = 0
    private var selectedIndex: Int = -1
    private lateinit var pvTextField: EditText
    private lateinit var pvHintText: TextView
    private lateinit var pvInputCard: LinearLayout
    private lateinit var pvPickImageButton: Button
    private lateinit var pvClearImagesButton: Button
    private lateinit var pvImageLabel: TextView
    private lateinit var pvImageRow: LinearLayout
    private val pvImageUris = mutableListOf<Uri>()
    private lateinit var pvMakeButton: Button
    private lateinit var pvProgressBar: ProgressBar
    private lateinit var pvStatusText: TextView
    private lateinit var pvDownloadButton: Button
    private var pvLastTmp: File? = null
    private var pvLastVideoUrl: String? = null
    private var pvLastSrt: String? = null

    // v0.10.7: photo-picker Uris (picker_get_content) are SHORT-LIVED —
    // the read grant can lapse while a long job (transcription) runs,
    // and the burn then fails with "File not found for uri" (Zin,
    // 15 Nov 01:00, Asset loader error code 2005). Copy every picked
    // file into the app cache at pick time and use the cache file
    // from then on. Runs off the UI thread; onDone gets the cache Uri.
    private fun copyPickedToCache(
        uri: Uri,
        prefix: String,
        onDone: (Uri) -> Unit,
        onError: (String) -> Unit
    ) {
        Thread {
            try {
                val dest = File(cacheDir, "$prefix-${stamp()}.bin")
                val input = contentResolver.openInputStream(uri)
                    ?: throw IOException("ဖိုင် ဖွင့်လို့ မရဘူး။")
                input.use { stream ->
                    FileOutputStream(dest).use { stream.copyTo(it) }
                }
                runOnUiThread { onDone(Uri.fromFile(dest)) }
            } catch (e: Exception) {
                val msg = e.message ?: "unknown error"
                runOnUiThread { onError(msg) }
            }
        }.start()
    }

    private val pickVideoLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                videoUri = null
                videoLabel.text = "Video: ${uri.lastPathSegment ?: uri}"
                setStatus("Video ကူးနေတယ်…")
                updateMakeEnabled()
                // v0.10.7: copy to cache — picker Uris expire.
                copyPickedToCache(uri, "picked-video",
                    onDone = { cached ->
                        videoUri = cached
                        setStatus("Video ရွေးပြီးပြီ")
                        updateMakeEnabled()
                    },
                    onError = { msg ->
                        setStatus("အမှား: $msg")
                    }
                )
            }
        }

    private val pickComboVideoLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                comboVideoUri = null
                comboVideoLabel.text = "Video: ${uri.lastPathSegment ?: uri}"
                comboStatusText.text = "Video ကူးနေတယ်…"
                comboMakeButton.isEnabled = false
                // v0.10.7: copy to cache — picker Uris expire.
                copyPickedToCache(uri, "picked-combo-video",
                    onDone = { cached ->
                        comboVideoUri = cached
                        comboStatusText.text = "Video ရွေးပြီးပြီ"
                        comboMakeButton.isEnabled = true
                    },
                    onError = { msg ->
                        comboStatusText.text = "အမှား: $msg"
                    }
                )
            }
        }

    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                ttsImageUri = null
                ttsImageLabel.text = "ပုံ: ${uri.lastPathSegment ?: uri}"
                copyPickedToCache(uri, "picked-tts-image",
                    onDone = { cached -> ttsImageUri = cached },
                    onError = { msg -> ttsStatusText.text = "အမှား: $msg" }
                )
            }
        }

    private val pickMtvImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                mtvImageUri = null
                mtvImageLabel.text = "ပုံ: ${uri.lastPathSegment ?: uri}"
                copyPickedToCache(uri, "picked-mtv-image",
                    onDone = { cached -> mtvImageUri = cached },
                    onError = { msg -> mtvStatusText.text = "အမှား: $msg" }
                )
            }
        }

    private val pickPvImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null && pvImageUris.size < 3) {
                copyPickedToCache(uri, "picked-pv-image",
                    onDone = { cached ->
                        if (pvImageUris.size < 3) {
                            pvImageUris.add(cached)
                            updatePvImageLabel()
                        }
                    },
                    onError = { msg -> pvStatusText.text = "အမှား: $msg" }
                )
            }
        }

    private fun updatePvImageLabel() {
        val n = pvImageUris.size
        pvImageLabel.text = if (n == 0) {
            "ပုံ မထည့်ရသေးဘူး — ပုံမထည့်ရင် AI က ပုံထုတ်ပေးမယ်"
        } else {
            "ပုံ $n ပုံ ထည့်ပြီးပြီ" + if (n < 3) " — နောက် ပုံ ထပ်ထည့်လို့ရတယ်" else ""
        }
        pvPickImageButton.isEnabled = n < 3
        pvClearImagesButton.visibility = if (n == 0) View.GONE else View.VISIBLE
        // v0.6.10: show the picked images as thumbnails together with the
        // text, so each added image is visible (not just a count).
        // v0.6.12: each thumbnail carries a small X — tapping it removes
        // just that image.
        pvImageRow.removeAllViews()
        for ((index, uri) in pvImageUris.withIndex()) {
            val thumb = ImageView(this).apply {
                setImageURI(uri)
                scaleType = ImageView.ScaleType.CENTER_CROP
                layoutParams = FrameLayout.LayoutParams(dp(72), dp(72))
            }
            val cross = TextView(this).apply {
                text = "✕"
                textSize = 13f
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.argb(160, 0, 0, 0))
                setPadding(dp(5), dp(1), dp(5), dp(1))
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { gravity = Gravity.TOP or Gravity.END }
                setOnClickListener {
                    pvImageUris.removeAt(index)
                    updatePvImageLabel()
                }
            }
            val frame = FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(72), dp(72)).apply {
                    marginEnd = dp(8)
                }
                addView(thumb)
                addView(cross)
            }
            pvImageRow.addView(frame)
        }
        pvImageRow.visibility = if (n == 0) View.GONE else View.VISIBLE
    }

    private val pickTtsSrtLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri == null) return@registerForActivityResult
            try {
                val text = contentResolver.openInputStream(uri)?.use {
                    it.readBytes().toString(Charsets.UTF_8)
                } ?: ""
                val cues = SrtParser.parse(text)
                if (cues.isEmpty()) {
                    ttsSrtText = null
                    ttsSrtLabel.text = "SRT ထဲမှာ စာတန်း မတွေ့ဘူး။"
                } else {
                    ttsSrtText = cues.joinToString(" ") { it.text.trim() }.trim()
                    ttsSrtLabel.text = "SRT: စာတန်း ${cues.size} ခု"
                }
            } catch (e: Exception) {
                ttsSrtText = null
                ttsSrtLabel.text = "SRT ဖိုင် ဖတ်လို့ မရဘူး။"
            }
        }

    private val burnCallback = object : SubtitleBurner.Callback {
        override fun onProgress(percent: Int) {
            progressBar.progress = percent
            setStatus("စာတန်းထည့်နေတယ်… $percent%")
        }

        override fun onCompleted(outputPath: String) {
            // v0.10.15: Media3's own extractor silently drops the audio
            // track on some malformed downloads (empty audio track, no
            // error — 15 Nov: 213s drama, zero audio packets). Verify
            // the burn kept audio; if not, repair by muxing the
            // platform-extracted audio (the extraction the transcription
            // step already proved works) onto the burned video. The
            // check runs off the main thread; the UI below is unchanged
            // apart from the repaired file + a repair note.
            Thread {
                // v0.10.18: if the burn lost its audio AND the repair
                // fails, say so — a silent broken file must never
                // present as a normal finished video again.
                val outFile = File(outputPath)
                val hadNoAudio = audioSampleCount(outFile) <= 0
                val repaired = maybeRepairAudio(outFile)
                val finalFile = repaired ?: outFile
                val wasRepaired = repaired != null
                val repairFailed = hadNoAudio && !wasRepaired
                // v0.6.2: no auto-download — the finished file waits until
                // the user taps the separate download button.
                workLastOutput = finalFile
                workLastSrt = null
                runOnUiThread {
                    setBusy(false)
                    progressBar.progress = 100
                    workDownloadButton.text = "Video ဒေါင်းလုဒ်လုပ်ရန်"
                    workDownloadButton.isEnabled = true
                    workDownloadButton.visibility = View.VISIBLE
                    // v0.9.9: preview the finished video here first.
                    if (::workPreviewVideo.isInitialized) {
                        workPreviewVideo.setVideoPath(finalFile.absolutePath)
                        workPreviewVideo.visibility = View.VISIBLE
                        workPreviewVideo.setOnPreparedListener { mp -> mp.seekTo(100) }
                    }
                    val note = if (wasRepaired) " (အသံ ပြန်ထည့်ပေးပြီးပြီ)" else if (repairFailed) " (အသံ ပြန်ထည့်လို့ မရဘူး — ဒီ Video က အသံမပါဘူး)" else ""
                    setStatus("ပြီးပြီ — Video ကို ဒီမှာ ကြည့်ပြီး၊ ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။$note")
                    workStage("ပြီးပြီ — Video ကြည့်ပြီး ဒေါင်းလုပ်လုပ်ပါ$note")
                }
            }.start()
        }

        override fun onError(message: String) {
            setBusy(false)
            setStatus("အမှား: $message")
            workStage("အမှား: $message")
        }
    }

    // v0.11.0: burn callback for Function 1 — the burn is only stage 2
    // of 4 (transcribe -> burn -> narration -> mux). On completion the
    // chain continues on a background thread: repair audio, synthesize
    // the timed narration from the same SRT, mux it onto the burned
    // video, then show the finished video.
    private val comboBurnCallback = object : SubtitleBurner.Callback {
        override fun onProgress(percent: Int) {
            comboProgressBar.progress = percent
            comboStatusText.text = "စာတန်းထည့်နေတယ်… $percent%"
        }

        override fun onCompleted(outputPath: String) {
            Thread {
                try {
                    val outFile = File(outputPath)
                    val hadNoAudio = audioSampleCount(outFile) <= 0
                    val repaired = maybeRepairAudio(outFile, comboVideoUri, 0L)
                    val burnedFile = repaired ?: outFile
                    val repairFailed = hadNoAudio && repaired == null
                    val srtText = comboSrtText
                        ?: throw IOException("စာတန်း မတွေ့ဘူး။")
                    comboStage("မြန်မာအသံ ထုတ်နေတယ်…")
                    runOnUiThread {
                        comboProgressBar.isIndeterminate = true
                        comboStatusText.text = "မြန်မာအသံ ထုတ်နေတယ်… (၁-၃ မိနစ် ကြာနိုင်တယ်)"
                    }
                    val client = TranscribeClient(contentResolver)
                    val (voice, rate, pitch) = comboVoices[comboVoiceIndex]
                    val jobId = client.submitVoiceoverSrt(
                        srtText, comboVideoDurationSec, apiKey, voice, rate, pitch, "manual"
                    )
                    val state = pollUntilDone(client, jobId, 450)
                    val narrationUrl = state.audioM4aUrl
                        ?: throw IOException("Server က မြန်မာအသံ ပြန်မပေးဘူး။")
                    comboStage("မြန်မာအသံ ပြန်ယူနေတယ်…")
                    runOnUiThread { comboStatusText.text = "မြန်မာအသံ ပြန်ယူနေတယ်…" }
                    val narration = File(cacheDir, "combo-narration-${stamp()}.m4a")
                    client.downloadToFile(narrationUrl, narration)
                    if (narration.length() < 1024L || audioSampleCount(narration) <= 0) {
                        throw IOException("မြန်မာအသံ ဖိုင် မပြည့်စုံဘူး — ထပ်စမ်းပါ။")
                    }
                    comboStage("Video နဲ့ အသံ တွဲနေတယ်…")
                    runOnUiThread { comboStatusText.text = "Video နဲ့ အသံ တွဲနေတယ်…" }
                    val finalFile = File(cacheDir, "combo-final-${stamp()}.mp4")
                    muxNarrationOntoVideo(Uri.fromFile(burnedFile), narration, finalFile)
                    if (audioSampleCount(finalFile) <= 0) {
                        throw IOException("Video နဲ့ အသံ တွဲလို့ မရဘူး — အသံ မပါဘူး။ ထပ်စမ်းပါ။")
                    }
                    comboLastOutput = finalFile
                    runOnUiThread {
                        comboPickButton.isEnabled = true
                        comboMakeButton.isEnabled = true
                        comboProgressBar.isIndeterminate = false
                        comboProgressBar.progress = 100
                        comboDownloadButton.text = "Video ဒေါင်းလုဒ်လုပ်ရန်"
                        comboDownloadButton.isEnabled = true
                        comboDownloadButton.visibility = View.VISIBLE
                        comboPreviewVideo.setVideoPath(finalFile.absolutePath)
                        comboPreviewVideo.visibility = View.VISIBLE
                        comboPreviewVideo.setOnPreparedListener { mp -> mp.seekTo(100) }
                        val note = if (repairFailed) " (မူလအသံ ပြန်ထည့်လို့ မရဘူး — မြန်မာအသံပဲ ပါမယ်)" else ""
                        comboStatusText.text = "ပြီးပြီ — Video ကို ဒီမှာ ကြည့်ပြီး၊ ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။$note"
                        comboStage("ပြီးပြီ — Video ကြည့်ပြီး ဒေါင်းလုပ်လုပ်ပါ$note")
                        comboScrollView.post {
                            comboScrollView.smoothScrollTo(0, comboPreviewVideo.top)
                        }
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        comboPickButton.isEnabled = true
                        comboMakeButton.isEnabled = true
                        comboProgressBar.isIndeterminate = false
                        comboProgressBar.progress = 0
                        comboStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                        comboStage("အမှား: ${e.message ?: "unknown error"}")
                    }
                }
            }.start()
        }

        override fun onError(message: String) {
            comboPickButton.isEnabled = true
            comboMakeButton.isEnabled = true
            comboProgressBar.isIndeterminate = false
            comboStatusText.text = "အမှား: $message"
            comboStage("အမှား: $message")
        }
    }

    private var loginBgPlayer: MediaPlayer? = null
    private var loginBgView: TextureView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        apiKey = prefs.getString("gemini_api_key", "").orEmpty()
        // v0.13.0: remembered subtitle color (red when never picked).
        subtitleColorIndex = prefs.getInt("subtitle_color_index", 0)
            .coerceIn(subtitleColors.indices)

        val root = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.rgb(17, 20, 24))
        }

        // Deep green-charcoal gradient background (approved design).
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.rgb(12, 32, 26), Color.rgb(6, 13, 10))
        )

        // Looping muted video behind the login (API key) screen only.
        loginBgView = TextureView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(
                    surfaceTexture: SurfaceTexture, width: Int, height: Int
                ) {
                    initLoginBgPlayer(Surface(surfaceTexture))
                }

                override fun onSurfaceTextureSizeChanged(
                    surfaceTexture: SurfaceTexture, width: Int, height: Int
                ) {
                    loginBgPlayer?.let {
                        adjustLoginBgTransform(it.videoWidth, it.videoHeight)
                    }
                }

                override fun onSurfaceTextureDestroyed(surfaceTexture: SurfaceTexture): Boolean {
                    try {
                        loginBgPlayer?.release()
                    } catch (e: Exception) {
                    }
                    loginBgPlayer = null
                    return true
                }

                override fun onSurfaceTextureUpdated(surfaceTexture: SurfaceTexture) {}
            }
        }
        root.addView(loginBgView)

        loginScreen = buildLoginScreen()
        menuScreen = buildMenuScreen()
        workScreen = buildWorkScreen()
        comboScreen = buildComboScreen()
        ttsScreen = buildTtsScreen()
        promptVideoScreen = buildPromptVideoScreen()
        mtvScreen = buildMtvScreen()
        root.addView(loginScreen)
        root.addView(menuScreen)
        root.addView(workScreen)
        root.addView(comboScreen)
        root.addView(ttsScreen)
        root.addView(promptVideoScreen)
        root.addView(mtvScreen)
        setContentView(root)

        if (apiKey.isBlank()) showScreen(loginScreen) else showScreen(menuScreen)
    }

    override fun onDestroy() {
        burner?.cancel()
        burner = null
        try {
            loginBgPlayer?.release()
        } catch (e: Exception) {
        }
        loginBgPlayer = null
        stopTtsPlayer()
        super.onDestroy()
    }

    override fun onPause() {
        try {
            loginBgPlayer?.let { if (it.isPlaying) it.pause() }
        } catch (e: Exception) {
        }
        try {
            if (::workPreviewVideo.isInitialized && workPreviewVideo.isPlaying) {
                workPreviewVideo.pause()
            }
        } catch (e: Exception) {
        }
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (loginScreen.visibility == View.VISIBLE) {
            try {
                loginBgPlayer?.let { if (!it.isPlaying) it.start() }
            } catch (e: Exception) {
            }
        }
    }

    // ---------- screens ----------

    private fun showScreen(screen: View) {
        // v0.9.9: stop the work-screen preview when leaving it.
        if (screen !== workScreen && ::workPreviewVideo.isInitialized) {
            workPreviewVideo.stopPlayback()
        }
        if (screen !== comboScreen && ::comboPreviewVideo.isInitialized) {
            comboPreviewVideo.stopPlayback()
        }
        // Pause the TTS listen-here player when leaving that screen.
        if (screen !== ttsScreen) {
            pauseTtsPlayer()
        }
        loginScreen.visibility = if (screen === loginScreen) View.VISIBLE else View.GONE
        menuScreen.visibility = if (screen === menuScreen) View.VISIBLE else View.GONE
        workScreen.visibility = if (screen === workScreen) View.VISIBLE else View.GONE
        comboScreen.visibility = if (screen === comboScreen) View.VISIBLE else View.GONE
        ttsScreen.visibility = if (screen === ttsScreen) View.VISIBLE else View.GONE
        promptVideoScreen.visibility =
            if (screen === promptVideoScreen) View.VISIBLE else View.GONE
        mtvScreen.visibility = if (screen === mtvScreen) View.VISIBLE else View.GONE
        // Login-only video background: visible + playing on the login
        // screen, hidden + paused everywhere else.
        val bgVisible = screen === loginScreen
        loginBgView?.visibility = if (bgVisible) View.VISIBLE else View.GONE
        try {
            if (bgVisible) {
                loginBgPlayer?.let { if (!it.isPlaying) it.start() }
            } else {
                loginBgPlayer?.let { if (it.isPlaying) it.pause() }
            }
        } catch (e: Exception) {
            // Player not prepared yet; the prepared listener starts it.
        }
        // v0.14.1: re-entering a finished screen restores the preview
        // thumbnail — leaving stopped playback, and the finished file
        // is now kept after download, so re-opening it is safe.
        if (screen === workScreen && ::workPreviewVideo.isInitialized &&
            workPreviewVideo.visibility == View.VISIBLE
        ) {
            workLastOutput?.takeIf { it.exists() }?.let {
                workPreviewVideo.setVideoPath(it.absolutePath)
            }
        }
        if (screen === comboScreen && ::comboPreviewVideo.isInitialized &&
            comboPreviewVideo.visibility == View.VISIBLE
        ) {
            comboLastOutput?.takeIf { it.exists() }?.let {
                comboPreviewVideo.setVideoPath(it.absolutePath)
            }
        }
    }

    private fun screenColumn(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val pad = dp(24)
        setPadding(pad, dp(48), pad, pad)
        layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    private fun wrapScroll(column: LinearLayout): ScrollView = ScrollView(this).apply {
        layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        addView(column)
    }

    // ---------- login video background ----------

    private fun initLoginBgPlayer(surface: Surface) {
        try {
            val fd = assets.openFd("login_bg.mp4")
            loginBgPlayer = MediaPlayer().apply {
                setDataSource(fd.fileDescriptor, fd.startOffset, fd.length)
                setSurface(surface)
                isLooping = true
                setVolume(0f, 0f)
                setOnVideoSizeChangedListener { _, w, h -> adjustLoginBgTransform(w, h) }
                setOnPreparedListener {
                    if (loginScreen.visibility == View.VISIBLE) {
                        try {
                            start()
                        } catch (e: Exception) {
                        }
                    }
                }
                prepareAsync()
            }
            fd.close()
        } catch (e: Exception) {
            loginBgView?.visibility = View.GONE
        }
    }

    private fun adjustLoginBgTransform(videoW: Int, videoH: Int) {
        val view = loginBgView ?: return
        if (videoW == 0 || videoH == 0 || view.width == 0 || view.height == 0) return
        val viewW = view.width.toFloat()
        val viewH = view.height.toFloat()
        val scaleX = viewW / videoW
        val scaleY = viewH / videoH
        val scale = maxOf(scaleX, scaleY)
        val matrix = Matrix()
        matrix.setScale(scale / scaleX, scale / scaleY, viewW / 2f, viewH / 2f)
        view.setTransform(matrix)
    }

    private fun buildLoginScreen(): View {
        val col = screenColumn()
        col.addView(titleText("ZHANG Studio", 32f))
        col.addView(titleText("မှ ကြိုဆိုပါတယ်", 26f))

        val banner = TextView(this).apply {
            text = "Gemini API Key ထည့်ပြီး\nစတင် အသုံးပြုနိုင်ပါပြီ"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = pillBg(Color.rgb(30, 107, 74), Color.rgb(76, 175, 125), 2)
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        col.addView(banner, rowParams(dp(40)))

        keyField = EditText(this).apply {
            hint = "API Key"
            textSize = 18f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            setSingleLine(true)
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(22), dp(14), dp(22), dp(14))
            if (apiKey.isNotBlank()) setText(apiKey)
        }
        col.addView(keyField, rowParams(dp(24)))

        val loginButton = pillButton("Login", Color.rgb(35, 35, 35), Color.WHITE, null)
        loginButton.setOnClickListener { onLoginClicked() }
        col.addView(loginButton, rowParams(dp(16)))

        loginStatus = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.rgb(255, 213, 74))
            gravity = Gravity.CENTER
        }
        col.addView(loginStatus, rowParams(dp(12)))

        // "Go get a Key" link: new users who don't know what a key is can
        // tap it and land straight on the free AI Studio key page.
        val keyLink = TextView(this).apply {
            text = "🔑 Key သွားယူရန်"
            textSize = 17f
            setTextColor(Color.rgb(255, 213, 74))
            gravity = Gravity.CENTER
            paint.isUnderlineText = true
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        keyLink.setOnClickListener {
            try {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://aistudio.google.com/apikey")
                    )
                )
            } catch (e: Exception) {
                loginStatus.text = "Link ဖွင့်လို့ မရဘူး။"
            }
        }
        col.addView(keyLink, rowParams(dp(8)))

        col.addView(hintText("Key ကို aistudio.google.com/apikey မှာ အခမဲ့ ရယူနိုင်ပါတယ်"),
            rowParams(dp(12)))
        // Dim the looping video background so the form stays readable.
        return wrapScroll(col).apply {
            setBackgroundColor(Color.argb(90, 0, 0, 0))
        }
    }

    // v0.12.0: photo-card menu (Zin, 15 Nov) — hero card + two
    // half cards with real photos, like the approved design sample.
    private fun buildMenuScreen(): View {
        val col = screenColumn()
        col.addView(titleText("ZHANG Studio", 30f))
        col.addView(TextView(this).apply {
            text = "လုပ်ဆောင်ချက်များ"
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(6) })

        val contentW = resources.displayMetrics.widthPixels - dp(48)
        val heroH = contentW * 9 / 16
        val halfW = (contentW - dp(12)) / 2
        val halfH = halfW * 380 / 340

        col.addView(photoMenuCard(
            "menu_hero.jpg", heroH,
            "Video ကို မြန်မာစာတန်း + မြန်မာအသံ ထည့်ပေးရန်",
            "စာတန်း + အသံ + Video တွဲ ထုတ်မယ်", Gravity.START
        ) { showScreen(comboScreen) }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(14) })

        val halfRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        halfRow.addView(photoMenuCard(
            "menu_cinema.jpg", halfH,
            "မြန်မာစာတန်းထိုး",
            "Video + စာတန်း တွဲ ထုတ်မယ်", Gravity.CENTER
        ) { openWork(modeSubtitle) }, LinearLayout.LayoutParams(
            halfW, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { marginEnd = dp(12) })
        halfRow.addView(photoMenuCard(
            "menu_mic.jpg", halfH,
            "AI အသံဖတ်ပြရန်",
            "စာသား → မြန်မာ AI အသံ", Gravity.CENTER
        ) { showScreen(ttsScreen) }, LinearLayout.LayoutParams(
            halfW, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        col.addView(halfRow, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(20) })

        val changeKey = TextView(this).apply {
            text = "API Key ပြောင်းရန်"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        changeKey.setOnClickListener {
            keyField.setText(apiKey)
            loginStatus.text = ""
            showScreen(loginScreen)
        }
        col.addView(changeKey, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(18) })
        return wrapScroll(col)
    }

    private fun buildWorkScreen(): View {
        workTitle = TextView(this).apply { text = "" }
        val col = sheetColumn()

        pickVideoButton = glassButton("Video ရွေးပါ")
        pickVideoButton.setOnClickListener { pickVideoLauncher.launch("video/*") }
        col.addView(pickVideoButton, rowParams(dp(24)))

        videoLabel = TextView(this).apply {
            text = "Video မရွေးရသေးဘူး"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(videoLabel, rowParams(dp(12)))

        // v0.10.13: link input REMOVED (Zin, 15 Nov — slow, big
        // files, wrong subtitles). Picked videos only; the link
        // code sleeps below, easy to restore.

        workCoverCheck = CheckBox(this).apply {
            text = "မူလ စာတန်းကို ဖျောက်မယ်"
            textSize = 16f
            setTextColor(Color.WHITE)
            isChecked = true
        }
        col.addView(workCoverCheck, rowParams(dp(12)))

        // v0.10.9: movie title, burned at the top for the whole
        // export (Zin: no re-edit in CapCut afterwards). Blank =
        // no title.
        workTitleField = EditText(this).apply {
            hint = "ဇာတ်ကား ခေါင်းစဉ် (ရိုက်ထည့်ပါ)"
            textSize = 16f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(170, 180, 175))
            background = glassPillBg()
            setPadding(dp(22), dp(14), dp(22), dp(14))
        }
        col.addView(workTitleField, rowParams(dp(12)))

        // v0.10.9: hide the top-corner platform/account logos.
        workTopBandCheck = CheckBox(this).apply {
            text = "အပေါ်က logo ကို ဖျောက်မယ်"
            textSize = 16f
            setTextColor(Color.WHITE)
            isChecked = true
        }
        col.addView(workTopBandCheck, rowParams(dp(12)))

        // v0.13.0: subtitle color picker (shared with the combo screen).
        col.addView(sectionLabel("စာတန်း အရောင် ရွေးပါ"), rowParams(dp(16)))
        col.addView(subtitleColorRow(), rowParams(dp(8)))

        makeButton = ctaButton("")
        makeButton.isEnabled = false
        makeButton.setOnClickListener { onMakeClicked() }
        col.addView(makeButton, rowParams(dp(12)))

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        col.addView(progressBar, rowParams(dp(16)))

        statusText = TextView(this).apply {
            text = "Video ရွေးပါ။"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(statusText, rowParams(dp(8)))

        // v0.10.1: အခြေအနေ box — stage-by-stage status like the web UI.
        workStatusCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBg()
            setPadding(dp(16), dp(12), dp(16), dp(12))
            visibility = View.GONE
        }
        workStatusCard.addView(TextView(this).apply {
            text = "အခြေအနေ"
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.rgb(140, 220, 170))
        })
        workStatusLog = TextView(this).apply {
            text = ""
            textSize = 14f
            setTextColor(Color.rgb(220, 235, 225))
            setPadding(0, dp(6), 0, 0)
        }
        workStatusCard.addView(workStatusLog)
        col.addView(workStatusCard, rowParams(dp(12)))

        workDownloadButton = glassButton("Video ဒေါင်းလုဒ်လုပ်ရန်", selectedStrokeColor)
        workDownloadButton.visibility = View.GONE
        workDownloadButton.setOnClickListener { onWorkDownloadClicked() }
        col.addView(workDownloadButton, rowParams(dp(12)))

        // v0.10.23: SRT download on the subtitle screen too (Zin) —
        // the SRT comes out of the subtitle place as well as the video.

        workPreviewVideo = VideoView(this).apply {
            visibility = View.GONE
        }
        workPreviewVideo.setMediaController(
            MediaController(this).apply { setAnchorView(workPreviewVideo) }
        )
        // v0.14.1: never show Android's raw "Can't play this video"
        // dialog — report in Burmese and keep the screen usable.
        workPreviewVideo.setOnErrorListener { _, _, _ ->
            setStatus("Video ဖိုင် ဖွင့်လို့ မရဘူး — Download/zhang file ထဲက သိမ်းပြီးသား ဖိုင်ကို ဖွင့်ကြည့်ပါ။")
            true
        }
        col.addView(
            workPreviewVideo,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(280)
            ).apply { topMargin = dp(12) }
        )

        col.addView(backLink(), rowParams(dp(16)))
        return buildPosterSheet("menu_cinema.jpg", workTitle, col)
    }

    // v0.11.0: Function 1 (Zin, 15 Nov) — video + subtitles + voice in
    // one place, so no other app is needed. No toggles: the original
    // subtitles and top logos are always covered, like the work
    // screen's defaults.
    private fun buildComboScreen(): View {
        val comboTitle = TextView(this).apply {
            text = "Video ကို စာတန်း + အသံ ထည့်ပေးရန်"
        }
        val col = sheetColumn()

        comboPickButton = glassButton("Video ထည့်ပါ")
        comboPickButton.setOnClickListener { pickComboVideoLauncher.launch("video/*") }
        col.addView(comboPickButton, rowParams(dp(24)))

        comboVideoLabel = TextView(this).apply {
            text = "Video မရွေးရသေးဘူး"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(comboVideoLabel, rowParams(dp(12)))

        col.addView(sectionLabel("အသံ ရွေးပါ"), rowParams(dp(20)))
        val voiceLabels = listOf(
            "သွက်လက်တဲ့ မိန်းကလေး အသံ",
            "ပုံမှန် မိန်းကလေး အသံ",
            "သွက်လက်တဲ့ ယောက်ျားလေး အသံ",
            "ပုံမှန် ယောက်ျားလေး အသံ"
        )
        for ((index, label) in voiceLabels.withIndex()) {
            val b = glassButton(label)
            b.textSize = 16f
            b.setOnClickListener {
                comboVoiceIndex = index
                refreshComboVoiceButtons()
            }
            comboVoiceButtons.add(b)
            col.addView(b, rowParams(dp(10)))
        }
        refreshComboVoiceButtons()

        // v0.13.0: subtitle color picker (shared with the subtitle screen).
        col.addView(sectionLabel("စာတန်း အရောင် ရွေးပါ"), rowParams(dp(16)))
        col.addView(subtitleColorRow(), rowParams(dp(8)))

        comboMakeButton = ctaButton("Video ထုတ်မယ်")
        comboMakeButton.isEnabled = false
        comboMakeButton.setOnClickListener { onComboClicked() }
        col.addView(comboMakeButton, rowParams(dp(12)))

        comboProgressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        col.addView(comboProgressBar, rowParams(dp(16)))

        comboStatusText = TextView(this).apply {
            text = "Video ရွေးပါ။"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(comboStatusText, rowParams(dp(8)))

        comboStatusCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBg()
            setPadding(dp(16), dp(12), dp(16), dp(12))
            visibility = View.GONE
        }
        comboStatusCard.addView(TextView(this).apply {
            text = "အခြေအနေ"
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.rgb(140, 220, 170))
        })
        comboStatusLog = TextView(this).apply {
            text = ""
            textSize = 14f
            setTextColor(Color.rgb(220, 235, 225))
            setPadding(0, dp(6), 0, 0)
        }
        comboStatusCard.addView(comboStatusLog)
        col.addView(comboStatusCard, rowParams(dp(12)))

        comboDownloadButton = glassButton("Video ဒေါင်းလုဒ်လုပ်ရန်", selectedStrokeColor)
        comboDownloadButton.visibility = View.GONE
        comboDownloadButton.setOnClickListener { onComboDownloadClicked() }
        col.addView(comboDownloadButton, rowParams(dp(12)))

        comboPreviewVideo = VideoView(this).apply {
            visibility = View.GONE
        }
        comboPreviewVideo.setMediaController(
            MediaController(this).apply { setAnchorView(comboPreviewVideo) }
        )
        // v0.14.1: never show Android's raw "Can't play this video"
        // dialog — report in Burmese and keep the screen usable.
        comboPreviewVideo.setOnErrorListener { _, _, _ ->
            comboStatusText.text = "Video ဖိုင် ဖွင့်လို့ မရဘူး — Download/zhang file ထဲက သိမ်းပြီးသား ဖိုင်ကို ဖွင့်ကြည့်ပါ။"
            true
        }
        col.addView(
            comboPreviewVideo,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(280)
            ).apply { topMargin = dp(12) }
        )

        col.addView(backLink(), rowParams(dp(16)))
        val scroll = buildPosterSheet("menu_hero.jpg", comboTitle, col)
        comboScrollView = scroll
        return scroll
    }

    private fun refreshComboVoiceButtons() {
        for ((index, button) in comboVoiceButtons.withIndex()) {
            val selected = index == comboVoiceIndex
            button.background = if (selected) selectedPillBg() else glassPillBg()
            button.setTextColor(Color.WHITE)
        }
    }

    // v0.13.0: one row of subtitle color swatches; the selected
    // swatch gets a white ring. Both screens share the same
    // selection, so one refresh updates every swatch.
    private fun subtitleColorRow(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        for ((index, color) in subtitleColors.withIndex()) {
            val swatch = View(this).apply {
                background = swatchBg(color, index == subtitleColorIndex)
                setOnClickListener {
                    subtitleColorIndex = index
                    prefs.edit().putInt("subtitle_color_index", index).apply()
                    refreshSubtitleColorSwatches()
                }
            }
            subtitleColorSwatches.add(swatch to index)
            // v0.13.1: equal weights so 8 swatches fit any phone
            // width (fixed dp sizes overflowed narrow screens).
            val params = LinearLayout.LayoutParams(0, dp(36), 1f).apply {
                marginStart = dp(4)
                marginEnd = dp(4)
            }
            row.addView(swatch, params)
        }
        return row
    }

    private fun swatchBg(color: Int, selected: Boolean): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            if (selected) setStroke(dp(3), Color.WHITE)
            else setStroke(dp(1), Color.argb(90, 255, 255, 255))
        }

    private fun refreshSubtitleColorSwatches() {
        for ((swatch, index) in subtitleColorSwatches) {
            swatch.background =
                swatchBg(subtitleColors[index], index == subtitleColorIndex)
        }
    }

    private fun buildMtvScreen(): View {
        val col = screenColumn()
        col.addView(titleText("ပုံ + သီချင်း MTV ထုတ်ရန်", 22f))

        mtvImageButton = pillButton("လူပုံ ရွေးပါ", Color.WHITE, Color.BLACK, null)
        mtvImageButton.setOnClickListener { pickMtvImageLauncher.launch("image/*") }
        col.addView(mtvImageButton, rowParams(dp(24)))

        mtvImageLabel = TextView(this).apply {
            text = "ပုံ မရွေးရသေးဘူး"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(mtvImageLabel, rowParams(dp(8)))

        mtvSongField = EditText(this).apply {
            hint = "သီချင်းနာမည် ရိုက်ပါ — ဥပမာ Chit Thu"
            textSize = 17f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_TEXT
            maxLines = 1
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(22), dp(14), dp(22), dp(14))
        }
        col.addView(mtvSongField, rowParams(dp(16)))

        mtvLinkField = EditText(this).apply {
            hint = "YouTube Link (ရှိရင် ဒီမှာ ထည့်ပါ)"
            textSize = 17f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            maxLines = 1
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(22), dp(14), dp(22), dp(14))
        }
        col.addView(mtvLinkField, rowParams(dp(12)))

        col.addView(TextView(this).apply {
            text = "Link ထည့်ရင် အဲ့သီချင်းကို တိုက်ရိုက်သုံးမယ်။ Link မထည့်ရင် နာမည်နဲ့ ရှာမယ်။ သီချင်းရဲ့ အကောင်းဆုံး 20 စက္ကန့်ကို သုံးမယ်။"
            textSize = 15f
            setTextColor(Color.WHITE)
        }, rowParams(dp(8)))

        mtvMakeButton = pillButton(
            "MTV လုပ်မယ်", Color.rgb(30, 107, 74), Color.WHITE, Color.rgb(76, 175, 125)
        )
        mtvMakeButton.setOnClickListener { onMtvClicked() }
        col.addView(mtvMakeButton, rowParams(dp(16)))

        mtvProgressBar =
            ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = 0
            }
        col.addView(mtvProgressBar, rowParams(dp(16)))

        mtvStatusText = TextView(this).apply {
            text = "ပုံ ရွေးပြီး သီချင်းနာမည် ရိုက်ထည့်ပါ။"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(mtvStatusText, rowParams(dp(8)))

        mtvDownloadButton = pillButton("Video ဒေါင်းလုဒ်လုပ်ရန်", Color.WHITE, Color.BLACK, null)
        mtvDownloadButton.visibility = View.GONE
        mtvDownloadButton.setOnClickListener { onMtvDownloadClicked() }
        col.addView(mtvDownloadButton, rowParams(dp(12)))

        col.addView(backLink(), rowParams(dp(16)))
        return wrapScroll(col)
    }

    private fun buildTtsScreen(): View {
        val ttsTitle = TextView(this).apply {
            text = "စာကို AI အသံဖြင့် ဖတ်ပြရန်"
        }
        val col = sheetColumn()

        // v0.10.19: SRT reading vs plain-text reading, separated (Zin)
        // — an SRT file can be the voice source even when the video
        // has no audio at all.
        val ttsSrtRow = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        val ttsSrtPickButton = glassButton("SRT ဖိုင် ရွေးပါ")
        ttsSrtPickButton.setOnClickListener { pickTtsSrtLauncher.launch("*/*") }
        ttsSrtRow.addView(ttsSrtPickButton, rowParams(0))
        ttsSrtLabel = TextView(this).apply {
            text = "SRT မရွေးရသေးဘူး"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        ttsSrtRow.addView(ttsSrtLabel, rowParams(dp(8)))
        val ttsModeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val ttsModeTextButton = glassButton("သာမန်စာ").apply {
            textSize = 16f
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            ).apply { marginEnd = dp(8) }
        }
        val ttsModeSrtButton = glassButton("SRT ဖိုင်").apply {
            textSize = 16f
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            )
        }
        fun refreshTtsModeRow() {
            ttsTextField.visibility = if (ttsSrtMode) View.GONE else View.VISIBLE
            ttsSrtRow.visibility = if (ttsSrtMode) View.VISIBLE else View.GONE
            ttsModeTextButton.background =
                if (!ttsSrtMode) selectedPillBg() else glassPillBg()
            ttsModeTextButton.setTextColor(Color.WHITE)
            ttsModeSrtButton.background =
                if (ttsSrtMode) selectedPillBg() else glassPillBg()
            ttsModeSrtButton.setTextColor(Color.WHITE)
        }
        ttsModeTextButton.setOnClickListener {
            ttsSrtMode = false
            refreshTtsModeRow()
        }
        ttsModeSrtButton.setOnClickListener {
            ttsSrtMode = true
            refreshTtsModeRow()
        }
        ttsModeRow.addView(ttsModeTextButton)
        ttsModeRow.addView(ttsModeSrtButton)
        col.addView(ttsModeRow, rowParams(dp(16)))
        // v0.11.0: Function 3 is plain text only — the SRT-mode
        // switch stays in code, hidden.
        ttsModeRow.visibility = View.GONE

        ttsTextField = EditText(this).apply {
            hint = "ဖတ်ပြစေချင်တဲ့ မြန်မာစာသား ဒီမှာ ရိုက်ထည့်ပါ..."
            filters = arrayOf(InputFilter.LengthFilter(20000))
            textSize = 17f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(170, 180, 175))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 6
            gravity = Gravity.TOP
            background = glassPillBg()
            setPadding(dp(22), dp(14), dp(22), dp(14))
        }
        col.addView(ttsTextField, rowParams(dp(24)))
        col.addView(ttsSrtRow, rowParams(dp(24)))
        refreshTtsModeRow()

        ttsImageButton = glassButton("ဇာတ်ကောင်ပုံ ရွေးပါ")
        ttsImageButton.setOnClickListener { pickImageLauncher.launch("image/*") }
        col.addView(ttsImageButton, rowParams(dp(12)))

        ttsImageLabel = TextView(this).apply {
            text = "ပုံ မရွေးရသေးဘူး (ပုံ မထည့်ရင် အသံသီးသန့် ထွက်မယ်)"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(ttsImageLabel, rowParams(dp(8)))
        // v0.11.0: Function 3 is audio only — no image button.
        ttsImageButton.visibility = View.GONE
        ttsImageLabel.visibility = View.GONE

        col.addView(sectionLabel("အသံ ရွေးပါ"), rowParams(dp(20)))
        col.addView(buildVoicePicker(false), rowParams(dp(8)))


        ttsPitchLabel = TextView(this).apply {
            text = "အသံနိမ့်မြင့်: ပုံမှန်"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(ttsPitchLabel, rowParams(dp(20)))
        val pitchBar = SeekBar(this).apply { max = 1000; progress = 500 }
        pitchBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                ttsPitch = (progress - 500) / 10
                ttsPitchLabel.text = when {
                    ttsPitch == 0 -> "အသံနိမ့်မြင့်: ပုံမှန်"
                    ttsPitch > 0 -> "အသံနိမ့်မြင့်: +$ttsPitch မြင့်"
                    else -> "အသံနိမ့်မြင့်: $ttsPitch နိမ့်"
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        col.addView(pitchBar, rowParams(dp(4)))

        ttsRateLabel = TextView(this).apply {
            text = "အမြန်နှုန်း: ပုံမှန်"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(ttsRateLabel, rowParams(dp(20)))
        val rateBar = SeekBar(this).apply { max = 100; progress = 50 }
        rateBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                ttsRate = progress - 50
                ttsRateLabel.text = when {
                    ttsRate == 0 -> "အမြန်နှုန်း: ပုံမှန်"
                    ttsRate > 0 -> "အမြန်နှုန်း: +$ttsRate% မြန်"
                    else -> "အမြန်နှုန်း: $ttsRate% နှေး"
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        col.addView(rateBar, rowParams(dp(4)))

        ttsMakeButton = ctaButton("အသံထုတ်မယ်")
        ttsMakeButton.setOnClickListener { onTtsClicked() }
        col.addView(ttsMakeButton, rowParams(dp(16)))

        ttsProgressBar =
            ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = 0
            }
        col.addView(ttsProgressBar, rowParams(dp(16)))

        // v0.6.20: listen to the generated voice here (play/pause +
        // seek + time) before downloading anything.
        ttsPlayerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
        }
        ttsPlayButton = Button(this).apply {
            text = "▶"
            textSize = 18f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = pillBg(Color.rgb(30, 107, 74), Color.rgb(76, 175, 125), 2)
            setPadding(dp(16), dp(6), dp(16), dp(6))
            setOnClickListener { toggleTtsPlayback() }
        }
        ttsPlayerRow.addView(ttsPlayButton)
        ttsSeekBar = SeekBar(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            )
        }
        ttsSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    try {
                        ttsPlayer?.seekTo(progress)
                    } catch (e: Exception) {
                    }
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        ttsPlayerRow.addView(ttsSeekBar)
        ttsTimeText = TextView(this).apply {
            text = "00:00 / 00:00"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(dp(8), 0, 0, 0)
        }
        ttsPlayerRow.addView(ttsTimeText)
        col.addView(ttsPlayerRow, rowParams(dp(8)))

        ttsStatusText = TextView(this).apply {
            text = "စာသား ရိုက်ထည့်ပြီး အသံထုတ်ပါ။ (စာသား အရှည် ၂၀၀၀၀ လုံးထိ ရတယ်)"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(ttsStatusText, rowParams(dp(8)))

        ttsDownloadButton = glassButton("အသံဖိုင် ဒေါင်းလုပ်လုပ်ရန်", selectedStrokeColor)
        ttsDownloadButton.visibility = View.GONE
        ttsDownloadButton.setOnClickListener { onTtsDownloadClicked() }
        col.addView(ttsDownloadButton, rowParams(dp(12)))

        col.addView(backLink(), rowParams(dp(16)))
        return buildPosterSheet("menu_mic.jpg", ttsTitle, col)
    }

    private fun buildPromptVideoScreen(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(12))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // Header: back + title.
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val back = TextView(this).apply {
            text = "←"
            textSize = 24f
            setTextColor(Color.WHITE)
            setPadding(dp(4), dp(4), dp(16), dp(4))
            setOnClickListener { showScreen(menuScreen) }
        }
        header.addView(back)
        header.addView(titleText("Video generation", 22f).apply {
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            )
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
        })
        root.addView(
            header,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        // Middle area: hint, picked images, status, progress, download.
        val middleScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            ).apply { topMargin = dp(8) }
        }
        val middle = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        middleScroll.addView(middle)
        root.addView(middleScroll)

        pvHintText = TextView(this).apply {
            text = "ဥပမာ — ရွာက ကြောင်လေးတစ်ကောင် ဈေးထဲမှာ ငါးခိုးစားတဲ့ ဇာတ်လမ်း"
            textSize = 14f
            setTextColor(Color.rgb(180, 180, 180))
            gravity = Gravity.CENTER
        }
        middle.addView(pvHintText, rowParams(dp(16)))

        // v0.6.9: up to 3 scene images (server v26+); thumbnails
        // with a small X each (v0.6.10/v0.6.12).
        pvImageLabel = TextView(this).apply {
            text = "ပုံ မထည့်ရသေးဘူး — ပုံမထည့်ရင် AI က ပုံထုတ်ပေးမယ်"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        middle.addView(pvImageLabel, rowParams(dp(12)))
        pvImageRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_HORIZONTAL
            visibility = View.GONE
        }
        middle.addView(pvImageRow, rowParams(dp(4)))
        pvClearImagesButton = pillButton("ပုံတွေ ဖျက်မယ်", Color.WHITE, Color.BLACK, null)
        pvClearImagesButton.visibility = View.GONE
        pvClearImagesButton.setOnClickListener {
            pvImageUris.clear()
            updatePvImageLabel()
        }
        middle.addView(pvClearImagesButton, rowParams(dp(8)))

        pvStatusText = TextView(this).apply {
            text = "Prompt ရိုက်ထည့်ပြီး Video ထုတ်ပါ။"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        middle.addView(pvStatusText, rowParams(dp(16)))
        pvProgressBar =
            ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = 0
            }
        middle.addView(pvProgressBar, rowParams(dp(8)))
        pvDownloadButton = pillButton(
            "Video ဒေါင်းလုဒ်လုပ်ရန်", Color.WHITE, Color.BLACK, null
        )
        pvDownloadButton.visibility = View.GONE
        pvDownloadButton.setOnClickListener { onPvDownloadClicked() }
        middle.addView(pvDownloadButton, rowParams(dp(12)))

        // Bottom input card: prompt field + image button + send.
        pvInputCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(24).toFloat()
                setColor(Color.rgb(35, 35, 35))
            }
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        pvTextField = EditText(this).apply {
            hint = "ဒီနေ့ ဘာ Video လုပ်မလဲ?"
            textSize = 17f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(150, 150, 150))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 2
            maxLines = 5
            gravity = Gravity.TOP
            background = null
            setPadding(0, dp(4), 0, dp(4))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        pvInputCard.addView(pvTextField)
        val cardRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        pvPickImageButton = pillButton("+", Color.rgb(60, 60, 60), Color.WHITE, null).apply {
            textSize = 22f
            setPadding(dp(18), dp(2), dp(18), dp(2))
            setOnClickListener { pickPvImageLauncher.launch("image/*") }
        }
        cardRow.addView(pvPickImageButton)
        cardRow.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                0, 1, 1f
            )
        })
        // v0.6.12: no voice picker on this screen — the server (v28+)
        // assigns each character their own voice automatically.
        pvMakeButton = pillButton(
            "➤", Color.rgb(30, 107, 74), Color.WHITE, Color.rgb(76, 175, 125)
        ).apply {
            textSize = 20f
            setPadding(dp(18), dp(2), dp(18), dp(2))
            setOnClickListener { onPromptVideoClicked() }
        }
        cardRow.addView(pvMakeButton)
        pvInputCard.addView(
            cardRow,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) }
        )
        root.addView(
            pvInputCard,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        )
        return root
    }

    private fun buildVoicePicker(showAuto: Boolean): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (showAuto) {
            val auto = glassButton("AI က ဇာတ်ကောင် အလိုက် ခွဲပေးမယ်")
            auto.textSize = 16f
            auto.setOnClickListener {
                autoVoice = true
                // Auto split is edge-only; a Gemini style would not apply.
                ttsEngine = "edge"
                ttsStyle = "natural"
                refreshStyleButtons()
                refreshVoiceButtons()
            }
            autoVoiceButtons.add(auto)
            box.addView(auto, rowParams(0))
        }
        for ((index, option) in voiceOptions.withIndex()) {
            val b = glassButton(option.label)
            b.textSize = 16f
            b.setOnClickListener {
                selectedVoiceIndex = index
                autoVoice = false
                refreshVoiceButtons()
            }
            voiceOptionButtons.add(b to index)
            box.addView(b, rowParams(dp(10)))
        }
        refreshVoiceButtons()
        return box
    }

    private fun refreshVoiceButtons() {
        for (button in autoVoiceButtons) {
            button.background = if (autoVoice) selectedPillBg() else glassPillBg()
            button.setTextColor(Color.WHITE)
        }
        for ((button, index) in voiceOptionButtons) {
            val selected = !autoVoice && index == selectedVoiceIndex
            button.background = if (selected) selectedPillBg() else glassPillBg()
            button.setTextColor(Color.WHITE)
        }
    }

    /** Narration style picker (TTS screen only, v0.6.5). */
    private fun buildStylePicker(): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val styles = listOf(
            "edge" to "ပုံမှန် အသံ",
            "natural" to "သဘာဝ အသံနိမ့်အမြင့်",
            "spooky" to "သရဲ ဇာတ်လမ်း အသံ"
        )
        for ((key, label) in styles) {
            val b = glassButton(label)
            b.textSize = 16f
            b.setOnClickListener {
                if (key == "edge") {
                    ttsEngine = "edge"
                    ttsStyle = "natural"
                } else {
                    ttsEngine = "gemini"
                    ttsStyle = key
                    // Gemini is single-voice; the auto split is edge-only.
                    autoVoice = false
                    refreshVoiceButtons()
                }
                refreshStyleButtons()
            }
            styleButtons.add(b to key)
            box.addView(b, rowParams(dp(10)))
        }
        refreshStyleButtons()
        return box
    }

    private fun refreshStyleButtons() {
        val current = if (ttsEngine == "edge") "edge" else ttsStyle
        for ((button, key) in styleButtons) {
            val selected = key == current
            button.background = if (selected) selectedPillBg() else glassPillBg()
            button.setTextColor(Color.WHITE)
        }
    }

    private fun backLink(): TextView = TextView(this).apply {
        text = "← Menu သို့ ပြန်သွားမယ်"
        textSize = 15f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(12), dp(12), dp(12))
        setOnClickListener { showScreen(menuScreen) }
    }

    // ---------- actions ----------

    private fun onLoginClicked() {
        val key = keyField.text.toString().trim()
        if (key.isEmpty()) {
            loginStatus.text = "API Key ထည့်ပါ။"
            return
        }
        // Hide the keyboard: it used to stay open over the menu screen.
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(keyField.windowToken, 0)
        apiKey = key
        prefs.edit().putString("gemini_api_key", key).apply()
        loginStatus.text = ""
        showScreen(menuScreen)
    }

    private fun openWork(targetMode: Int) {
        mode = targetMode
        if (mode == modeSrt) {
            workTitle.text = "SRT သီးသန့်ထုတ်ရန်"
            makeButton.text = "SRT ထုတ်မယ်"
        } else {
            workTitle.text = "Video ကို မြန်မာစာတန်းထိုးပေးရန်"
            makeButton.text = "စာတန်းထိုးထားသော Video လုပ်မယ်"
        }
        // v0.9.9: the cover toggle only matters for the burn path.
        workCoverCheck.visibility =
            if (mode == modeSrt) View.GONE else View.VISIBLE
        // v0.10.9: title + top-band toggles are burn-only too.
        workTitleField.visibility =
            if (mode == modeSrt) View.GONE else View.VISIBLE
        workTopBandCheck.visibility =
            if (mode == modeSrt) View.GONE else View.VISIBLE
        setStatus("Video ရွေးပါ။")
        progressBar.progress = 0
        updateMakeEnabled()
        showScreen(workScreen)
    }

    private fun onMakeClicked() {
        // v0.10.13: picked videos only — the link input was removed
        // (Zin, 15 Nov). workAutoTitle stays null (no link fetch).
        workAutoTitle = null
        if (videoUri == null) {
            setStatus("Video ရွေးပါ။")
            return
        }
        setBusy(true)
        progressBar.progress = 0
        workDownloadButton.visibility = View.GONE
        if (::workPreviewVideo.isInitialized) {
            workPreviewVideo.stopPlayback()
            workPreviewVideo.visibility = View.GONE
        }
        // v0.14.1: the previous finished file was kept for the
        // preview — delete it now so cache doesn't pile up.
        workLastOutput?.let { if (it.exists()) it.delete() }
        workLastOutput = null
        workLastSrt = null
        val firstStage = "အသံ ထုတ်နေတယ်…"
        setStatus(firstStage)
        clearWorkStages()
        workStage(firstStage)
        Thread {
            try {
                val video: Uri = videoUri ?: throw java.io.IOException("Video မရွေးရသေးဘူး။")
                // v0.10.0: upload only the extracted audio (~10x less
                // data, much faster on slow connections). Server v35+
                // detects audio-only input. The original video stays
                // on the phone for the burn step below.
                val audioFile = File(cacheDir, "srt-audio-${stamp()}.m4a")
                extractAudioToM4a(video, audioFile)
                workStage("အသံ တင်နေတယ်…")
                val client = TranscribeClient(contentResolver)
                val srtText = when (val res = client.submitAudioFileChunked(
                    audioFile, "audio.m4a", apiKey,
                    onUploadProgress = { pct ->
                        runOnUiThread {
                            progressBar.isIndeterminate = false
                            progressBar.progress = pct
                            setStatus("အသံ တင်နေတယ်… $pct%")
                        }
                    },
                    onRetry = { n ->
                        workStage("လိုင်းပြတ်သွားလို့ အသံ ပြန်တင်နေတယ်… ($n/3)")
                    }
                )) {
                    is TranscribeClient.SubmitResult.Ready -> res.srt
                    is TranscribeClient.SubmitResult.Job -> {
                        runOnUiThread { progressBar.isIndeterminate = true }
                        postStatus("Gemini က အသံနားထောင်နေတယ်… (၁-၃ မိနစ် ကြာနိုင်တယ်)")
                        workStage("Gemini က အသံနားထောင်နေတယ်…")
                        waitForJob(client, res.jobId)
                    }
                }
                audioFile.delete()
                // v0.13.0: the picked subtitle color, shared by both screens.
                val cues = SrtParser.parse(srtText)
                    .map { it.copy(color = subtitleColors[subtitleColorIndex]) }
                if (cues.isEmpty()) {
                    postError("ဒီ Video မှာ အသံမတွေ့ဘူး။")
                    return@Thread
                }
                workStage("စာတန်း ရပြီ — ${cues.size} ပိုင်း")
                if (mode == modeSrt) {
                    // v0.6.2: SRT waits for the download button too.
                    workLastSrt = srtText
                    runOnUiThread {
                        setBusy(false)
                        progressBar.progress = 100
                        workDownloadButton.text = "SRT ဒေါင်းလုဒ်လုပ်ရန်"
                        workDownloadButton.isEnabled = true
                        workDownloadButton.visibility = View.VISIBLE
                        setStatus("ပြီးပြီ — ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။")
                        workStage("ပြီးပြီ — SRT ဒေါင်းလုပ်လုပ်ပါ")
                    }
                    return@Thread
                }
                // v0.14.0: auto-detect where the baked-in subtitles
                // sit; null falls back to the cover checkboxes below.
                workStage("မူရင်းစာတန်း နေရာ ရှာနေတယ်…")
                val subsZone = detectSubsZoneSafe(client, video)
                if (subsZone != null) workStage("မူရင်းစာတန်း တွေ့ပြီ — မှုံဘား အလိုလျှောက် ထားမယ်")
                // Transformer must start on the main thread.
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    try {
                        val typeface = loadMyanmarTypeface()
                        val outputFile = newOutputFile()
                        // v0.10.15: remember the source for audio repair.
                        workLastSourceUri = video
                        val newBurner = SubtitleBurner(this)
                        burner = newBurner
                        progressBar.isIndeterminate = false
                        setStatus("စာတန်းထည့်နေတယ်… 0%")
                        workStage("စာတန်းထည့်နေတယ်…")
                        newBurner.start(
                            video, cues, typeface, outputFile, burnCallback,
                            // v0.10.13: typed title only (auto title died
                            // with the link input); else no title.
                            topText = workTitleField.text.toString().trim().ifBlank { workAutoTitle },
                            coverOriginalSubs = workCoverCheck.isChecked,
                            // v0.10.13: the top band follows the box only
                            // (Zin: hide only when a logo is there).
                            coverTopLogos = workTopBandCheck.isChecked,
                            subsZone = subsZone
                        )
                    } catch (e: Exception) {
                        setBusy(false)
                        setStatus("အမှား: ${e.message ?: "unknown error"}")
                    }
                }
            } catch (e: Exception) {
                postError(e.message ?: "unknown error")
                workStage("အမှား: ${e.message ?: "unknown error"}")
            }
        }.start()
    }

    /**
     * v0.14.0: auto subtitle-zone detection (Zin, 16 Nov). Samples 4
     * frames, asks the server (v55+) where the baked-in subtitles sit,
     * and returns the band as (yStart, yEnd) frame fractions from the
     * top — or null on ANY failure, so the burn always falls back to
     * the manual cover bands. Background thread only.
     */
    private fun detectSubsZoneSafe(client: TranscribeClient, video: Uri): Pair<Float, Float>? {
        return try {
            if (apiKey.isBlank()) return null
            val frames = FrameSampler.sampleFrames(this, video)
            if (frames.isEmpty()) return null
            client.detectSubsZone(frames, apiKey)?.let { it.yStart to it.yEnd }
        } catch (e: Exception) {
            null
        }
    }

    private fun onComboClicked() {
        val video = comboVideoUri
        if (video == null) {
            comboStatusText.text = "Video ရွေးပါ။"
            return
        }
        comboPickButton.isEnabled = false
        comboMakeButton.isEnabled = false
        comboProgressBar.progress = 0
        comboDownloadButton.visibility = View.GONE
        comboPreviewVideo.stopPlayback()
        comboPreviewVideo.visibility = View.GONE
        // v0.14.1: delete the previous finished file (kept for the
        // preview) so cache doesn't pile up.
        comboLastOutput?.let { if (it.exists()) it.delete() }
        comboLastOutput = null
        comboSrtText = null
        comboVideoDurationSec = probeVideoDurationSec(video)
        val firstStage = "အသံ ထုတ်နေတယ်…"
        comboStatusText.text = firstStage
        clearComboStages()
        comboStage(firstStage)
        Thread {
            try {
                // Stage 1: upload only the extracted audio (~10x less
                // data), transcribe with the same path as the work
                // screen. The SRT from this step is used for BOTH the
                // burn and the narration, so voice and subtitles match.
                val audioFile = File(cacheDir, "combo-audio-${stamp()}.m4a")
                extractAudioToM4a(video, audioFile)
                if (audioSampleCount(audioFile) <= 0) {
                    throw IOException("ဒီ Video မှာ အသံမပါဘူး — အသံပါတဲ့ Video ရွေးပါ။")
                }
                comboStage("အသံ တင်နေတယ်…")
                val client = TranscribeClient(contentResolver)
                val srtText = when (val res = client.submitAudioFileChunked(
                    audioFile, "audio.m4a", apiKey,
                    onUploadProgress = { pct ->
                        runOnUiThread {
                            comboProgressBar.isIndeterminate = false
                            comboProgressBar.progress = pct
                            comboStatusText.text = "အသံ တင်နေတယ်… $pct%"
                        }
                    },
                    onRetry = { n ->
                        comboStage("လိုင်းပြတ်သွားလို့ အသံ ပြန်တင်နေတယ်… ($n/3)")
                    }
                )) {
                    is TranscribeClient.SubmitResult.Ready -> res.srt
                    is TranscribeClient.SubmitResult.Job -> {
                        runOnUiThread {
                            comboProgressBar.isIndeterminate = true
                            comboStatusText.text = "Gemini က အသံနားထောင်နေတယ်… (၁-၃ မိနစ် ကြာနိုင်တယ်)"
                        }
                        comboStage("Gemini က အသံနားထောင်နေတယ်…")
                        waitForJob(client, res.jobId)
                    }
                }
                audioFile.delete()
                // v0.13.0: the picked subtitle color, shared by both screens.
                val cues = SrtParser.parse(srtText)
                    .map { it.copy(color = subtitleColors[subtitleColorIndex]) }
                if (cues.isEmpty()) {
                    runOnUiThread {
                        comboPickButton.isEnabled = true
                        comboMakeButton.isEnabled = true
                        comboProgressBar.isIndeterminate = false
                        comboStatusText.text = "အမှား: ဒီ Video မှာ အသံမတွေ့ဘူး။"
                    }
                    comboStage("အမှား: ဒီ Video မှာ အသံမတွေ့ဘူး။")
                    return@Thread
                }
                comboStage("စာတန်း ရပြီ — ${cues.size} ပိုင်း")
                comboSrtText = srtText
                // v0.14.0: auto-detect the baked-in subtitle zone; when
                // found, the blur bar goes there INSTEAD of the fixed
                // bottom/top bands. Null keeps the fixed bands.
                comboStage("မူရင်းစာတန်း နေရာ ရှာနေတယ်…")
                val subsZone = detectSubsZoneSafe(client, video)
                if (subsZone != null) comboStage("မူရင်းစာတန်း တွေ့ပြီ — မှုံဘား အလိုလျှောက် ထားမယ်")
                // Stage 2: burn. Transformer must start on the main
                // thread. comboBurnCallback chains stages 3-4.
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    try {
                        val typeface = loadMyanmarTypeface()
                        val outputFile = newOutputFile()
                        val newBurner = SubtitleBurner(this)
                        burner = newBurner
                        comboProgressBar.isIndeterminate = false
                        comboStatusText.text = "စာတန်းထည့်နေတယ်… 0%"
                        comboStage("စာတန်းထည့်နေတယ်…")
                        newBurner.start(
                            video, cues, typeface, outputFile, comboBurnCallback,
                            topText = null,
                            coverOriginalSubs = subsZone == null,
                            coverTopLogos = subsZone == null,
                            subsZone = subsZone
                        )
                    } catch (e: Exception) {
                        comboPickButton.isEnabled = true
                        comboMakeButton.isEnabled = true
                        comboStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    comboPickButton.isEnabled = true
                    comboMakeButton.isEnabled = true
                    comboProgressBar.isIndeterminate = false
                    comboProgressBar.progress = 0
                    comboStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
                comboStage("အမှား: ${e.message ?: "unknown error"}")
            }
        }.start()
    }

    private fun onComboDownloadClicked() {
        val output = comboLastOutput ?: return
        comboDownloadButton.isEnabled = false
        comboStatusText.text = "Download/zhang file ထဲ သိမ်းနေတယ်…"
        Thread {
            try {
                if (!output.exists()) {
                    runOnUiThread {
                        comboDownloadButton.isEnabled = false
                        comboStatusText.text = "ဒီ Video သိမ်းပြီးသွားပြီ — Download/zhang file ထဲ ရှိတယ်။"
                    }
                    return@Thread
                }
                // v0.14.1: keep the preview file after download — the
                // old delete-on-save left the preview pointing at a
                // deleted file, so returning to this screen showed
                // "Can't play this video." The file is deleted when
                // the next job starts instead.
                val savedName = copyToDownloads(output, "video/mp4", FOLDER_TRANSLATED, deleteSource = false)
                runOnUiThread {
                    if (savedName != null) {
                        comboDownloadButton.isEnabled = false
                        comboDownloadButton.text = "သိမ်းပြီးပြီ"
                        comboStatusText.text = "ပြီးပြီ — Download/zhang file ထဲ သိမ်းပြီးပြီ:\n$savedName"
                    } else {
                        comboDownloadButton.isEnabled = true
                        comboStatusText.text = "အမှား: သိမ်းလို့ မရဘူး။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    comboDownloadButton.isEnabled = true
                    comboStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    /** Stage log for Function 1's အခြေအနေ box. Safe from any thread. */
    private fun comboStage(text: String) {
        runOnUiThread {
            if (::comboStatusLog.isInitialized) {
                comboStatusCard.visibility = View.VISIBLE
                val cur = comboStatusLog.text.toString()
                comboStatusLog.text = if (cur.isEmpty()) "• $text" else "$cur\n• $text"
            }
        }
    }

    private fun clearComboStages() {
        runOnUiThread {
            if (::comboStatusLog.isInitialized) {
                comboStatusLog.text = ""
                comboStatusCard.visibility = View.GONE
            }
        }
    }

    private fun muxNarrationOntoVideo(videoUri: Uri, narrationFile: File, outFile: File) {
        var rotation = 0
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, videoUri)
            rotation = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION
            )?.toIntOrNull() ?: 0
        } catch (e: Exception) {
        } finally {
            try {
                retriever.release()
            } catch (e: Exception) {
            }
        }
        val muxer = MediaMuxer(
            outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
        )
        if (rotation != 0) muxer.setOrientationHint(rotation)
        val vExtractor = MediaExtractor()
        val aExtractor = MediaExtractor()
        try {
            vExtractor.setDataSource(this, videoUri, null)
            var vTrack = -1
            var vFormat: MediaFormat? = null
            for (i in 0 until vExtractor.trackCount) {
                val f = vExtractor.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME).orEmpty().startsWith("video/")) {
                    vTrack = i
                    vFormat = f
                    break
                }
            }
            if (vTrack < 0 || vFormat == null) {
                throw IOException("Video track ရှာမတွေ့ဘူး။")
            }
            vExtractor.selectTrack(vTrack)
            val outVideo = muxer.addTrack(vFormat)
            aExtractor.setDataSource(narrationFile.absolutePath)
            var aTrack = -1
            var aFormat: MediaFormat? = null
            for (i in 0 until aExtractor.trackCount) {
                val f = aExtractor.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME).orEmpty().startsWith("audio/")) {
                    aTrack = i
                    aFormat = f
                    break
                }
            }
            if (aTrack < 0 || aFormat == null) {
                throw IOException("အသံ track ရှာမတွေ့ဘူး။")
            }
            aExtractor.selectTrack(aTrack)
            val outAudio = muxer.addTrack(aFormat)
            muxer.start()
            val buffer = ByteBuffer.allocate(2 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            // v0.10.20: sampleTime can be NEGATIVE for the first
            // samples (AAC priming / edit lists — the server's ffmpeg
            // AAC files start at -23ms). That is NOT end-of-stream:
            // the old `time < 0` check made the mux drop the WHOLE
            // narration track with no error (15 Nov voiceover bug).
            // EOS is ONLY readSampleData() < 0. Each track is shifted
            // so its first sample starts at 0 (MediaMuxer needs
            // timestamps >= 0). Peek-reads decide emptiness without
            // consuming: readSampleData does not advance.
            var vTime = vExtractor.sampleTime
            var aTime = aExtractor.sampleTime
            var vDone = false
            var aDone = false
            if (vTime < 0L && vExtractor.readSampleData(buffer, 0) < 0) vDone = true
            if (aTime < 0L && aExtractor.readSampleData(buffer, 0) < 0) aDone = true
            val vShift = if (!vDone && vTime < 0L) -vTime else 0L
            val aShift = if (!aDone && aTime < 0L) -aTime else 0L
            while (!vDone || !aDone) {
                if (!vDone && (aDone || vTime + vShift <= aTime + aShift)) {
                    val size = vExtractor.readSampleData(buffer, 0)
                    if (size < 0) {
                        vDone = true
                    } else {
                        info.set(0, size, vTime + vShift, vExtractor.sampleFlags)
                        muxer.writeSampleData(outVideo, buffer, info)
                        vExtractor.advance()
                        vTime = vExtractor.sampleTime
                    }
                } else if (!aDone) {
                    val size = aExtractor.readSampleData(buffer, 0)
                    if (size < 0) {
                        aDone = true
                    } else {
                        info.set(0, size, aTime + aShift, aExtractor.sampleFlags)
                        muxer.writeSampleData(outAudio, buffer, info)
                        aExtractor.advance()
                        aTime = aExtractor.sampleTime
                    }
                }
            }
            muxer.stop()
        } finally {
            try {
                vExtractor.release()
            } catch (e: Exception) {
            }
            try {
                aExtractor.release()
            } catch (e: Exception) {
            }
            try {
                muxer.release()
            } catch (e: Exception) {
            }
        }
    }

    private fun probeVideoDurationSec(uri: Uri): Double {
        return try {
            val r = MediaMetadataRetriever()
            r.setDataSource(this, uri)
            val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            r.release()
            ms / 1000.0
        } catch (_: Exception) {
            0.0
        }
    }

    private fun onTtsClicked() {
        // v0.10.19: SRT mode reads the picked SRT's cue texts in
        // order; plain-text mode reads the typed text. Same voices,
        // same submit paths — only the script source differs.
        val text = if (ttsSrtMode) {
            val srt = ttsSrtText?.trim().orEmpty()
            if (srt.isEmpty()) {
                ttsStatusText.text = "SRT ဖိုင် ရွေးပါ။"
                return
            }
            srt
        } else {
            val typed = ttsTextField.text.toString().trim()
            if (typed.isEmpty()) {
                ttsStatusText.text = "စာသား ရိုက်ထည့်ပါ။"
                return
            }
            typed
        }
        val option = voiceOptions[selectedVoiceIndex]
        val rate = ttsRate
        val mode = if (autoVoice) "auto" else "manual"
        val imageUri = ttsImageUri
        ttsMakeButton.isEnabled = false
        ttsDownloadButton.visibility = View.GONE
        stopTtsPlayer()
        ttsPlayerRow.visibility = View.GONE
        ttsLastAudio = null
        ttsLastSrt = null
        ttsLastVideo = null
        ttsLastVideoUrl = null
        ttsProgressBar.isIndeterminate = true
        ttsStatusText.text = "အသံထုတ်နေတယ်…"
        Thread {
            try {
                val client = TranscribeClient(contentResolver)
                if (imageUri != null) {
                    // Image picked: the server builds a finished video
                    // (image + narration + burned subtitles).
                    runOnUiThread { ttsStatusText.text = "ပုံ တင်နေတယ်…" }
                    val fileName = imageUri.lastPathSegment ?: "image.jpg"
                    val jobId = client.submitNarrateImage(
                        imageUri, fileName, text, apiKey, option.voice, rate, ttsPitch, mode,
                        ttsEngine, ttsStyle,
                        onUploadProgress = { pct ->
                            runOnUiThread {
                                ttsProgressBar.isIndeterminate = false
                                ttsProgressBar.progress = pct
                                ttsStatusText.text = "ပုံ တင်နေတယ်… $pct%"
                            }
                        }
                    )
                    runOnUiThread {
                        ttsProgressBar.isIndeterminate = true
                        ttsStatusText.text = "Video ထုတ်နေတယ်… (မိနစ် အနည်းငယ် ကြာနိုင်တယ်)"
                    }
                    val state = pollUntilDone(client, jobId, maxWaits = 450)
                    val videoUrl = state.videoUrl
                        ?: throw IOException("Server က Video ပြန်မပေးဘူး။")
                    runOnUiThread { ttsStatusText.text = "Video ပြန်ယူနေတယ်…" }
                    val tmp = File(cacheDir, "narrated-image-${stamp()}.mp4")
                    client.downloadToFile(videoUrl, tmp)
                    ttsLastVideo = tmp
                    ttsLastVideoUrl = videoUrl
                    ttsLastSrt = state.srt?.takeIf { it.isNotBlank() }
                } else if (ttsEngine == "gemini") {
                    // Expressive Gemini TTS (single voice + style).
                    val geminiVoice = if (selectedVoiceIndex == 0) {
                        TtsClient.GEMINI_VOICE_FEMALE
                    } else {
                        TtsClient.GEMINI_VOICE_MALE
                    }
                    val jobId = TtsClient().submitGemini(
                        text, geminiVoice, ttsStyle, apiKey
                    )
                    runOnUiThread { ttsStatusText.text = "Gemini အသံထုတ်နေတယ်…" }
                    val state = pollUntilDone(client, jobId)
                    val audioUrl = state.audioUrl
                        ?: throw IOException("Server က အသံဖိုင် ပြန်မပေးဘူး။")
                    val audio = TtsClient().downloadAudio(audioUrl)
                    ttsLastAudio = audio
                    ttsLastSrt = state.srt?.takeIf { it.isNotBlank() }
                } else {
                    val jobId = TtsClient().submit(text, option.voice, rate, ttsPitch, mode, apiKey)
                    runOnUiThread { ttsStatusText.text = "AI အသံဖတ်ပြနေတယ်…" }
                    val state = pollUntilDone(client, jobId)
                    val audioUrl = state.audioUrl
                        ?: throw IOException("Server က အသံဖိုင် ပြန်မပေးဘူး။")
                    val audio = TtsClient().downloadAudio(audioUrl)
                    // v0.6.2: keep the audio until the user taps download.
                    ttsLastAudio = audio
                    ttsLastSrt = state.srt?.takeIf { it.isNotBlank() }
                }
                runOnUiThread {
                    ttsMakeButton.isEnabled = true
                    ttsProgressBar.isIndeterminate = false
                    ttsProgressBar.progress = 100
                    ttsDownloadButton.text = if (ttsLastVideo != null) {
                        "Video ဒေါင်းလုဒ်လုပ်ရန်"
                    } else {
                        "အသံဖိုင် ဒေါင်းလုပ်လုပ်ရန်"
                    }
                    ttsDownloadButton.visibility = View.VISIBLE
                    val audio = ttsLastAudio
                    if (audio != null) {
                        setupTtsPlayer(audio)
                        ttsStatusText.text =
                            "ပြီးပြီ — ▶ နှိပ်ပြီး အသံနားထောင်ကြည့်ပါ၊ ပြီးရင် ဒေါင်းလုပ်လုပ်ပါ။"
                    } else {
                        ttsStatusText.text =
                            "ပြီးပြီ — ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    ttsMakeButton.isEnabled = true
                    ttsProgressBar.isIndeterminate = false
                    ttsProgressBar.progress = 0
                    ttsStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    /** Prepares the listen-here player for freshly generated audio. */
    private fun setupTtsPlayer(audio: ByteArray) {
        stopTtsPlayer()
        try {
            val file = File(cacheDir, "tts-preview-${stamp()}.mp3")
            file.writeBytes(audio)
            ttsPlayerFile = file
            val mp = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                prepare()
                setOnCompletionListener {
                    ttsPlayButton.text = "▶"
                    ttsSeekBar.progress = 0
                    ttsPlayerHandler.removeCallbacks(ttsPlayerPoller)
                }
            }
            ttsPlayer = mp
            ttsSeekBar.max = mp.duration
            ttsSeekBar.progress = 0
            ttsTimeText.text = "00:00 / ${formatClockUs(mp.duration * 1_000L)}"
            ttsPlayButton.text = "▶"
            ttsPlayerRow.visibility = View.VISIBLE
        } catch (e: Exception) {
            ttsPlayerRow.visibility = View.GONE
        }
    }

    private fun toggleTtsPlayback() {
        val mp = ttsPlayer ?: return
        try {
            if (mp.isPlaying) {
                mp.pause()
                ttsPlayButton.text = "▶"
                ttsPlayerHandler.removeCallbacks(ttsPlayerPoller)
            } else {
                mp.start()
                ttsPlayButton.text = "⏸"
                ttsPlayerHandler.removeCallbacks(ttsPlayerPoller)
                ttsPlayerHandler.post(ttsPlayerPoller)
            }
        } catch (e: Exception) {
        }
    }

    /** Pauses playback when leaving the TTS screen, keeping the
     * player ready so listening can resume on return. */
    private fun pauseTtsPlayer() {
        ttsPlayerHandler.removeCallbacks(ttsPlayerPoller)
        try {
            if (ttsPlayer?.isPlaying == true) ttsPlayer?.pause()
        } catch (e: Exception) {
        }
        if (::ttsPlayButton.isInitialized) ttsPlayButton.text = "▶"
    }

    private fun stopTtsPlayer() {
        ttsPlayerHandler.removeCallbacks(ttsPlayerPoller)
        try {
            ttsPlayer?.stop()
        } catch (e: Exception) {
        }
        try {
            ttsPlayer?.release()
        } catch (e: Exception) {
        }
        ttsPlayer = null
        ttsPlayerFile?.delete()
        ttsPlayerFile = null
    }

    /** Copies the video's audio track into [outFile] (.m4a) without
     * re-encoding, so only a few megabytes go up to the server. */
    @Throws(IOException::class)
    /** v0.10.15: counts audio samples in [file] (up to [maxSamples]).
     * 0 = no audio track, or a declared-but-empty track (the silent-burn
     * failure: Media3 writes the track header but zero samples). Uses
     * the platform extractor — the same one that reads the source fine. */
    private fun audioSampleCount(file: File, maxSamples: Int = 20): Int {
        if (!file.exists() || file.length() <= 0L) return 0
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(file.absolutePath)
            var audioTrack = -1
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME).orEmpty().startsWith("audio/")) {
                    audioTrack = i
                    break
                }
            }
            if (audioTrack < 0) return 0
            extractor.selectTrack(audioTrack)
            val buffer = ByteBuffer.allocate(256 * 1024)
            var count = 0
            while (count < maxSamples) {
                if (extractor.readSampleData(buffer, 0) < 0) break
                count++
                extractor.advance()
            }
            return count
        } catch (e: Exception) {
            return 0
        } finally {
            try { extractor.release() } catch (e: Exception) { }
        }
    }

    /** v0.10.15: if [burned] has no audible audio, rebuild it by muxing
     * the platform-extracted source audio onto the burned video track.
     * Returns the repaired file, or null when the audio was already fine
     * (or the repair is impossible — the original file is kept as-is). */
    private fun maybeRepairAudio(burned: File, srcUri: Uri? = workLastSourceUri, audioOffsetUs: Long = 0L): File? {
        if (audioSampleCount(burned) > 0) return null
        val src = srcUri ?: return null
        try {
            val audioFile = File(cacheDir, "repair-audio-${stamp()}.m4a")
            extractAudioToM4a(src, audioFile)
            if (audioSampleCount(audioFile) <= 0) {
                audioFile.delete()
                return null
            }
            val repaired = File(
                burned.parentFile,
                "zhang-studio-subtitled-${stamp()}-fixed.mp4"
            )
            muxVideoAudio(burned, audioFile, repaired, audioOffsetUs)
            audioFile.delete()
            if (audioSampleCount(repaired) <= 0) {
                repaired.delete()
                return null
            }
            burned.delete()
            return repaired
        } catch (e: Exception) {
            return null
        }
    }

    private fun extractAudioToM4a(videoUri: Uri, outFile: File) {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(this, videoUri, null)
            var audioTrack = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME).orEmpty().startsWith("audio/")) {
                    audioTrack = i
                    format = f
                    break
                }
            }
            if (audioTrack < 0 || format == null) {
                throw IOException("ဒီ Video မှာ အသံ မပါဘူး။ အသံပါတဲ့ Video ရွေးပါ။")
            }
            extractor.selectTrack(audioTrack)
            val muxer = MediaMuxer(
                outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
            )
            try {
                val outTrack = muxer.addTrack(format)
                muxer.start()
                val buffer = ByteBuffer.allocate(512 * 1024)
                val info = MediaCodec.BufferInfo()
                while (true) {
                    val size = extractor.readSampleData(buffer, 0)
                    if (size < 0) break
                    info.set(0, size, extractor.sampleTime, extractor.sampleFlags)
                    muxer.writeSampleData(outTrack, buffer, info)
                    extractor.advance()
                }
                muxer.stop()
            } finally {
                try {
                    muxer.release()
                } catch (e: Exception) {
                }
            }
        } finally {
            extractor.release()
        }
    }

    /** Muxes the original video track + the narration audio into
     * [outFile], copying both tracks without re-encoding. The narration
     * replaces the original audio. Samples are interleaved by timestamp. */
    private fun muxVideoAudio(videoFile: File, audioFile: File, outFile: File, audioOffsetUs: Long = 0L) {
        var rotation = 0
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(videoFile.absolutePath)
            rotation = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION
            )?.toIntOrNull() ?: 0
        } catch (e: Exception) {
        } finally {
            try { retriever.release() } catch (e: Exception) { }
        }
        val muxer = MediaMuxer(
            outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
        )
        if (rotation != 0) muxer.setOrientationHint(rotation)
        val vExtractor = MediaExtractor()
        val aExtractor = MediaExtractor()
        try {
            vExtractor.setDataSource(videoFile.absolutePath)
            var vTrack = -1
            var vFormat: MediaFormat? = null
            for (i in 0 until vExtractor.trackCount) {
                val f = vExtractor.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME).orEmpty().startsWith("video/")) {
                    vTrack = i
                    vFormat = f
                    break
                }
            }
            if (vTrack < 0 || vFormat == null) {
                throw IOException("Video track ရှာမတွေ့ဘူး။")
            }
            vExtractor.selectTrack(vTrack)
            val outVideo = muxer.addTrack(vFormat)
            aExtractor.setDataSource(audioFile.absolutePath)
            var aTrack = -1
            var aFormat: MediaFormat? = null
            for (i in 0 until aExtractor.trackCount) {
                val f = aExtractor.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME).orEmpty().startsWith("audio/")) {
                    aTrack = i
                    aFormat = f
                    break
                }
            }
            if (aTrack < 0 || aFormat == null) {
                throw IOException("အသံ track ရှာမတွေ့ဘူး။")
            }
            aExtractor.selectTrack(aTrack)
            val outAudio = muxer.addTrack(aFormat)
            muxer.start()
            val buffer = ByteBuffer.allocate(2 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            // v0.10.20: negative-first-sampleTime fix (AAC priming /
            // edit lists) — EOS is ONLY readSampleData() < 0, each
            // track shifted to start at 0. audioOffsetUs adds on top.
            var vTime = vExtractor.sampleTime
            var aTime = aExtractor.sampleTime
            var vDone = false
            var aDone = false
            if (vTime < 0L && vExtractor.readSampleData(buffer, 0) < 0) vDone = true
            if (aTime < 0L && aExtractor.readSampleData(buffer, 0) < 0) aDone = true
            val vShift = if (!vDone && vTime < 0L) -vTime else 0L
            val aShift = if (!aDone && aTime < 0L) -aTime else 0L
            while (!vDone || !aDone) {
                if (!vDone && (aDone || vTime + vShift <= aTime + aShift + audioOffsetUs)) {
                    val size = vExtractor.readSampleData(buffer, 0)
                    if (size < 0) {
                        vDone = true
                    } else {
                        info.set(0, size, vTime + vShift, vExtractor.sampleFlags)
                        muxer.writeSampleData(outVideo, buffer, info)
                        vExtractor.advance()
                        vTime = vExtractor.sampleTime
                    }
                } else if (!aDone) {
                    val size = aExtractor.readSampleData(buffer, 0)
                    if (size < 0) {
                        aDone = true
                    } else {
                        info.set(0, size, aTime + aShift + audioOffsetUs, aExtractor.sampleFlags)
                        muxer.writeSampleData(outAudio, buffer, info)
                        aExtractor.advance()
                        aTime = aExtractor.sampleTime
                    }
                }
            }
            muxer.stop()
        } finally {
            try { vExtractor.release() } catch (e: Exception) { }
            try { aExtractor.release() } catch (e: Exception) { }
            try { muxer.release() } catch (e: Exception) { }
        }
    }

    // v0.10.3: link flow — resolve the link on the server (bytes only),
    // download the video directly from the platform CDN on the phone,
    // mux audio when the platform splits it, then set it as the picked
    // video so the normal subtitle flow runs unchanged.
    // v0.10.5: file-safe name from a video title (illegal chars
    // become '_', capped at 30 chars) + the link key, so folder
    // copies are recognisable and never collide between links.
    private fun safeTitleName(title: String?, key: String): String {
        val illegal = setOf('/', '\\', ':', '*', '?', '"', '<', '>', '|')
        val clean = (title ?: "").map { if (it in illegal || it.code < 32) '_' else it }
            .joinToString("").trim().take(30).trimEnd('_', ' ', '.')
        val base = if (clean.isEmpty()) "video" else clean
        return "$base-$key"
    }

    private fun existsInDownloads(name: String, folder: String): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        return try {
            val projection = arrayOf(MediaStore.Downloads._ID)
            val selection = "${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.RELATIVE_PATH}=?"
            contentResolver.query(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI, projection, selection,
                arrayOf(name, "$folder/"), null
            )?.use { it.count > 0 } ?: false
        } catch (e: Exception) {
            false
        }
    }

    // v0.10.12: deletes one exact-named file from a Downloads
    // subfolder. Exact DISPLAY_NAME match only, so only our own
    // file can go — used to drop the raw video once the muxed copy
    // is saved, so the folder holds one file per link, not two.
    private fun deleteFromDownloads(name: String, folder: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        runCatching {
            val projection = arrayOf(MediaStore.Downloads._ID)
            val selection = "${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.RELATIVE_PATH}=?"
            val ids = mutableListOf<Long>()
            contentResolver.query(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI, projection, selection,
                arrayOf(name, "$folder/"), null
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Downloads._ID)
                while (c.moveToNext()) ids.add(c.getLong(idCol))
            }
            for (id in ids) {
                contentResolver.delete(
                    android.content.ContentUris.withAppendedId(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI, id),
                    null, null)
            }
        }
    }

    // v0.10.6: finds an already-saved copy of this video in Zin's
    // link folder — ours (exact name) or another downloader's (the
    // file name starts with the video title). Returns name + Uri, or
    // null. Any miss just falls back to the normal download flow.
    private fun findSavedLinkVideo(title: String?, baseName: String): Pair<String, android.net.Uri>? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return try {
            val projection = arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME)
            val selection = "${MediaStore.Downloads.RELATIVE_PATH}=?"
            val rows = mutableListOf<Pair<String, android.net.Uri>>()
            contentResolver.query(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI, projection, selection,
                arrayOf("$FOLDER_LINK_VIDEOS/"), null
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Downloads._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val name = c.getString(nameCol) ?: continue
                    rows.add(name to android.content.ContentUris.withAppendedId(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI, id))
                }
            }
            if (rows.isEmpty()) return null
            val muxedName = "$baseName-အသံပါ.mp4"
            val rawName = "$baseName.mp4"
            rows.firstOrNull { it.first == muxedName }
                ?: rows.firstOrNull { it.first == rawName }
                ?: run {
                    // v0.10.6: two videos sharing a title prefix must
                    // NOT be guessed between — exactly one match, or
                    // no reuse (the normal download flow runs).
                    val prefix = (title ?: "").trim().take(20)
                    if (prefix.length < 8) null
                    else rows.filter { it.first.startsWith(prefix, ignoreCase = true) }.singleOrNull()
                }
        } catch (e: Exception) {
            null
        }
    }

    // Saves a link-downloaded video into Zin's link folder, once —
    // re-taps must not pile up duplicate copies.
    private fun saveLinkCopy(source: File, displayName: String) {
        runCatching {
            if (!existsInDownloads(displayName, FOLDER_LINK_VIDEOS)) {
                copyToDownloads(source, "video/mp4", FOLDER_LINK_VIDEOS, deleteSource = false, displayName = displayName)
            }
        }
    }

    // v0.10.5: DOWNLOAD FIRST (Zin, 15 Nov 00:20). The video is saved
    // to the phone folder as soon as ITS download finishes — even if
    // the audio download fails afterwards, the video is already in
    // the phone. Stable file names from the link hash give CROSS-TAP
    // resume: re-tapping continues the partial downloads instead of
    // restarting.
    // v0.10.6: REUSE (Zin, 15 Nov 00:55). If the video is already in
    // the phone folder — saved by the app or by another downloader —
    // use the saved file instead of downloading again.
    // Runs on the make flow's background thread; throws on failure.
    // v0.10.13: DORMANT — link input removed from the UI (Zin).
    // Kept so the link flow can return without rewriting.
    private fun fetchLinkVideo(link: String): Uri {
        val client = TranscribeClient(contentResolver)
        val resolved = client.resolveLink(link, apiKey.ifBlank { null })
        // v0.10.10: auto Myanmar title for the top band (link flow).
        workAutoTitle = resolved.titleMm
        resolved.titleMm?.let { workStage("ခေါင်းစဉ် ရပြီ: $it") }
        val key = link.hashCode().toUInt().toString(16)
        val baseName = safeTitleName(resolved.title, key)
        val saved = findSavedLinkVideo(resolved.title, baseName)
        if (saved != null && saved.first == "$baseName-အသံပါ.mp4") {
            // Complete muxed copy from an earlier run — use it as-is.
            // v0.10.12: drop any leftover raw copy from older runs.
            deleteFromDownloads("$baseName.mp4", FOLDER_LINK_VIDEOS)
            val uri = saved.second
            runOnUiThread {
                videoUri = uri
                videoLabel.text = "Video: ${resolved.title ?: saved.first}"
                updateMakeEnabled()
                progressBar.progress = 100
                setStatus("Video ရပြီ")
                workStage("သိမ်းထားတဲ့ video ကို သုံးနေတယ်…")
            }
            return uri
        }
        val videoFile = File(cacheDir, "link-video-$key.mp4")
        val audioFile = File(cacheDir, "link-audio-$key.m4a")
        val muxed = File(cacheDir, "link-muxed-$key.mp4")
        // Drop abandoned partials from other links (and the old
        // stamp-named ones) so the cache does not grow forever.
        cacheDir.listFiles()?.forEach { f ->
            if (f.name.startsWith("link-") && !f.name.contains(key)) {
                runCatching { f.delete() }
            }
        }
        if (saved != null) {
            // Reuse the saved video file — copy it into the stable
            // cache slot, then run the normal flow (audio+mux only
            // if this link serves separate audio).
            val savedInput = contentResolver.openInputStream(saved.second)
                ?: throw IOException("သိမ်းထားတဲ့ video ကို ဖွင့်လို့ မရဘူး။")
            savedInput.use { input ->
                FileOutputStream(videoFile).use { input.copyTo(it) }
            }
            workStage("သိမ်းထားတဲ့ video ကို သုံးနေတယ်…")
        } else {
            if (videoFile.exists() && videoFile.length() > 0) {
                workStage("ဒေါင်းတာ ဆက်လုပ်နေတယ်…")
            } else {
                workStage("Video ဒေါင်းလုဒ်လုပ်နေတယ်…")
            }
            client.downloadToFile(resolved.url, videoFile, resumeNote = true) { pct ->
                runOnUiThread {
                    progressBar.isIndeterminate = false
                    progressBar.progress = pct
                    setStatus("Video ဒေါင်းလုဒ်လုပ်နေတယ်… $pct%")
                }
            }
            // Save FIRST — before the audio step, so a later failure
            // cannot leave the folder empty.
            saveLinkCopy(videoFile, "$baseName.mp4")
            workStage("Video ဖုန်းထဲ သိမ်းပြီးပြီ")
        }
        val finalFile = if (resolved.audioUrl != null) {
            workStage("အသံ တွဲနေတယ်…")
            client.downloadToFile(resolved.audioUrl, audioFile, resumeNote = true)
            muxVideoAudio(videoFile, audioFile, muxed)
            saveLinkCopy(muxed, "$baseName-အသံပါ.mp4")
            // v0.10.12: the muxed copy replaces the raw one — drop
            // the raw so the folder holds one file per link (Zin:
            // videos were piling up 2-3 copies).
            deleteFromDownloads("$baseName.mp4", FOLDER_LINK_VIDEOS)
            audioFile.delete()
            videoFile.delete()
            muxed
        } else {
            videoFile
        }
        val uri = Uri.fromFile(finalFile)
        runOnUiThread {
            videoUri = uri
            videoLabel.text = "Video: ${resolved.title ?: finalFile.name}"
            updateMakeEnabled()
            progressBar.progress = 100
            setStatus("Video ရပြီ")
            workStage("Video ရပြီ")
        }
        return uri
    }

    private fun setPvRunning(running: Boolean) {
        val formVisibility = if (running) View.GONE else View.VISIBLE
        pvInputCard.visibility = formVisibility
        pvHintText.visibility = formVisibility
        if (running) {
            pvImageLabel.visibility = View.GONE
            pvImageRow.visibility = View.GONE
            pvClearImagesButton.visibility = View.GONE
        } else {
            pvImageLabel.visibility = View.VISIBLE
            updatePvImageLabel()
        }
    }

    private fun onPromptVideoClicked() {
        val prompt = pvTextField.text.toString().trim()
        if (prompt.isEmpty()) {
            pvStatusText.text = "Prompt ရိုက်ထည့်ပါ။"
            return
        }
        val imageUris = pvImageUris.toList()
        pvMakeButton.isEnabled = false
        pvDownloadButton.visibility = View.GONE
        setPvRunning(true)
        pvProgressBar.isIndeterminate = true
        pvStatusText.text = "ဇာတ်လမ်း ရေးနေတယ်…"
        Thread {
            try {
                val imageFiles = imageUris.mapIndexed { idx, uri ->
                    copyUriToCache(uri, "pv-image-$idx")
                }
                // Auto mode (server v28+): the AI splits the narration by
                // character and gives each their own voice. The voice sent
                // here is only the fallback if the split fails.
                val jobId = TtsClient().submitPromptVideo(
                    prompt, apiKey, TtsClient.VOICE_NILAR, 0, 0, imageFiles, "auto"
                )
                runOnUiThread {
                    pvStatusText.text = "ပုံထုတ် + အသံထည့် + Video ပေါင်းနေတယ်… (မိနစ် အနည်းငယ် ကြာနိုင်တယ်)"
                }
                val client = TranscribeClient(contentResolver)
                // Prompt-video assembles 3 scenes on the free server, so it
                // may take longer than a transcription: allow ~30 minutes.
                val state = pollUntilDone(client, jobId, maxWaits = 450)
                val videoUrl = state.videoUrl
                    ?: throw IOException("Server က Video ပြန်မပေးဘူး။")
                runOnUiThread { pvStatusText.text = "Video ပြန်ယူနေတယ်…" }
                val tmp = File(cacheDir, "prompt-video-${stamp()}.mp4")
                client.downloadToFile(videoUrl, tmp)
                runOnUiThread {
                    pvMakeButton.isEnabled = true
                    setPvRunning(false)
                    pvProgressBar.isIndeterminate = false
                    pvProgressBar.progress = 100
                    pvLastTmp = tmp
                    pvLastVideoUrl = videoUrl
                    pvLastSrt = state.srt
                    pvDownloadButton.visibility = View.VISIBLE
                    pvStatusText.text = "ပြီးပြီ — ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    pvMakeButton.isEnabled = true
                    setPvRunning(false)
                    pvProgressBar.isIndeterminate = false
                    pvProgressBar.progress = 0
                    pvStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    // v0.6.2: finished files are saved to Downloads only when the user
    // taps the separate download button on each screen.
    private fun onWorkDownloadClicked() {
        val srt = workLastSrt
        val output = workLastOutput
        if (srt == null && output == null) return
        workDownloadButton.isEnabled = false
        setStatus("Download/zhang file ထဲ သိမ်းနေတယ်…")
        Thread {
            try {
                // v0.10.15: guard a second tap after the file is gone
                // (button is disabled after a successful save, but the
                // system can still clear the cache file). v0.14.1: the
                // save keeps the preview file now, so the preview
                // still plays after downloading.
                if (srt == null && (output == null || !output.exists())) {
                    runOnUiThread {
                        workDownloadButton.isEnabled = false
                        setStatus("ဒီ Video သိမ်းပြီးသွားပြီ — Download/zhang file ထဲ ရှိတယ်။")
                    }
                    return@Thread
                }
                val savedName = if (srt != null) {
                    saveSrtToDownloads(srt)
                } else {
                    copyToDownloads(output!!, "video/mp4", FOLDER_TRANSLATED, deleteSource = false)
                }
                runOnUiThread {
                    if (savedName != null) {
                        workDownloadButton.isEnabled = false
                        workDownloadButton.text = "သိမ်းပြီးပြီ"
                        setStatus("ပြီးပြီ — Download/zhang file ထဲ သိမ်းပြီးပြီ:\n$savedName")
                    } else {
                        workDownloadButton.isEnabled = true
                        setStatus("အမှား: သိမ်းလို့ မရဘူး။")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    workDownloadButton.isEnabled = true
                    setStatus("အမှား: ${e.message ?: "unknown error"}")
                }
            }
        }.start()
    }

    private fun onMtvClicked() {
        val imageUri = mtvImageUri
        val song = mtvSongField.text.toString().trim()
        val link = mtvLinkField.text.toString().trim()
        if (imageUri == null) {
            mtvStatusText.text = "လူပုံ အရင် ရွေးပါ။"
            return
        }
        if (song.isEmpty() && link.isEmpty()) {
            mtvStatusText.text = "သီချင်းနာမည် (သို့) Link တစ်ခု ထည့်ပါ။"
            return
        }
        mtvMakeButton.isEnabled = false
        mtvDownloadButton.visibility = View.GONE
        mtvLastVideo = null
        mtvLastVideoUrl = null
        mtvProgressBar.isIndeterminate = true
        mtvStatusText.text = "ပုံ တင်နေတယ်…"
        Thread {
            try {
                val client = TranscribeClient(contentResolver)
                val fileName = imageUri.lastPathSegment ?: "image.jpg"
                val jobId = client.submitMtv(
                    imageUri, fileName, song, link.ifEmpty { null },
                    onUploadProgress = { pct ->
                        runOnUiThread {
                            mtvProgressBar.isIndeterminate = false
                            mtvProgressBar.progress = pct
                            mtvStatusText.text = "ပုံ တင်နေတယ်… $pct%"
                        }
                    }
                )
                runOnUiThread {
                    mtvProgressBar.isIndeterminate = true
                    mtvStatusText.text = "သီချင်းရှာပြီး MTV ထုတ်နေတယ်… (မိနစ် အနည်းငယ် ကြာနိုင်တယ်)"
                }
                val state = pollUntilDone(client, jobId, maxWaits = 450)
                val videoUrl = state.videoUrl
                    ?: throw IOException("Server က Video ပြန်မပေးဘူး။")
                runOnUiThread { mtvStatusText.text = "Video ပြန်ယူနေတယ်…" }
                val tmp = File(cacheDir, "mtv-${stamp()}.mp4")
                client.downloadToFile(videoUrl, tmp)
                mtvLastVideo = tmp
                mtvLastVideoUrl = videoUrl
                val title = state.title?.takeIf { it.isNotBlank() }
                runOnUiThread {
                    mtvMakeButton.isEnabled = true
                    mtvProgressBar.isIndeterminate = false
                    mtvProgressBar.progress = 100
                    mtvDownloadButton.visibility = View.VISIBLE
                    mtvStatusText.text = if (title != null) {
                        "ပြီးပြီ — $title\nဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။"
                    } else {
                        "ပြီးပြီ — ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    mtvMakeButton.isEnabled = true
                    mtvProgressBar.isIndeterminate = false
                    mtvProgressBar.progress = 0
                    mtvStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    private fun onMtvDownloadClicked() {
        val video = mtvLastVideo ?: return
        mtvDownloadButton.isEnabled = false
        mtvStatusText.text = "Download/zhang file ထဲ သိမ်းနေတယ်…"
        Thread {
            try {
                val file = if (video.exists()) {
                    video
                } else {
                    val videoUrl = mtvLastVideoUrl
                        ?: throw IOException("Video ပြန်ယူလို့ မရဘူး။")
                    val fresh = File(cacheDir, "mtv-${stamp()}.mp4")
                    TranscribeClient(contentResolver).downloadToFile(videoUrl, fresh)
                    mtvLastVideo = fresh
                    fresh
                }
                val name = copyToDownloads(file, "video/mp4")
                runOnUiThread {
                    mtvDownloadButton.isEnabled = true
                    mtvStatusText.text = if (name != null) {
                        "ပြီးပြီ — Download/zhang file ထဲ သိမ်းပြီးပြီ:\n$name"
                    } else {
                        "အမှား: သိမ်းလို့ မရဘူး။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    mtvDownloadButton.isEnabled = true
                    mtvStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    private fun onTtsDownloadClicked() {
        val video = ttsLastVideo
        val audio = ttsLastAudio
        if (video == null && audio == null) return
        ttsDownloadButton.isEnabled = false
        ttsStatusText.text = "Download/zhang file ထဲ သိမ်းနေတယ်…"
        Thread {
            try {
                val mainName: String?
                if (video != null) {
                    val file = if (video.exists()) {
                        video
                    } else {
                        val videoUrl = ttsLastVideoUrl
                            ?: throw IOException("Video ပြန်ယူလို့ မရဘူး။")
                        val fresh = File(cacheDir, "narrated-image-${stamp()}.mp4")
                        TranscribeClient(contentResolver).downloadToFile(videoUrl, fresh)
                        ttsLastVideo = fresh
                        fresh
                    }
                    mainName = copyToDownloads(file, "video/mp4")
                } else {
                    mainName = saveBytesToDownloads(
                        audio!!, "zhang-studio-voice-${stamp()}.mp3", "audio/mpeg", FOLDER_TTS_MP3
                    )
                }
                val srtName = ttsLastSrt?.let { saveSrtToDownloads(it) }
                runOnUiThread {
                    ttsDownloadButton.isEnabled = true
                    if (mainName != null) {
                        ttsStatusText.text = "ပြီးပြီ — Download/zhang file ထဲ သိမ်းပြီးပြီ:\n$mainName" +
                            (if (srtName != null) "\n$srtName" else "")
                    } else {
                        ttsStatusText.text = "အမှား: သိမ်းလို့ မရဘူး။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    ttsDownloadButton.isEnabled = true
                    ttsStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    private fun onPvDownloadClicked() {
        val tmp = pvLastTmp
        val videoUrl = pvLastVideoUrl
        if (tmp == null || videoUrl == null) return
        pvDownloadButton.isEnabled = false
        pvStatusText.text = "Video ဒေါင်းလုဒ်လုပ်နေတယ်…"
        Thread {
            try {
                val file = if (tmp.exists()) {
                    tmp
                } else {
                    val fresh = File(cacheDir, "prompt-video-${stamp()}.mp4")
                    TranscribeClient(contentResolver).downloadToFile(videoUrl, fresh)
                    pvLastTmp = fresh
                    fresh
                }
                val savedName = copyToDownloads(file, "video/mp4")
                val srtName = pvLastSrt?.takeIf { it.isNotBlank() }
                    ?.let { saveSrtToDownloads(it) }
                runOnUiThread {
                    pvDownloadButton.isEnabled = true
                    pvStatusText.text = if (savedName != null) {
                        "ပြီးပြီ — Download/zhang file ထဲ သိမ်းပြီးပြီ:\n$savedName" +
                            (if (srtName != null) "\n$srtName" else "")
                    } else {
                        "အမှား: Video သိမ်းလို့ မရဘူး။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    pvDownloadButton.isEnabled = true
                    pvStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    // ---- v0.7.0: VN-style segment editing ----

    /** Pushes the segment models into the timeline views. */
    private fun pollUntilDone(
        client: TranscribeClient,
        jobId: String,
        maxWaits: Int = 150
    ): TranscribeClient.JobState {
        var failures = 0
        var waited = 0
        while (waited < maxWaits) {
            val state = try {
                client.poll(jobId)
            } catch (e: IOException) {
                failures++
                // v0.9.9: 12 x 4s — his connection regularly dies for
                // 30-60s at a time; 5 was giving up too early.
                if (failures > 12) {
                    throw IOException("Server နဲ့ အဆက်ပြတ်သွားတယ်။ ထပ်စမ်းပါ။")
                }
                null
            }
            if (state != null) {
                failures = 0
                when (state.status) {
                    "done" -> return state
                    "error" -> throw IOException(state.error ?: "Server error")
                    // "pending": keep waiting.
                }
            }
            Thread.sleep(4000)
            waited++
        }
        throw IOException("အချိန်ကြာလွန်းတယ်။ ထပ်စမ်းပါ။")
    }

    private fun waitForJob(client: TranscribeClient, jobId: String): String {
        val state = pollUntilDone(client, jobId)
        return state.srt ?: throw IOException("Server returned no subtitles")
    }

    private fun postStatus(text: String) {
        runOnUiThread { setStatus(text) }
    }

    private fun postError(message: String) {
        runOnUiThread {
            setBusy(false)
            setStatus("အမှား: $message")
        }
    }

    /** v0.10.1: stage log for the work screen's အခြေအနေ box — one line
     * per stage, like the web UI's status field. Safe from any thread. */
    private fun workStage(text: String) {
        runOnUiThread {
            if (::workStatusLog.isInitialized) {
                workStatusCard.visibility = View.VISIBLE
                val cur = workStatusLog.text.toString()
                workStatusLog.text = if (cur.isEmpty()) "• $text" else "$cur\n• $text"
            }
        }
    }

    private fun clearWorkStages() {
        runOnUiThread {
            if (::workStatusLog.isInitialized) {
                workStatusLog.text = ""
                workStatusCard.visibility = View.GONE
            }
        }
    }

    private fun titleText(text: String, size: Float): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
    }

    private fun sectionLabel(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 17f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(Color.WHITE)
    }

    private fun hintText(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(Color.rgb(235, 235, 235))
        gravity = Gravity.CENTER
    }

    private fun pillBg(color: Int, strokeColor: Int?, strokeWidthDp: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(30).toFloat()
            setColor(color)
            if (strokeColor != null) setStroke(dp(strokeWidthDp), strokeColor)
        }

    private fun pillButton(text: String, bg: Int, fg: Int, stroke: Int?): Button =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 18f
            setTextColor(fg)
            background = pillBg(bg, stroke, 2)
            setPadding(dp(20), dp(12), dp(20), dp(12))
        }

    // v0.12.0 design (Zin, 15 Nov): glass pills + photo headers/posters.
    private val glassBgColor = Color.rgb(28, 44, 37)
    private val glassStrokeColor = Color.rgb(74, 104, 88)
    private val selectedStrokeColor = Color.rgb(76, 175, 125)

    private fun glassPillBg(strokeColor: Int = glassStrokeColor): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(30).toFloat()
            setColor(glassBgColor)
            setStroke(dp(2), strokeColor)
        }

    private fun selectedPillBg(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(Color.rgb(47, 163, 107), Color.rgb(30, 107, 74))
    ).apply {
        cornerRadius = dp(30).toFloat()
        setStroke(dp(2), selectedStrokeColor)
    }

    private fun glassButton(text: String, stroke: Int = glassStrokeColor): Button =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 18f
            setTextColor(Color.WHITE)
            background = glassPillBg(stroke)
            setPadding(dp(20), dp(12), dp(20), dp(12))
        }

    // Menu/poster photos, decoded once from assets and reused.
    private val photoBitmaps = mutableMapOf<String, Bitmap>()

    private fun photoBitmap(asset: String): Bitmap? {
        photoBitmaps[asset]?.let { return it }
        return try {
            assets.open(asset).use { BitmapFactory.decodeStream(it) }
                ?.also { photoBitmaps[asset] = it }
        } catch (e: Exception) {
            null
        }
    }

    private fun roundedPhotoView(asset: String, heightPx: Int): ImageView =
        ImageView(this).apply {
            photoBitmap(asset)?.let { setImageBitmap(it) }
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, heightPx
            )
            setBackgroundColor(Color.rgb(21, 36, 29))
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(
                        0, 0, view.width, view.height, dp(18).toFloat()
                    )
                }
            }
        }

    // A menu card: rounded photo + title + subtitle, all tappable.
    private fun photoMenuCard(
        asset: String, photoH: Int, title: String, subtitle: String,
        labelGravity: Int, onClick: () -> Unit
    ): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        }
        card.addView(roundedPhotoView(asset, photoH))
        card.addView(TextView(this).apply {
            text = title
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = labelGravity
        }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(10) })
        card.addView(TextView(this).apply {
            text = subtitle
            textSize = 13f
            setTextColor(Color.rgb(165, 178, 170))
            gravity = labelGravity
        })
        return card
    }

    // Sheet column for poster screens: padded content area that sits
    // on the rounded-top sheet overlapping the poster photo.
    private fun sheetColumn(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(24), dp(24), dp(24), dp(24))
        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            val r = dp(24).toFloat()
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            setColor(Color.rgb(13, 26, 21))
        }
        layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    // Poster + sheet scaffold: full-bleed photo with the title on it,
    // the sheet overlapping the photo's bottom edge. The title view
    // is styled here; its text can change later (work screen modes).
    private fun buildPosterSheet(
        photo: String, titleView: TextView, sheet: LinearLayout
    ): ScrollView {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        val poster = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(360)
            )
        }
        poster.addView(ImageView(this).apply {
            photoBitmap(photo)?.let { setImageBitmap(it) }
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.rgb(12, 32, 26))
        })
        poster.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.TRANSPARENT, Color.argb(210, 0, 0, 0))
            )
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(130)
            ).apply { gravity = Gravity.BOTTOM }
        })
        titleView.apply {
            textSize = 24f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.START
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.START
                setMargins(dp(24), 0, dp(24), dp(48))
            }
        }
        poster.addView(titleView)
        outer.addView(poster)
        sheet.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = -dp(30) }
        outer.addView(sheet)
        return ScrollView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            addView(outer)
        }
    }

    private fun menuCard(emoji: String, title: String, subtitle: String, onClick: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(18).toFloat()
                setColor(Color.WHITE)
            }
            setPadding(dp(16), dp(14), dp(16), dp(14))
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        }
        val chip = TextView(this).apply {
            text = emoji
            textSize = 26f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(12).toFloat()
                setColor(Color.rgb(228, 244, 234))
            }
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        row.addView(chip)
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        texts.addView(TextView(this).apply {
            text = title
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.rgb(18, 32, 25))
        })
        texts.addView(TextView(this).apply {
            text = subtitle
            textSize = 13f
            setTextColor(Color.rgb(90, 107, 96))
        })
        row.addView(texts)
        return row
    }

    private fun ctaBg(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(Color.rgb(47, 163, 107), Color.rgb(30, 107, 74))
    ).apply {
        cornerRadius = dp(30).toFloat()
    }

    private fun ctaButton(text: String): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 18f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(Color.WHITE)
        background = ctaBg()
        setPadding(dp(20), dp(12), dp(20), dp(12))
    }

    private fun cardBg(): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(16).toFloat()
        setColor(Color.rgb(28, 44, 37))
        setStroke(dp(2), Color.rgb(74, 104, 88))
    }

    private fun infoCard(text: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = cardBg()
        setPadding(dp(16), dp(14), dp(16), dp(14))
        addView(TextView(context).apply {
            this.text = text
            textSize = 15f
            setTextColor(Color.rgb(220, 235, 225))
            gravity = Gravity.CENTER
        })
    }

    private fun rowParams(topDp: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(topDp) }

    /**
     * Bundled Noto Sans Myanmar (shapes Myanmar correctly with
     * StaticLayout). Falls back to the system default typeface if the
     * asset is missing — most Android devices ship a Myanmar font.
     */
    private fun loadMyanmarTypeface(): Typeface {
        return try {
            // v0.10.9: Bold — Zin: beautiful font, like his promo.
            Typeface.createFromAsset(assets, "NotoSansMyanmar-Bold.ttf")
        } catch (e: Exception) {
            Typeface.DEFAULT
        }
    }

    companion object {
        // All downloads go into a "zhang file" folder inside Downloads,
        // so the app's videos, audio and SRTs stay together in one place.
        // MediaStore creates the subfolder automatically on Android 10+.
        const val DOWNLOADS_FOLDER = "Download/zhang file"
        // v0.10.4: Zin's own 4 subfolders (screenshot, 15 Nov 00:07).
        // Names copied exactly — MediaStore creates them on demand.
        const val FOLDER_LINK_VIDEOS = "Download/zhang file/linkကနေ download လုပ်ထားတဲ့ video"
        const val FOLDER_SRT = "Download/zhang file/video မှ SRT ထုတ်ထားသော စာများ"
        const val FOLDER_TTS_MP3 = "Download/zhang file/စာနဲ့ ai အသံထုတ်ထားသော mp3 များ"
        const val FOLDER_TRANSLATED = "Download/zhang file/ဘာသာပြန်ပြီးသားvideos"
    }

    /**
     * Copies [source] into the public Downloads folder (MediaStore, no
     * storage permission needed for the app's own files on Android 10+).
     * Returns the file name on success, null on failure (or on Android
     * older than 10, where the private path is reported instead). The
     * private temp file is deleted after a successful copy.
     */
    private fun copyToDownloads(source: File, mimeType: String, folder: String = DOWNLOADS_FOLDER, deleteSource: Boolean = true, displayName: String? = null): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, displayName ?: source.name)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, folder)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return null
            contentResolver.openOutputStream(uri)?.use { out ->
                FileInputStream(source).use { it.copyTo(out) }
            } ?: return null
            if (deleteSource) source.delete()
            source.name
        } catch (e: Exception) {
            null
        }
    }

    /** Writes bytes straight into the public Downloads folder. */
    private fun saveBytesToDownloads(bytes: ByteArray, name: String, mimeType: String, folder: String = DOWNLOADS_FOLDER): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, folder)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return null
            contentResolver.openOutputStream(uri)?.use { out ->
                out.write(bytes)
            } ?: return null
            name
        } catch (e: Exception) {
            null
        }
    }

    /** Writes SRT text straight into the public Downloads folder. */
    private fun saveSrtToDownloads(srtText: String): String? {
        return saveBytesToDownloads(
            srtText.toByteArray(Charsets.UTF_8),
            "zhang-studio-${stamp()}.srt",
            "application/x-subrip",
            FOLDER_SRT
        )
    }

    private fun stamp(): String =
        SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())

    /** Copies a picked content Uri to a cache file for upload. */
    @Throws(IOException::class)
    private fun copyUriToCache(uri: Uri, prefix: String): File {
        val tmp = File(cacheDir, "$prefix-${stamp()}.jpg")
        contentResolver.openInputStream(uri)?.use { input ->
            tmp.outputStream().use { output -> input.copyTo(output) }
        } ?: throw IOException("Could not open the image")
        return tmp
    }

    /** Output goes to the app's private Movies folder (no storage permission needed). */
    private fun newOutputFile(): File {
        val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: cacheDir
        if (!dir.exists()) dir.mkdirs()
        return File(dir, "zhang-studio-subtitled-${stamp()}.mp4")
    }

    private fun formatClockUs(timeUs: Long): String {
        val totalSeconds = timeUs / 1_000_000L
        val minutes = totalSeconds / 60L
        val seconds = totalSeconds % 60L
        return "%02d:%02d".format(minutes, seconds)
    }

    /** v0.9.4: MM:SS.cc (demo-style total time). */
    private fun formatClockUsCs(timeUs: Long): String {
        val totalCs = timeUs / 10_000L
        val minutes = totalCs / 6000L
        val seconds = (totalCs % 6000L) / 100L
        val cs = totalCs % 100L
        return "%02d:%02d.%02d".format(minutes, seconds, cs)
    }

    /** v0.9.4: speed label with 1 decimal when exact ("1.0"),
     * else 2 ("1.25") — the demo badge shows "Speed: 1.0x". */
    private fun formatSpeedLabel(speed: Float): String {
        val one = "%.1f".format(speed)
        return if (one.toFloatOrNull() == speed) one else "%.2f".format(speed)
    }

    private fun fmtSeconds(seconds: Double): String {
        return if (seconds == seconds.toInt().toDouble()) {
            seconds.toInt().toString()
        } else {
            "%.1f".format(seconds)
        }
    }

    private fun updateMakeEnabled() {
        makeButton.isEnabled = videoUri != null
    }

    private fun setBusy(busy: Boolean) {
        pickVideoButton.isEnabled = !busy
        makeButton.isEnabled = !busy && videoUri != null
    }

    private fun setStatus(text: String) {
        statusText.text = text
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
