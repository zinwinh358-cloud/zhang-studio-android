package com.zhangstudio.app

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.util.UnstableApi
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Zhang Studio v0.6.21 — seven screens over the studio photo background:
 * 1. Login: Gemini API Key, entered once and remembered. A "Key သွားယူရန်"
 *    link opens the AI Studio key page so new users can get a key.
 * 2. Menu: all six features, all working now.
 * 3. Work (modes 1-2): pick a video -> Gemini SRT -> burn on the phone CPU
 *    (subtitle mode) or SRT alone (SRT mode). Finished files wait for the
 *    separate download button — nothing is saved to Downloads by itself.
 * 4. TTS (mode 3): type text -> AI voice reads it aloud (2 voices + speed
 *    slider, or AI auto mode: Gemini splits the text by character and
 *    assigns male/female voices per part) -> MP3 + SRT on demand, or a
 *    finished video when a character image is picked (image + narration
 *    + burned subtitles). Style picker: plain edge-tts voice, or
 *    expressive Gemini TTS (natural / spooky ghost-story style).
 *    Server: POST /api/tts, POST /api/gemini-tts, POST /api/narrate-image.
 * 5. Voiceover (mode 4): pick a video -> server transcribes/translates it,
 *    narrates it in Myanmar (manual voice or AI auto split), and muxes the
 *    voice into the video -> finished MP4 + SRT on demand.
 *    Server: POST /api/voiceover (v16+, auto mode v20+).
 * 6. Timing (mode 5): CapCut-style timeline editor — preview on
 *    top, ruler + video strip + music track + SRT track on one time
 *    axis, tools in a bottom toolbar. Shift subtitle timing
 *    (-10s..+10s), trim, cut out a middle section, speed, background
 *    music, title text -> burn on the phone CPU, or save the SRT alone.
 * 7. Prompt-video (mode 6): chat-style "Video generation" screen —
 *    type a prompt in the bottom box -> 3-scene video with Myanmar
 *    narration + subtitles, on demand. Server: POST /api/prompt-video.
 *
 * Server jobs are polled (async), so slow connections never hit a single
 * long request that times out. A sync (v13) transcribe server still works.
 * All errors surface as status text — the app never crashes on bad input.
 * Rotating the phone during a burn cancels the export.
 */
@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {

    private val modeSubtitle = 1
    private val modeSrt = 2
    private val modeTts = 3
    private val modeVoiceover = 4
    private val modeTiming = 5
    private val modePromptVideo = 6
    private var mode = modeSubtitle

    private var videoUri: Uri? = null
    private var voVideoUri: Uri? = null
    private var timingVideoUri: Uri? = null
    private var timingCues: List<SubtitleCue> = emptyList()
    private var timingShiftUs: Long = 0L
    private var timingBusy: Boolean = false
    private var burner: SubtitleBurner? = null
    private var timingBurner: SubtitleBurner? = null
    private var apiKey: String = ""

    // Two real Myanmar edge-tts voices (Nilar = female, Thiha = male).
    // Auto mode (v0.6.3): AI splits the text by character instead.
    private data class VoiceOption(val label: String, val voice: String)
    private val voiceOptions = listOf(
        VoiceOption("မိန်းကလေး အသံ", TtsClient.VOICE_NILAR),
        VoiceOption("ယောက်ျားလေး အသံ", TtsClient.VOICE_THIHA)
    )
    private var selectedVoiceIndex = 0
    private val voiceOptionButtons = mutableListOf<Pair<Button, Int>>()
    private var autoVoice = false
    private val autoVoiceButtons = mutableListOf<Button>()
    // Narration style (v0.6.5): "edge" = plain edge-tts voice; "gemini" =
    // expressive Gemini TTS with a style direction. Gemini and the auto
    // character split exclude each other (Gemini is single-voice).
    private var ttsEngine: String = "edge"
    private var ttsStyle: String = "natural"
    private val styleButtons = mutableListOf<Pair<Button, String>>()
    private var ttsRate: Int = 0

    private val prefs by lazy { getSharedPreferences("zhang_studio", MODE_PRIVATE) }

    private lateinit var loginScreen: View
    private lateinit var menuScreen: View
    private lateinit var workScreen: View
    private lateinit var ttsScreen: View
    private lateinit var voiceoverScreen: View
    private lateinit var timingScreen: View
    private lateinit var promptVideoScreen: View
    private lateinit var keyField: EditText
    private lateinit var loginStatus: TextView
    private lateinit var workTitle: TextView
    private lateinit var pickVideoButton: Button
    private lateinit var videoLabel: TextView
    private lateinit var makeButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var workDownloadButton: Button
    private var workLastOutput: File? = null
    private var workLastSrt: String? = null
    private lateinit var ttsTextField: EditText
    private lateinit var ttsRateLabel: TextView
    private lateinit var ttsMakeButton: Button
    private lateinit var ttsProgressBar: ProgressBar
    private lateinit var ttsStatusText: TextView
    private lateinit var ttsDownloadButton: Button
    private var ttsLastAudio: ByteArray? = null
    private var ttsLastSrt: String? = null
    // v0.6.20: listen to the generated voice here before downloading.
    private lateinit var ttsPlayerRow: LinearLayout
    private lateinit var ttsPlayButton: Button
    private lateinit var ttsSeekBar: SeekBar
    private lateinit var ttsTimeText: TextView
    private var ttsPlayer: MediaPlayer? = null
    private var ttsPlayerFile: File? = null
    private val ttsPlayerHandler = Handler(Looper.getMainLooper())
    private val ttsPlayerPoller = object : Runnable {
        override fun run() {
            val mp = ttsPlayer ?: return
            if (!::ttsSeekBar.isInitialized) return
            try {
                if (mp.isPlaying) {
                    ttsSeekBar.progress = mp.currentPosition
                    ttsTimeText.text =
                        "${formatClockUs(mp.currentPosition * 1_000L)} / ${formatClockUs(mp.duration * 1_000L)}"
                    ttsPlayerHandler.postDelayed(this, 250L)
                } else {
                    ttsPlayButton.text = "▶"
                }
            } catch (e: Exception) {
            }
        }
    }
    private var ttsImageUri: Uri? = null
    private lateinit var ttsImageButton: Button
    private lateinit var ttsImageLabel: TextView
    private var ttsLastVideo: File? = null
    private var ttsLastVideoUrl: String? = null
    private lateinit var voPickButton: Button
    private lateinit var voVideoLabel: TextView
    private lateinit var voMakeButton: Button
    private lateinit var voProgressBar: ProgressBar
    private lateinit var voStatusText: TextView
    private lateinit var voDownloadButton: Button
    private lateinit var voSrtDownloadButton: Button
    private lateinit var voScrollView: ScrollView
    private var voLastTmp: File? = null
    private var voLastVideoUrl: String? = null
    private var voLastSrt: String? = null
    // v0.6.8: preview the finished voiceover video + SRT before downloading.
    // v0.6.21: the SRT text shows full-height on the page (no nested
    // scroll box), and Video / SRT download as separate buttons.
    private lateinit var voPreviewVideo: VideoView
    private lateinit var voSrtText: TextView
    private lateinit var timingPickVideoButton: Button
    private lateinit var timingVideoLabel: TextView
    private lateinit var timingPickSrtButton: Button
    private lateinit var timingSrtLabel: TextView
    private lateinit var timingShiftLabel: TextView
    private lateinit var timingInfoText: TextView
    // v0.6.13 editor slice 1: preview + live cue text + trim.
    // v0.6.14: title text shown over the preview and burned at the top.
    // v0.6.18: timeline editor — ruler + video strip + music track
    // share one time axis; tools live in a bottom toolbar.
    private lateinit var timingPreviewFrame: FrameLayout
    private lateinit var timingPreviewVideo: VideoView
    private lateinit var timingTopTextPreview: TextView
    private lateinit var timingCueText: TextView
    private lateinit var timingSrtTrackRow: LinearLayout
    private lateinit var timingSrtTrack: SrtTrackView
    private lateinit var timingRuler: TimeRulerView
    private lateinit var timingVideoStrip: VideoStripView
    private lateinit var timingMusicTrack: MusicTrackView
    private lateinit var timingPlayButton: Button
    private lateinit var timingTimeText: TextView
    private lateinit var timingChangeVideoButton: Button
    private val timingToolPanels = mutableListOf<View>()
    private val timingToolButtons = mutableListOf<View>()
    private lateinit var timingTrimStartField: EditText
    private lateinit var timingTrimEndField: EditText
    private lateinit var timingTopTextField: EditText
    // v0.6.16 editor slice 2: cut-out, speed, background music.
    private lateinit var timingCutStartField: EditText
    private lateinit var timingCutEndField: EditText
    private var timingSpeed: Float = 1f
    private val timingSpeedButtons = mutableListOf<Pair<Button, Float>>()
    private var timingMusicUri: Uri? = null
    private lateinit var timingMusicLabel: TextView
    private lateinit var timingMusicClearButton: Button
    private lateinit var timingMuteCheck: CheckBox
    private var timingVideoDurationMs: Long = 0L
    private var timingVideoBaseLabel: String = ""
    private val timingPreviewHandler = Handler(Looper.getMainLooper())
    private val timingPreviewPoller = object : Runnable {
        override fun run() {
            if (!::timingPreviewVideo.isInitialized) return
            if (::timingScreen.isInitialized &&
                timingScreen.visibility == View.VISIBLE
            ) {
                val posMs = timingPreviewVideo.currentPosition.toLong()
                val posUs = posMs * 1_000L
                val cues = SrtParser.shifted(timingCues, timingShiftUs)
                val active = cues.firstOrNull { posUs in it.startUs until it.endUs }
                timingCueText.text = active?.text.orEmpty()
                if (::timingSrtTrack.isInitialized) {
                    timingSrtTrack.setPosition(posMs)
                }
                if (::timingVideoStrip.isInitialized) {
                    timingVideoStrip.setPosition(posMs)
                }
                if (::timingMusicTrack.isInitialized) {
                    timingMusicTrack.setPosition(posMs)
                }
                if (::timingTimeText.isInitialized) {
                    timingTimeText.text =
                        "${formatClockUs(posUs)} / ${formatClockUs(timingVideoDurationMs * 1_000L)}"
                }
                if (::timingPlayButton.isInitialized) {
                    timingPlayButton.text =
                        if (timingPreviewVideo.isPlaying) "⏸" else "▶"
                }
                timingPreviewHandler.postDelayed(this, 250L)
            }
        }
    }
    private lateinit var timingBurnButton: Button
    private lateinit var timingSaveSrtButton: Button
    private lateinit var timingProgressBar: ProgressBar
    private lateinit var timingStatusText: TextView
    private lateinit var timingDownloadButton: Button
    private var timingLastOutput: File? = null
    private lateinit var pvTextField: EditText
    private lateinit var pvHintText: TextView
    private lateinit var pvInputCard: LinearLayout
    private lateinit var pvPickImageButton: Button
    private lateinit var pvClearImagesButton: Button
    private lateinit var pvImageLabel: TextView
    private lateinit var pvImageRow: LinearLayout
    private val pvImageUris = mutableListOf<Uri>()
    private lateinit var pvMakeButton: Button
    private lateinit var pvProgressBar: ProgressBar
    private lateinit var pvStatusText: TextView
    private lateinit var pvDownloadButton: Button
    private var pvLastTmp: File? = null
    private var pvLastVideoUrl: String? = null
    private var pvLastSrt: String? = null

    private val pickVideoLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                videoUri = uri
                videoLabel.text = "Video: ${uri.lastPathSegment ?: uri}"
                updateMakeEnabled()
            }
        }

    private val pickVoVideoLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                voVideoUri = uri
                voVideoLabel.text = "Video: ${uri.lastPathSegment ?: uri}"
                voMakeButton.isEnabled = true
            }
        }

    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                ttsImageUri = uri
                ttsImageLabel.text = "ပုံ: ${uri.lastPathSegment ?: uri}"
            }
        }

    private val pickPvImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null && pvImageUris.size < 3) {
                pvImageUris.add(uri)
                updatePvImageLabel()
            }
        }

    private fun updatePvImageLabel() {
        val n = pvImageUris.size
        pvImageLabel.text = if (n == 0) {
            "ပုံ မထည့်ရသေးဘူး — ပုံမထည့်ရင် AI က ပုံထုတ်ပေးမယ်"
        } else {
            "ပုံ $n ပုံ ထည့်ပြီးပြီ" + if (n < 3) " — နောက် ပုံ ထပ်ထည့်လို့ရတယ်" else ""
        }
        pvPickImageButton.isEnabled = n < 3
        pvClearImagesButton.visibility = if (n == 0) View.GONE else View.VISIBLE
        // v0.6.10: show the picked images as thumbnails together with the
        // text, so each added image is visible (not just a count).
        // v0.6.12: each thumbnail carries a small X — tapping it removes
        // just that image.
        pvImageRow.removeAllViews()
        for ((index, uri) in pvImageUris.withIndex()) {
            val thumb = ImageView(this).apply {
                setImageURI(uri)
                scaleType = ImageView.ScaleType.CENTER_CROP
                layoutParams = FrameLayout.LayoutParams(dp(72), dp(72))
            }
            val cross = TextView(this).apply {
                text = "✕"
                textSize = 13f
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.argb(160, 0, 0, 0))
                setPadding(dp(5), dp(1), dp(5), dp(1))
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { gravity = Gravity.TOP or Gravity.END }
                setOnClickListener {
                    pvImageUris.removeAt(index)
                    updatePvImageLabel()
                }
            }
            val frame = FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(72), dp(72)).apply {
                    marginEnd = dp(8)
                }
                addView(thumb)
                addView(cross)
            }
            pvImageRow.addView(frame)
        }
        pvImageRow.visibility = if (n == 0) View.GONE else View.VISIBLE
    }

    private val pickTimingVideoLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                timingVideoUri = uri
                timingVideoBaseLabel = "Video: ${uri.lastPathSegment ?: uri}"
                timingVideoLabel.text = timingVideoBaseLabel
                timingPreviewVideo.setVideoURI(uri)
                timingPreviewVideo.setMediaController(
                    MediaController(this).apply { setAnchorView(timingPreviewVideo) }
                )
                timingPreviewVideo.setOnPreparedListener { mp ->
                    timingVideoDurationMs = mp.duration.toLong()
                    val secs = mp.duration / 1000
                    timingVideoLabel.text = "$timingVideoBaseLabel — $secs စက္ကန့်"
                    timingSrtTrack.setDuration(mp.duration.toLong())
                    timingRuler.setDuration(mp.duration.toLong())
                    timingMusicTrack.setDuration(mp.duration.toLong())
                    timingVideoStrip.setVideo(uri, mp.duration.toLong())
                    timingPreviewHandler.removeCallbacks(timingPreviewPoller)
                    timingPreviewHandler.post(timingPreviewPoller)
                }
                timingPickVideoButton.visibility = View.GONE
                updateTimingEnabled()
            }
        }

    private val pickMusicLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                timingMusicUri = uri
                timingMusicLabel.text = "သီချင်း: ${uri.lastPathSegment ?: uri}"
                timingMusicClearButton.visibility = View.VISIBLE
                timingMusicTrack.setMusic("${uri.lastPathSegment ?: uri}")
            }
        }

    private val pickSrtLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri == null) return@registerForActivityResult
            try {
                val text = contentResolver.openInputStream(uri)?.use {
                    it.readBytes().toString(Charsets.UTF_8)
                } ?: ""
                val cues = SrtParser.parse(text)
                if (cues.isEmpty()) {
                    timingCues = emptyList()
                    timingSrtLabel.text = "SRT ဖိုင်မှာ စာတန်း မတွေ့ဘူး။"
                } else {
                    timingCues = cues
                    timingSrtLabel.text = "SRT: စာတန်း ${cues.size} ပိုင်း"
                }
            } catch (e: Exception) {
                timingCues = emptyList()
                timingSrtLabel.text = "SRT ဖတ်လို့ မရဘူး။"
            }
            updateTimingInfo()
            updateTimingEnabled()
        }

    private val burnCallback = object : SubtitleBurner.Callback {
        override fun onProgress(percent: Int) {
            progressBar.progress = percent
            setStatus("စာတန်းထည့်နေတယ်… $percent%")
        }

        override fun onCompleted(outputPath: String) {
            // v0.6.2: no auto-download — the finished file waits until
            // the user taps the separate download button.
            workLastOutput = File(outputPath)
            workLastSrt = null
            runOnUiThread {
                setBusy(false)
                progressBar.progress = 100
                workDownloadButton.text = "Video ဒေါင်းလုဒ်လုပ်ရန်"
                workDownloadButton.visibility = View.VISIBLE
                setStatus("ပြီးပြီ — ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။")
            }
        }

        override fun onError(message: String) {
            setBusy(false)
            setStatus("အမှား: $message")
        }
    }

    private val timingBurnCallback = object : SubtitleBurner.Callback {
        override fun onProgress(percent: Int) {
            timingProgressBar.progress = percent
            timingStatusText.text = "စာတန်းထည့်နေတယ်… $percent%"
        }

        override fun onCompleted(outputPath: String) {
            // v0.6.2: no auto-download — the finished file waits until
            // the user taps the separate download button.
            timingLastOutput = File(outputPath)
            runOnUiThread {
                timingBusy = false
                updateTimingEnabled()
                timingProgressBar.progress = 100
                timingDownloadButton.visibility = View.VISIBLE
                timingStatusText.text = "ပြီးပြီ — ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။"
            }
        }

        override fun onError(message: String) {
            timingBusy = false
            updateTimingEnabled()
            timingStatusText.text = "အမှား: $message"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        apiKey = prefs.getString("gemini_api_key", "").orEmpty()

        val root = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.rgb(17, 20, 24))
        }

        // Studio photo background + dark overlay for readable text.
        try {
            val bmp = assets.open("studio_bg.jpg").use { BitmapFactory.decodeStream(it) }
            if (bmp != null) {
                root.addView(ImageView(this).apply {
                    setImageBitmap(bmp)
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                })
            }
        } catch (e: Exception) {
            // No background image: the dark solid color stays.
        }
        root.addView(View(this).apply {
            setBackgroundColor(Color.argb(110, 0, 0, 0))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        })

        loginScreen = buildLoginScreen()
        menuScreen = buildMenuScreen()
        workScreen = buildWorkScreen()
        ttsScreen = buildTtsScreen()
        voiceoverScreen = buildVoiceoverScreen()
        timingScreen = buildTimingScreen()
        promptVideoScreen = buildPromptVideoScreen()
        root.addView(loginScreen)
        root.addView(menuScreen)
        root.addView(workScreen)
        root.addView(ttsScreen)
        root.addView(voiceoverScreen)
        root.addView(timingScreen)
        root.addView(promptVideoScreen)
        setContentView(root)

        if (apiKey.isBlank()) showScreen(loginScreen) else showScreen(menuScreen)
    }

    override fun onDestroy() {
        burner?.cancel()
        burner = null
        timingBurner?.cancel()
        timingBurner = null
        stopTtsPlayer()
        super.onDestroy()
    }

    // ---------- screens ----------

    private fun showScreen(screen: View) {
        // Stop the voiceover preview when leaving that screen, so its
        // audio never keeps playing over another screen.
        if (screen !== voiceoverScreen && ::voPreviewVideo.isInitialized) {
            voPreviewVideo.stopPlayback()
        }
        // Pause the TTS listen-here player when leaving that screen.
        if (screen !== ttsScreen) {
            pauseTtsPlayer()
        }
        // Same for the timing-screen preview + its cue poller.
        if (screen !== timingScreen && ::timingPreviewVideo.isInitialized) {
            timingPreviewVideo.stopPlayback()
            timingPreviewHandler.removeCallbacks(timingPreviewPoller)
        }
        // Returning to the editor restarts the playhead poller.
        if (screen === timingScreen && ::timingPreviewVideo.isInitialized &&
            timingVideoUri != null
        ) {
            timingPreviewHandler.removeCallbacks(timingPreviewPoller)
            timingPreviewHandler.post(timingPreviewPoller)
        }
        loginScreen.visibility = if (screen === loginScreen) View.VISIBLE else View.GONE
        menuScreen.visibility = if (screen === menuScreen) View.VISIBLE else View.GONE
        workScreen.visibility = if (screen === workScreen) View.VISIBLE else View.GONE
        ttsScreen.visibility = if (screen === ttsScreen) View.VISIBLE else View.GONE
        voiceoverScreen.visibility =
            if (screen === voiceoverScreen) View.VISIBLE else View.GONE
        timingScreen.visibility = if (screen === timingScreen) View.VISIBLE else View.GONE
        promptVideoScreen.visibility =
            if (screen === promptVideoScreen) View.VISIBLE else View.GONE
    }

    private fun screenColumn(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val pad = dp(24)
        setPadding(pad, dp(48), pad, pad)
        layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    private fun wrapScroll(column: LinearLayout): ScrollView = ScrollView(this).apply {
        layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        addView(column)
    }

    private fun buildLoginScreen(): View {
        val col = screenColumn()
        col.addView(titleText("ZHANG Studio", 32f))
        col.addView(titleText("မှ ကြိုဆိုပါတယ်", 26f))

        val banner = TextView(this).apply {
            text = "Gemini API Key ထည့်ပြီး\nစတင် အသုံးပြုနိုင်ပါပြီ"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = pillBg(Color.rgb(13, 84, 96), Color.rgb(72, 199, 214), 2)
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        col.addView(banner, rowParams(dp(40)))

        keyField = EditText(this).apply {
            hint = "API Key"
            textSize = 18f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            setSingleLine(true)
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(22), dp(14), dp(22), dp(14))
            if (apiKey.isNotBlank()) setText(apiKey)
        }
        col.addView(keyField, rowParams(dp(24)))

        val loginButton = pillButton("Login", Color.rgb(35, 35, 35), Color.WHITE, null)
        loginButton.setOnClickListener { onLoginClicked() }
        col.addView(loginButton, rowParams(dp(16)))

        loginStatus = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.rgb(255, 213, 74))
            gravity = Gravity.CENTER
        }
        col.addView(loginStatus, rowParams(dp(12)))

        // "Go get a Key" link: new users who don't know what a key is can
        // tap it and land straight on the free AI Studio key page.
        val keyLink = TextView(this).apply {
            text = "🔑 Key သွားယူရန်"
            textSize = 17f
            setTextColor(Color.rgb(255, 213, 74))
            gravity = Gravity.CENTER
            paint.isUnderlineText = true
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        keyLink.setOnClickListener {
            try {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://aistudio.google.com/apikey")
                    )
                )
            } catch (e: Exception) {
                loginStatus.text = "Link ဖွင့်လို့ မရဘူး။"
            }
        }
        col.addView(keyLink, rowParams(dp(8)))

        col.addView(hintText("Key ကို aistudio.google.com/apikey မှာ အခမဲ့ ရယူနိုင်ပါတယ်"),
            rowParams(dp(12)))
        return wrapScroll(col)
    }

    private fun buildMenuScreen(): View {
        val col = screenColumn()
        col.addView(titleText("ZHANG Studio", 30f))
        col.addView(titleText("လုပ်ဆောင်ချက်များ ရွေးချယ်ပါ", 20f))

        val green = Color.rgb(30, 107, 74)
        val greenStroke = Color.rgb(76, 175, 125)
        val items = listOf(
            "SRT သီးသန့်ထုတ်ရန်" to modeSrt,
            "Video ကို မြန်မာစာတန်းထိုးပေးရန်" to modeSubtitle,
            "ရေးထားသောစာများကို\nAI အသံဖြင့် ဖတ်ပြရန်" to modeTts,
            "Video များကို မြန်မာအသံဖြင့်\nပြောပြပေးရန်" to modeVoiceover,
            "SRT နှင့် Video တွဲရန် နှင့်\nစာသား အတိုအရှည် စိတ်ကြိုက်ချိန်ရန်" to modeTiming,
            "Prompt ရေးပြီး Video ထုတ်ရန်" to modePromptVideo
        )
        for ((label, targetMode) in items) {
            val b = pillButton(label, Color.WHITE, green, greenStroke)
            b.setOnClickListener {
                when (targetMode) {
                    modeSrt, modeSubtitle -> openWork(targetMode)
                    modeTts -> showScreen(ttsScreen)
                    modeVoiceover -> showScreen(voiceoverScreen)
                    modeTiming -> showScreen(timingScreen)
                    modePromptVideo -> showScreen(promptVideoScreen)
                }
            }
            col.addView(b, rowParams(dp(18)))
        }

        val changeKey = TextView(this).apply {
            text = "API Key ပြောင်းရန်"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        changeKey.setOnClickListener {
            keyField.setText(apiKey)
            loginStatus.text = ""
            showScreen(loginScreen)
        }
        col.addView(changeKey, rowParams(dp(18)))
        return wrapScroll(col)
    }

    private fun buildWorkScreen(): View {
        val col = screenColumn()
        workTitle = titleText("", 22f)
        col.addView(workTitle)

        pickVideoButton = pillButton("Video ရွေးပါ", Color.WHITE, Color.BLACK, null)
        pickVideoButton.setOnClickListener { pickVideoLauncher.launch("video/*") }
        col.addView(pickVideoButton, rowParams(dp(24)))

        videoLabel = TextView(this).apply {
            text = "Video မရွေးရသေးဘူး"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(videoLabel, rowParams(dp(12)))

        makeButton = pillButton("", Color.rgb(13, 84, 96), Color.WHITE, Color.rgb(72, 199, 214))
        makeButton.isEnabled = false
        makeButton.setOnClickListener { onMakeClicked() }
        col.addView(makeButton, rowParams(dp(12)))

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        col.addView(progressBar, rowParams(dp(16)))

        statusText = TextView(this).apply {
            text = "Video ရွေးပါ။"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(statusText, rowParams(dp(8)))

        workDownloadButton = pillButton("Video ဒေါင်းလုဒ်လုပ်ရန်", Color.WHITE, Color.BLACK, null)
        workDownloadButton.visibility = View.GONE
        workDownloadButton.setOnClickListener { onWorkDownloadClicked() }
        col.addView(workDownloadButton, rowParams(dp(12)))

        col.addView(backLink(), rowParams(dp(16)))
        return wrapScroll(col)
    }

    private fun buildTtsScreen(): View {
        val col = screenColumn()
        col.addView(titleText("စာကို AI အသံဖြင့် ဖတ်ပြရန်", 22f))

        ttsTextField = EditText(this).apply {
            hint = "ဖတ်ပြစေချင်တဲ့ မြန်မာစာသား ဒီမှာ ရိုက်ထည့်ပါ..."
            textSize = 17f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 6
            gravity = Gravity.TOP
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(22), dp(14), dp(22), dp(14))
        }
        col.addView(ttsTextField, rowParams(dp(24)))

        ttsImageButton = pillButton("ဇာတ်ကောင်ပုံ ရွေးပါ", Color.WHITE, Color.BLACK, null)
        ttsImageButton.setOnClickListener { pickImageLauncher.launch("image/*") }
        col.addView(ttsImageButton, rowParams(dp(12)))

        ttsImageLabel = TextView(this).apply {
            text = "ပုံ မရွေးရသေးဘူး (ပုံ မထည့်ရင် အသံသီးသန့် ထွက်မယ်)"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(ttsImageLabel, rowParams(dp(8)))

        col.addView(sectionLabel("အသံ ရွေးပါ"), rowParams(dp(20)))
        col.addView(buildVoicePicker(true), rowParams(dp(8)))

        col.addView(sectionLabel("အသံ ပုံစံ"), rowParams(dp(20)))
        col.addView(buildStylePicker(), rowParams(dp(8)))

        ttsRateLabel = TextView(this).apply {
            text = "အမြန်နှုန်း: ပုံမှန်"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(ttsRateLabel, rowParams(dp(20)))
        val rateBar = SeekBar(this).apply { max = 20; progress = 10 }
        rateBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                ttsRate = (progress - 10) * 5
                ttsRateLabel.text = when {
                    ttsRate == 0 -> "အမြန်နှုန်း: ပုံမှန်"
                    ttsRate > 0 -> "အမြန်နှုန်း: +$ttsRate% မြန်"
                    else -> "အမြန်နှုန်း: $ttsRate% နှေး"
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        col.addView(rateBar, rowParams(dp(4)))

        ttsMakeButton = pillButton(
            "အသံထုတ်မယ်", Color.rgb(13, 84, 96), Color.WHITE, Color.rgb(72, 199, 214)
        )
        ttsMakeButton.setOnClickListener { onTtsClicked() }
        col.addView(ttsMakeButton, rowParams(dp(16)))

        ttsProgressBar =
            ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = 0
            }
        col.addView(ttsProgressBar, rowParams(dp(16)))

        // v0.6.20: listen to the generated voice here (play/pause +
        // seek + time) before downloading anything.
        ttsPlayerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
        }
        ttsPlayButton = Button(this).apply {
            text = "▶"
            textSize = 18f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = pillBg(Color.rgb(13, 84, 96), Color.rgb(72, 199, 214), 2)
            setPadding(dp(16), dp(6), dp(16), dp(6))
            setOnClickListener { toggleTtsPlayback() }
        }
        ttsPlayerRow.addView(ttsPlayButton)
        ttsSeekBar = SeekBar(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            )
        }
        ttsSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    try {
                        ttsPlayer?.seekTo(progress)
                    } catch (e: Exception) {
                    }
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        ttsPlayerRow.addView(ttsSeekBar)
        ttsTimeText = TextView(this).apply {
            text = "00:00 / 00:00"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(dp(8), 0, 0, 0)
        }
        ttsPlayerRow.addView(ttsTimeText)
        col.addView(ttsPlayerRow, rowParams(dp(8)))

        ttsStatusText = TextView(this).apply {
            text = "စာသား ရိုက်ထည့်ပြီး အသံထုတ်ပါ။ (စာသား အရှည် ၁၅၀၀၀ လုံးထိ ရတယ်)"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(ttsStatusText, rowParams(dp(8)))

        ttsDownloadButton = pillButton("အသံဖိုင် ဒေါင်းလုပ်လုပ်ရန်", Color.WHITE, Color.BLACK, null)
        ttsDownloadButton.visibility = View.GONE
        ttsDownloadButton.setOnClickListener { onTtsDownloadClicked() }
        col.addView(ttsDownloadButton, rowParams(dp(12)))

        col.addView(backLink(), rowParams(dp(16)))
        return wrapScroll(col)
    }

    private fun buildVoiceoverScreen(): View {
        val col = screenColumn()
        col.addView(titleText("Video ကို မြန်မာအသံဖြင့် ပြောပြရန်", 22f))

        col.addView(
            hintText("Video ရဲ့ အသံကို မြန်မာလို ပြောင်းပြီး AI အသံကို Video ထဲမှာ ထည့်ပေးမယ်။ ပြီးရင် ဒေါင်းလုဒ်ခလုတ် နှိပ်မှ Download/zhang file ထဲ သိမ်းမယ်။"),
            rowParams(dp(16))
        )

        voPickButton = pillButton("Video ရွေးပါ", Color.WHITE, Color.BLACK, null)
        voPickButton.setOnClickListener { pickVoVideoLauncher.launch("video/*") }
        col.addView(voPickButton, rowParams(dp(20)))

        voVideoLabel = TextView(this).apply {
            text = "Video မရွေးရသေးဘူး"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(voVideoLabel, rowParams(dp(12)))

        col.addView(sectionLabel("အသံ ရွေးပါ"), rowParams(dp(16)))
        col.addView(buildVoicePicker(true), rowParams(dp(8)))

        voMakeButton = pillButton(
            "မြန်မာအသံထုတ်မယ်", Color.rgb(13, 84, 96), Color.WHITE, Color.rgb(72, 199, 214)
        )
        voMakeButton.isEnabled = false
        voMakeButton.setOnClickListener { onVoiceoverClicked() }
        col.addView(voMakeButton, rowParams(dp(16)))

        voProgressBar =
            ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = 0
            }
        col.addView(voProgressBar, rowParams(dp(16)))

        voStatusText = TextView(this).apply {
            text = "Video ရွေးပါ။"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        col.addView(voStatusText, rowParams(dp(8)))

        // v0.6.8: preview the finished video + SRT before downloading.
        voPreviewVideo = VideoView(this).apply {
            visibility = View.GONE
        }
        col.addView(
            voPreviewVideo,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(300)
            ).apply { topMargin = dp(12) }
        )

        voSrtText = TextView(this).apply {
            text = ""
            textSize = 14f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(120, 0, 0, 0))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            visibility = View.GONE
        }
        col.addView(voSrtText, rowParams(dp(12)))

        // v0.6.21: separate downloads — the user picks Video or SRT.
        voDownloadButton = pillButton(
            "Video ဒေါင်းလုဒ်လုပ်ရန်", Color.WHITE, Color.BLACK, null
        )
        voDownloadButton.visibility = View.GONE
        voDownloadButton.setOnClickListener { onVoVideoDownloadClicked() }
        col.addView(voDownloadButton, rowParams(dp(12)))

        voSrtDownloadButton = pillButton(
            "SRT ဒေါင်းလုဒ်လုပ်ရန်", Color.WHITE, Color.BLACK, null
        )
        voSrtDownloadButton.visibility = View.GONE
        voSrtDownloadButton.setOnClickListener { onVoSrtDownloadClicked() }
        col.addView(voSrtDownloadButton, rowParams(dp(12)))

        col.addView(backLink(), rowParams(dp(16)))
        voScrollView = wrapScroll(col)
        return voScrollView
    }

    // v0.6.19: prompt-video is now a chat-style "Video generation"
    // screen like the reference Zin sent — back + title on top, an
    // open middle area, and the prompt box pinned to the bottom
    // with a + button for scene images and a send button.
    private fun buildPromptVideoScreen(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(12))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // Header: back + title.
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val back = TextView(this).apply {
            text = "←"
            textSize = 24f
            setTextColor(Color.WHITE)
            setPadding(dp(4), dp(4), dp(16), dp(4))
            setOnClickListener { showScreen(menuScreen) }
        }
        header.addView(back)
        header.addView(titleText("Video generation", 22f).apply {
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            )
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
        })
        root.addView(
            header,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        // Middle area: hint, picked images, status, progress, download.
        val middleScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            ).apply { topMargin = dp(8) }
        }
        val middle = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        middleScroll.addView(middle)
        root.addView(middleScroll)

        pvHintText = TextView(this).apply {
            text = "ဥပမာ — ရွာက ကြောင်လေးတစ်ကောင် ဈေးထဲမှာ ငါးခိုးစားတဲ့ ဇာတ်လမ်း"
            textSize = 14f
            setTextColor(Color.rgb(180, 180, 180))
            gravity = Gravity.CENTER
        }
        middle.addView(pvHintText, rowParams(dp(16)))

        // v0.6.9: up to 3 scene images (server v26+); thumbnails
        // with a small X each (v0.6.10/v0.6.12).
        pvImageLabel = TextView(this).apply {
            text = "ပုံ မထည့်ရသေးဘူး — ပုံမထည့်ရင် AI က ပုံထုတ်ပေးမယ်"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        middle.addView(pvImageLabel, rowParams(dp(12)))
        pvImageRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_HORIZONTAL
            visibility = View.GONE
        }
        middle.addView(pvImageRow, rowParams(dp(4)))
        pvClearImagesButton = pillButton("ပုံတွေ ဖျက်မယ်", Color.WHITE, Color.BLACK, null)
        pvClearImagesButton.visibility = View.GONE
        pvClearImagesButton.setOnClickListener {
            pvImageUris.clear()
            updatePvImageLabel()
        }
        middle.addView(pvClearImagesButton, rowParams(dp(8)))

        pvStatusText = TextView(this).apply {
            text = "Prompt ရိုက်ထည့်ပြီး Video ထုတ်ပါ။"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        middle.addView(pvStatusText, rowParams(dp(16)))
        pvProgressBar =
            ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = 0
            }
        middle.addView(pvProgressBar, rowParams(dp(8)))
        pvDownloadButton = pillButton(
            "Video ဒေါင်းလုဒ်လုပ်ရန်", Color.WHITE, Color.BLACK, null
        )
        pvDownloadButton.visibility = View.GONE
        pvDownloadButton.setOnClickListener { onPvDownloadClicked() }
        middle.addView(pvDownloadButton, rowParams(dp(12)))

        // Bottom input card: prompt field + image button + send.
        pvInputCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(24).toFloat()
                setColor(Color.rgb(35, 35, 35))
            }
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        pvTextField = EditText(this).apply {
            hint = "ဒီနေ့ ဘာ Video လုပ်မလဲ?"
            textSize = 17f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(150, 150, 150))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 2
            maxLines = 5
            gravity = Gravity.TOP
            background = null
            setPadding(0, dp(4), 0, dp(4))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        pvInputCard.addView(pvTextField)
        val cardRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        pvPickImageButton = pillButton("+", Color.rgb(60, 60, 60), Color.WHITE, null).apply {
            textSize = 22f
            setPadding(dp(18), dp(2), dp(18), dp(2))
            setOnClickListener { pickPvImageLauncher.launch("image/*") }
        }
        cardRow.addView(pvPickImageButton)
        cardRow.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                0, 1, 1f
            )
        })
        // v0.6.12: no voice picker on this screen — the server (v28+)
        // assigns each character their own voice automatically.
        pvMakeButton = pillButton(
            "➤", Color.rgb(13, 84, 96), Color.WHITE, Color.rgb(72, 199, 214)
        ).apply {
            textSize = 20f
            setPadding(dp(18), dp(2), dp(18), dp(2))
            setOnClickListener { onPromptVideoClicked() }
        }
        cardRow.addView(pvMakeButton)
        pvInputCard.addView(
            cardRow,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) }
        )
        root.addView(
            pvInputCard,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        )
        return root
    }

    // v0.6.18: the timing screen is now a CapCut-style timeline
    // editor — preview on top, ruler + video strip + music track +
    // SRT track on one shared time axis, tools in a bottom toolbar
    // with one panel open at a time. All editor functions are
    // unchanged; only the layout moved.
    private fun buildTimingScreen(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(12))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // Header: back + title.
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val back = TextView(this).apply {
            text = "← Menu"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(dp(4), dp(8), dp(12), dp(8))
            setOnClickListener { showScreen(menuScreen) }
        }
        header.addView(back)
        header.addView(titleText("Video Editor", 22f).apply {
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            )
            gravity = Gravity.CENTER
        })
        header.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(56), 1)
        })
        root.addView(
            header,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        // Preview: video + title text overlay + pick button (shown
        // only until a video is picked).
        timingPreviewFrame = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }
        timingPreviewVideo = VideoView(this)
        timingPreviewFrame.addView(
            timingPreviewVideo,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        timingTopTextPreview = TextView(this).apply {
            text = ""
            textSize = 18f
            setTextColor(Color.WHITE)
            setShadowLayer(6f, 0f, 2f, Color.BLACK)
            gravity = Gravity.CENTER
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply { topMargin = dp(16) }
        }
        timingPreviewFrame.addView(timingTopTextPreview)
        timingPickVideoButton = pillButton("Video ရွေးပါ", Color.WHITE, Color.BLACK, null).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
            setOnClickListener { pickTimingVideoLauncher.launch("video/*") }
        }
        timingPreviewFrame.addView(timingPickVideoButton)
        root.addView(
            timingPreviewFrame,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(300)
            ).apply { topMargin = dp(8) }
        )

        // Live subtitle line under the preview.
        timingCueText = TextView(this).apply {
            text = ""
            textSize = 16f
            minHeight = dp(40)
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(120, 0, 0, 0))
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        root.addView(timingCueText, rowParams(dp(8)))

        // Transport: play/pause + time + video name.
        val transport = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        timingPlayButton = Button(this).apply {
            text = "▶"
            textSize = 18f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = pillBg(Color.rgb(13, 84, 96), Color.rgb(72, 199, 214), 2)
            setPadding(dp(16), dp(6), dp(16), dp(6))
            setOnClickListener {
                if (timingVideoUri == null) return@setOnClickListener
                if (timingPreviewVideo.isPlaying) timingPreviewVideo.pause()
                else timingPreviewVideo.start()
            }
        }
        transport.addView(timingPlayButton)
        timingTimeText = TextView(this).apply {
            text = "00:00 / 00:00"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
        }
        transport.addView(timingTimeText)
        timingVideoLabel = TextView(this).apply {
            text = "Video မရွေးရသေးဘူး"
            textSize = 14f
            setTextColor(Color.rgb(235, 235, 235))
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, 1f
            )
        }
        transport.addView(timingVideoLabel)
        root.addView(transport, rowParams(dp(8)))

        // Timeline deck: ruler + video strip + music track + SRT
        // track. All rows share the same label width, so the
        // playheads line up vertically.
        val deck = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(170, 0, 0, 0))
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val rulerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        rulerRow.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(36), 1)
        })
        timingRuler = TimeRulerView(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, dp(20), 1f)
        }
        rulerRow.addView(timingRuler)
        deck.addView(
            rulerRow,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        val videoRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        videoRow.addView(trackLabel("🎬"))
        timingVideoStrip = VideoStripView(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f)
            onSeekTo = { ms -> timingPreviewVideo.seekTo(ms) }
        }
        videoRow.addView(timingVideoStrip)
        deck.addView(videoRow, rowParams(dp(4)))
        val musicRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        musicRow.addView(trackLabel("🎵"))
        timingMusicTrack = MusicTrackView(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f)
            onSeekTo = { ms -> timingPreviewVideo.seekTo(ms) }
            onAddMusic = { pickMusicLauncher.launch("audio/*") }
        }
        musicRow.addView(timingMusicTrack)
        deck.addView(musicRow, rowParams(dp(4)))
        timingSrtTrackRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val srtTrackLabel = TextView(this).apply {
            text = "SRT"
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                dp(36), ViewGroup.LayoutParams.MATCH_PARENT
            )
            setOnClickListener { pickSrtLauncher.launch("*/*") }
        }
        timingSrtTrackRow.addView(srtTrackLabel)
        timingSrtTrack = SrtTrackView(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f)
            onSeekTo = { ms -> timingPreviewVideo.seekTo(ms) }
        }
        timingSrtTrackRow.addView(timingSrtTrack)
        deck.addView(timingSrtTrackRow, rowParams(dp(4)))
        root.addView(deck, rowParams(dp(8)))

        // Panel area: one tool panel visible at a time.
        val panelScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            ).apply { topMargin = dp(8) }
        }
        val panelBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        panelBox.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        panelScroll.addView(panelBox)
        root.addView(panelScroll)

        // Video panel: pick / change the video.
        val videoPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        videoPanel.addView(
            hintText("Video ကို ရွေးပါ — ပြီးရင် Track တွေပေါ်မှာ နှိပ်ပြီး အချိန်ကို ရွှေ့ကြည့်နိုင်တယ်။"),
            rowParams(0)
        )
        timingChangeVideoButton = pillButton("Video ပြောင်းမယ်", Color.WHITE, Color.BLACK, null)
        timingChangeVideoButton.setOnClickListener { pickTimingVideoLauncher.launch("video/*") }
        videoPanel.addView(timingChangeVideoButton, rowParams(dp(12)))
        panelBox.addView(videoPanel, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        timingToolPanels.add(videoPanel)

        // Subtitle panel: SRT file + shift slider + info.
        val subtitlePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        timingPickSrtButton = pillButton("SRT ဖိုင်ရွေးပါ", Color.WHITE, Color.BLACK, null)
        timingPickSrtButton.setOnClickListener { pickSrtLauncher.launch("*/*") }
        subtitlePanel.addView(timingPickSrtButton, rowParams(0))
        timingSrtLabel = TextView(this).apply {
            text = "SRT မရွေးရသေးဘူး"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        subtitlePanel.addView(timingSrtLabel, rowParams(dp(12)))
        timingShiftLabel = TextView(this).apply {
            text = "စာတန်း အချိန်: ပုံမှန် (မရွှေ့ဘူး)"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        subtitlePanel.addView(timingShiftLabel, rowParams(dp(20)))
        val shiftBar = SeekBar(this).apply { max = 40; progress = 20 }
        shiftBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val seconds = (progress - 20) * 0.5
                timingShiftUs = (seconds * 1_000_000).toLong()
                timingShiftLabel.text = when {
                    seconds == 0.0 -> "စာတန်း အချိန်: ပုံမှန် (မရွှေ့ဘူး)"
                    seconds > 0 -> "စာတန်း အချိန်: +${fmtSeconds(seconds)} စက္ကန့် နောက်ကျ"
                    else -> "စာတန်း အချိန်: ${fmtSeconds(seconds)} စက္ကန့် စော"
                }
                updateTimingInfo()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        subtitlePanel.addView(shiftBar, rowParams(dp(4)))
        timingInfoText = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.rgb(255, 213, 74))
        }
        subtitlePanel.addView(timingInfoText, rowParams(dp(8)))
        panelBox.addView(subtitlePanel, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        timingToolPanels.add(subtitlePanel)

        // Trim panel: keep only the video between start and end
        // seconds (blank end = to the end). Subtitles are cut and
        // rebased to match the trimmed video.
        val trimPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        trimPanel.addView(sectionLabel("Video ဖြတ်ရန် (စက္ကန့်)"), rowParams(0))
        val trimRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        timingTrimStartField = EditText(this).apply {
            hint = "အစ (0)"
            textSize = 16f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
        }
        trimRow.addView(timingTrimStartField)
        timingTrimEndField = EditText(this).apply {
            hint = "အဆုံး (အကုန်လုံး)"
            textSize = 16f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        trimRow.addView(timingTrimEndField)
        trimPanel.addView(trimRow, rowParams(dp(4)))
        panelBox.addView(trimPanel, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        timingToolPanels.add(trimPanel)

        // Cut-out panel: remove a middle section (on the trimmed
        // timeline). Blank = no cut. The video joins across it.
        val cutPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        cutPanel.addView(sectionLabel("အလယ်က ဖြတ်ထုတ်ရန် (စက္ကန့်)"), rowParams(0))
        val cutRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        timingCutStartField = EditText(this).apply {
            hint = "အစ"
            textSize = 16f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
        }
        cutRow.addView(timingCutStartField)
        timingCutEndField = EditText(this).apply {
            hint = "အဆုံး"
            textSize = 16f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        cutRow.addView(timingCutEndField)
        cutPanel.addView(cutRow, rowParams(dp(4)))
        panelBox.addView(cutPanel, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        timingToolPanels.add(cutPanel)

        // Speed panel: 4 presets.
        val speedPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        speedPanel.addView(sectionLabel("အမြန်နှုန်း"), rowParams(0))
        val speedRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        for ((label, speed) in listOf("0.5x" to 0.5f, "1x" to 1f, "1.5x" to 1.5f, "2x" to 2f)) {
            val button = pillButton(label, Color.WHITE, Color.BLACK, null).apply {
                textSize = 16f
                layoutParams = LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
                ).apply { marginEnd = dp(8) }
                setOnClickListener {
                    timingSpeed = speed
                    refreshSpeedButtons()
                }
            }
            timingSpeedButtons.add(button to speed)
            speedRow.addView(button)
        }
        speedPanel.addView(speedRow, rowParams(dp(4)))
        refreshSpeedButtons()
        panelBox.addView(speedPanel, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        timingToolPanels.add(speedPanel)

        // Music panel: background music (loops) + mute original.
        val musicPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        musicPanel.addView(sectionLabel("နောက်ခံ သီချင်း"), rowParams(0))
        val musicPickButton = pillButton("သီချင်း ရွေးပါ", Color.WHITE, Color.BLACK, null)
        musicPickButton.setOnClickListener { pickMusicLauncher.launch("audio/*") }
        musicPanel.addView(musicPickButton, rowParams(dp(4)))
        timingMusicLabel = TextView(this).apply {
            text = "သီချင်း မရွေးရသေးဘူး"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        musicPanel.addView(timingMusicLabel, rowParams(dp(8)))
        timingMusicClearButton = pillButton("သီချင်း ဖျက်မယ်", Color.WHITE, Color.BLACK, null)
        timingMusicClearButton.visibility = View.GONE
        timingMusicClearButton.setOnClickListener {
            timingMusicUri = null
            timingMusicLabel.text = "သီချင်း မရွေးရသေးဘူး"
            timingMusicClearButton.visibility = View.GONE
            timingMusicTrack.clearMusic()
        }
        musicPanel.addView(timingMusicClearButton, rowParams(dp(4)))
        timingMuteCheck = CheckBox(this).apply {
            text = "မူရင်းအသံ ပိတ်မယ် (သီချင်းပဲ ထားမယ်)"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        musicPanel.addView(timingMuteCheck, rowParams(dp(4)))
        panelBox.addView(musicPanel, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        timingToolPanels.add(musicPanel)

        // Text panel: title text shown at the top of the preview
        // and burned at the top of the exported video.
        val textPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        textPanel.addView(sectionLabel("Video ပေါ်မှာ ပြမယ့် စာ"), rowParams(0))
        timingTopTextField = EditText(this).apply {
            hint = "မထည့်လည်း ရတယ်"
            textSize = 16f
            setTextColor(Color.BLACK)
            setHintTextColor(Color.rgb(130, 130, 130))
            inputType = InputType.TYPE_CLASS_TEXT
            background = pillBg(Color.WHITE, null, 0)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(
                    s: CharSequence?, start: Int, count: Int, after: Int
                ) {
                }

                override fun onTextChanged(
                    s: CharSequence?, start: Int, before: Int, count: Int
                ) {
                }

                override fun afterTextChanged(s: Editable?) {
                    val text = s?.toString().orEmpty()
                    timingTopTextPreview.text = text
                    timingTopTextPreview.visibility =
                        if (text.isBlank()) View.GONE else View.VISIBLE
                }
            })
        }
        textPanel.addView(timingTopTextField, rowParams(dp(4)))
        panelBox.addView(textPanel, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        timingToolPanels.add(textPanel)

        // Export panel: burn + SRT save + progress + download.
        val exportPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        timingBurnButton = pillButton(
            "Video လုပ်မယ်", Color.rgb(13, 84, 96), Color.WHITE, Color.rgb(72, 199, 214)
        )
        timingBurnButton.isEnabled = false
        timingBurnButton.setOnClickListener { onTimingBurnClicked() }
        exportPanel.addView(timingBurnButton, rowParams(0))
        timingSaveSrtButton = pillButton("SRT သီးသန့်သိမ်းမယ်", Color.WHITE, Color.BLACK, null)
        timingSaveSrtButton.isEnabled = false
        timingSaveSrtButton.setOnClickListener { onTimingSaveSrtClicked() }
        exportPanel.addView(timingSaveSrtButton, rowParams(dp(12)))
        timingProgressBar =
            ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = 0
            }
        exportPanel.addView(timingProgressBar, rowParams(dp(16)))
        timingStatusText = TextView(this).apply {
            text = "Video နဲ့ SRT ရွေးပါ။"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        exportPanel.addView(timingStatusText, rowParams(dp(8)))
        timingDownloadButton = pillButton("Video ဒေါင်းလုဒ်လုပ်ရန်", Color.WHITE, Color.BLACK, null)
        timingDownloadButton.visibility = View.GONE
        timingDownloadButton.setOnClickListener { onTimingDownloadClicked() }
        exportPanel.addView(timingDownloadButton, rowParams(dp(12)))
        panelBox.addView(exportPanel, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        timingToolPanels.add(exportPanel)

        // Bottom toolbar: one button per panel.
        val toolbarScroll = HorizontalScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
            isHorizontalScrollBarEnabled = false
        }
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        toolbarScroll.addView(toolbar)
        root.addView(toolbarScroll)
        for ((icon, label, panel) in listOf(
            Triple("🎬", "Video", videoPanel),
            Triple("💬", "စာတန်း", subtitlePanel),
            Triple("✂️", "ဖြတ်ရန်", trimPanel),
            Triple("✄", "အလယ်ဖြတ်", cutPanel),
            Triple("⏩", "အမြန်နှုန်း", speedPanel),
            Triple("🎵", "သီချင်း", musicPanel),
            Triple("🔤", "စာသား", textPanel),
            Triple("⬆️", "ထုတ်မယ်", exportPanel)
        )) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(8), dp(14), dp(8))
                isClickable = true
                isFocusable = true
            }
            cell.addView(TextView(this).apply {
                text = icon
                textSize = 20f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
            })
            cell.addView(TextView(this).apply {
                text = label
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
            })
            cell.tag = panel
            cell.setOnClickListener { showTimingPanel(panel) }
            timingToolButtons.add(cell)
            toolbar.addView(cell)
        }

        showTimingPanel(subtitlePanel)
        return root
    }

    /** Shows one editor tool panel and highlights its toolbar button. */
    private fun showTimingPanel(panel: View) {
        for (p in timingToolPanels) {
            p.visibility = if (p === panel) View.VISIBLE else View.GONE
        }
        for (b in timingToolButtons) {
            b.background = if (b.tag === panel) {
                pillBg(Color.rgb(13, 84, 96), Color.rgb(72, 199, 214), 2)
            } else {
                null
            }
        }
    }

    /** The small fixed-width label at the left of a timeline track. */
    private fun trackLabel(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 16f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        layoutParams = LinearLayout.LayoutParams(
            dp(36), ViewGroup.LayoutParams.MATCH_PARENT
        )
    }

    /** The 4 voice-option buttons; shared selection state across screens. */
    /** Voice picker shared by the TTS and voiceover screens.
     * The auto button (AI splits voices by character) is offered on both;
     * prompt-video always uses auto mode (server v28+) with no picker. */
    private fun buildVoicePicker(showAuto: Boolean): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (showAuto) {
            val auto = pillButton(
                "AI က ဇာတ်ကောင် အလိုက် ခွဲပေးမယ်", Color.WHITE, Color.BLACK, null
            )
            auto.textSize = 16f
            auto.setOnClickListener {
                autoVoice = true
                // Auto split is edge-only; a Gemini style would not apply.
                ttsEngine = "edge"
                ttsStyle = "natural"
                refreshStyleButtons()
                refreshVoiceButtons()
            }
            autoVoiceButtons.add(auto)
            box.addView(auto, rowParams(0))
        }
        for ((index, option) in voiceOptions.withIndex()) {
            val b = pillButton(option.label, Color.WHITE, Color.BLACK, null)
            b.textSize = 16f
            b.setOnClickListener {
                selectedVoiceIndex = index
                autoVoice = false
                refreshVoiceButtons()
            }
            voiceOptionButtons.add(b to index)
            box.addView(b, rowParams(dp(10)))
        }
        refreshVoiceButtons()
        return box
    }

    private fun refreshVoiceButtons() {
        for (button in autoVoiceButtons) {
            button.background = pillBg(
                if (autoVoice) Color.rgb(13, 84, 96) else Color.WHITE,
                if (autoVoice) Color.rgb(72, 199, 214) else null,
                2
            )
            button.setTextColor(if (autoVoice) Color.WHITE else Color.BLACK)
        }
        for ((button, index) in voiceOptionButtons) {
            val selected = !autoVoice && index == selectedVoiceIndex
            button.background = pillBg(
                if (selected) Color.rgb(13, 84, 96) else Color.WHITE,
                if (selected) Color.rgb(72, 199, 214) else null,
                2
            )
            button.setTextColor(if (selected) Color.WHITE else Color.BLACK)
        }
    }

    /** Narration style picker (TTS screen only, v0.6.5). */
    private fun buildStylePicker(): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val styles = listOf(
            "edge" to "ပုံမှန် အသံ",
            "natural" to "သဘာဝ အသံနိမ့်အမြင့်",
            "spooky" to "သရဲ ဇာတ်လမ်း အသံ"
        )
        for ((key, label) in styles) {
            val b = pillButton(label, Color.WHITE, Color.BLACK, null)
            b.textSize = 16f
            b.setOnClickListener {
                if (key == "edge") {
                    ttsEngine = "edge"
                    ttsStyle = "natural"
                } else {
                    ttsEngine = "gemini"
                    ttsStyle = key
                    // Gemini is single-voice; the auto split is edge-only.
                    autoVoice = false
                    refreshVoiceButtons()
                }
                refreshStyleButtons()
            }
            styleButtons.add(b to key)
            box.addView(b, rowParams(dp(10)))
        }
        refreshStyleButtons()
        return box
    }

    private fun refreshStyleButtons() {
        val current = if (ttsEngine == "edge") "edge" else ttsStyle
        for ((button, key) in styleButtons) {
            val selected = key == current
            button.background = pillBg(
                if (selected) Color.rgb(13, 84, 96) else Color.WHITE,
                if (selected) Color.rgb(72, 199, 214) else null,
                2
            )
            button.setTextColor(if (selected) Color.WHITE else Color.BLACK)
        }
    }

    private fun backLink(): TextView = TextView(this).apply {
        text = "← Menu သို့ ပြန်သွားမယ်"
        textSize = 15f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(12), dp(12), dp(12))
        setOnClickListener { showScreen(menuScreen) }
    }

    // ---------- actions ----------

    private fun onLoginClicked() {
        val key = keyField.text.toString().trim()
        if (key.isEmpty()) {
            loginStatus.text = "API Key ထည့်ပါ။"
            return
        }
        // Hide the keyboard: it used to stay open over the menu screen.
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(keyField.windowToken, 0)
        apiKey = key
        prefs.edit().putString("gemini_api_key", key).apply()
        loginStatus.text = ""
        showScreen(menuScreen)
    }

    private fun openWork(targetMode: Int) {
        mode = targetMode
        if (mode == modeSrt) {
            workTitle.text = "SRT သီးသန့်ထုတ်ရန်"
            makeButton.text = "SRT ထုတ်မယ်"
        } else {
            workTitle.text = "Video ကို မြန်မာစာတန်းထိုးပေးရန်"
            makeButton.text = "စာတန်းထိုးထားသော Video လုပ်မယ်"
        }
        setStatus("Video ရွေးပါ။")
        progressBar.progress = 0
        updateMakeEnabled()
        showScreen(workScreen)
    }

    private fun onMakeClicked() {
        val video = videoUri ?: return
        setBusy(true)
        progressBar.progress = 0
        workDownloadButton.visibility = View.GONE
        workLastOutput = null
        workLastSrt = null
        setStatus("Video တင်နေတယ်…")
        Thread {
            try {
                val fileName = video.lastPathSegment ?: "video.mp4"
                val client = TranscribeClient(contentResolver)
                val srtText = when (val res = client.submit(video, fileName, apiKey) { pct ->
                    runOnUiThread {
                        progressBar.isIndeterminate = false
                        progressBar.progress = pct
                        setStatus("Video တင်နေတယ်… $pct%")
                    }
                }) {
                    is TranscribeClient.SubmitResult.Ready -> res.srt
                    is TranscribeClient.SubmitResult.Job -> {
                        runOnUiThread { progressBar.isIndeterminate = true }
                        postStatus("Gemini က အသံနားထောင်နေတယ်… (၁-၃ မိနစ် ကြာနိုင်တယ်)")
                        waitForJob(client, res.jobId)
                    }
                }
                val cues = SrtParser.parse(srtText)
                if (cues.isEmpty()) {
                    postError("ဒီ Video မှာ အသံမတွေ့ဘူး။")
                    return@Thread
                }
                if (mode == modeSrt) {
                    // v0.6.2: SRT waits for the download button too.
                    workLastSrt = srtText
                    runOnUiThread {
                        setBusy(false)
                        progressBar.progress = 100
                        workDownloadButton.text = "SRT ဒေါင်းလုဒ်လုပ်ရန်"
                        workDownloadButton.visibility = View.VISIBLE
                        setStatus("ပြီးပြီ — ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။")
                    }
                    return@Thread
                }
                // Transformer must start on the main thread.
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    try {
                        val typeface = loadMyanmarTypeface()
                        val outputFile = newOutputFile()
                        val newBurner = SubtitleBurner(this)
                        burner = newBurner
                        progressBar.isIndeterminate = false
                        setStatus("စာတန်းထည့်နေတယ်… 0%")
                        newBurner.start(video, cues, typeface, outputFile, burnCallback)
                    } catch (e: Exception) {
                        setBusy(false)
                        setStatus("အမှား: ${e.message ?: "unknown error"}")
                    }
                }
            } catch (e: Exception) {
                postError(e.message ?: "unknown error")
            }
        }.start()
    }

    private fun onTtsClicked() {
        val text = ttsTextField.text.toString().trim()
        if (text.isEmpty()) {
            ttsStatusText.text = "စာသား ရိုက်ထည့်ပါ။"
            return
        }
        val option = voiceOptions[selectedVoiceIndex]
        val rate = ttsRate
        val mode = if (autoVoice) "auto" else "manual"
        val imageUri = ttsImageUri
        ttsMakeButton.isEnabled = false
        ttsDownloadButton.visibility = View.GONE
        stopTtsPlayer()
        ttsPlayerRow.visibility = View.GONE
        ttsLastAudio = null
        ttsLastSrt = null
        ttsLastVideo = null
        ttsLastVideoUrl = null
        ttsProgressBar.isIndeterminate = true
        ttsStatusText.text = "အသံထုတ်နေတယ်…"
        Thread {
            try {
                val client = TranscribeClient(contentResolver)
                if (imageUri != null) {
                    // Image picked: the server builds a finished video
                    // (image + narration + burned subtitles).
                    runOnUiThread { ttsStatusText.text = "ပုံ တင်နေတယ်…" }
                    val fileName = imageUri.lastPathSegment ?: "image.jpg"
                    val jobId = client.submitNarrateImage(
                        imageUri, fileName, text, apiKey, option.voice, rate, 0, mode,
                        ttsEngine, ttsStyle,
                        onUploadProgress = { pct ->
                            runOnUiThread {
                                ttsProgressBar.isIndeterminate = false
                                ttsProgressBar.progress = pct
                                ttsStatusText.text = "ပုံ တင်နေတယ်… $pct%"
                            }
                        }
                    )
                    runOnUiThread {
                        ttsProgressBar.isIndeterminate = true
                        ttsStatusText.text = "Video ထုတ်နေတယ်… (မိနစ် အနည်းငယ် ကြာနိုင်တယ်)"
                    }
                    val state = pollUntilDone(client, jobId, maxWaits = 450)
                    val videoUrl = state.videoUrl
                        ?: throw IOException("Server က Video ပြန်မပေးဘူး။")
                    runOnUiThread { ttsStatusText.text = "Video ပြန်ယူနေတယ်…" }
                    val tmp = File(cacheDir, "narrated-image-${stamp()}.mp4")
                    client.downloadToFile(videoUrl, tmp)
                    ttsLastVideo = tmp
                    ttsLastVideoUrl = videoUrl
                    ttsLastSrt = state.srt?.takeIf { it.isNotBlank() }
                } else if (ttsEngine == "gemini") {
                    // Expressive Gemini TTS (single voice + style).
                    val geminiVoice = if (selectedVoiceIndex == 0) {
                        TtsClient.GEMINI_VOICE_FEMALE
                    } else {
                        TtsClient.GEMINI_VOICE_MALE
                    }
                    val jobId = TtsClient().submitGemini(
                        text, geminiVoice, ttsStyle, apiKey
                    )
                    runOnUiThread { ttsStatusText.text = "Gemini အသံထုတ်နေတယ်…" }
                    val state = pollUntilDone(client, jobId)
                    val audioUrl = state.audioUrl
                        ?: throw IOException("Server က အသံဖိုင် ပြန်မပေးဘူး။")
                    val audio = TtsClient().downloadAudio(audioUrl)
                    ttsLastAudio = audio
                    ttsLastSrt = state.srt?.takeIf { it.isNotBlank() }
                } else {
                    val jobId = TtsClient().submit(text, option.voice, rate, 0, mode, apiKey)
                    runOnUiThread { ttsStatusText.text = "AI အသံဖတ်ပြနေတယ်…" }
                    val state = pollUntilDone(client, jobId)
                    val audioUrl = state.audioUrl
                        ?: throw IOException("Server က အသံဖိုင် ပြန်မပေးဘူး။")
                    val audio = TtsClient().downloadAudio(audioUrl)
                    // v0.6.2: keep the audio until the user taps download.
                    ttsLastAudio = audio
                    ttsLastSrt = state.srt?.takeIf { it.isNotBlank() }
                }
                runOnUiThread {
                    ttsMakeButton.isEnabled = true
                    ttsProgressBar.isIndeterminate = false
                    ttsProgressBar.progress = 100
                    ttsDownloadButton.text = if (ttsLastVideo != null) {
                        "Video ဒေါင်းလုဒ်လုပ်ရန်"
                    } else {
                        "အသံဖိုင် ဒေါင်းလုပ်လုပ်ရန်"
                    }
                    ttsDownloadButton.visibility = View.VISIBLE
                    val audio = ttsLastAudio
                    if (audio != null) {
                        setupTtsPlayer(audio)
                        ttsStatusText.text =
                            "ပြီးပြီ — ▶ နှိပ်ပြီး အသံနားထောင်ကြည့်ပါ၊ ပြီးရင် ဒေါင်းလုပ်လုပ်ပါ။"
                    } else {
                        ttsStatusText.text =
                            "ပြီးပြီ — ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    ttsMakeButton.isEnabled = true
                    ttsProgressBar.isIndeterminate = false
                    ttsProgressBar.progress = 0
                    ttsStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    /** Prepares the listen-here player for freshly generated audio. */
    private fun setupTtsPlayer(audio: ByteArray) {
        stopTtsPlayer()
        try {
            val file = File(cacheDir, "tts-preview-${stamp()}.mp3")
            file.writeBytes(audio)
            ttsPlayerFile = file
            val mp = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                prepare()
                setOnCompletionListener {
                    ttsPlayButton.text = "▶"
                    ttsSeekBar.progress = 0
                    ttsPlayerHandler.removeCallbacks(ttsPlayerPoller)
                }
            }
            ttsPlayer = mp
            ttsSeekBar.max = mp.duration
            ttsSeekBar.progress = 0
            ttsTimeText.text = "00:00 / ${formatClockUs(mp.duration * 1_000L)}"
            ttsPlayButton.text = "▶"
            ttsPlayerRow.visibility = View.VISIBLE
        } catch (e: Exception) {
            ttsPlayerRow.visibility = View.GONE
        }
    }

    private fun toggleTtsPlayback() {
        val mp = ttsPlayer ?: return
        try {
            if (mp.isPlaying) {
                mp.pause()
                ttsPlayButton.text = "▶"
                ttsPlayerHandler.removeCallbacks(ttsPlayerPoller)
            } else {
                mp.start()
                ttsPlayButton.text = "⏸"
                ttsPlayerHandler.removeCallbacks(ttsPlayerPoller)
                ttsPlayerHandler.post(ttsPlayerPoller)
            }
        } catch (e: Exception) {
        }
    }

    /** Pauses playback when leaving the TTS screen, keeping the
     * player ready so listening can resume on return. */
    private fun pauseTtsPlayer() {
        ttsPlayerHandler.removeCallbacks(ttsPlayerPoller)
        try {
            if (ttsPlayer?.isPlaying == true) ttsPlayer?.pause()
        } catch (e: Exception) {
        }
        if (::ttsPlayButton.isInitialized) ttsPlayButton.text = "▶"
    }

    private fun stopTtsPlayer() {
        ttsPlayerHandler.removeCallbacks(ttsPlayerPoller)
        try {
            ttsPlayer?.stop()
        } catch (e: Exception) {
        }
        try {
            ttsPlayer?.release()
        } catch (e: Exception) {
        }
        ttsPlayer = null
        ttsPlayerFile?.delete()
        ttsPlayerFile = null
    }

    private fun onVoiceoverClicked() {
        val video = voVideoUri ?: return
        val option = voiceOptions[selectedVoiceIndex]
        voPickButton.isEnabled = false
        voMakeButton.isEnabled = false
        voDownloadButton.visibility = View.GONE
        voSrtDownloadButton.visibility = View.GONE
        voPreviewVideo.stopPlayback()
        voPreviewVideo.visibility = View.GONE
        voSrtText.visibility = View.GONE
        voProgressBar.isIndeterminate = true
        voStatusText.text = "Video တင်နေတယ်…"
        Thread {
            try {
                val fileName = video.lastPathSegment ?: "video.mp4"
                val client = TranscribeClient(contentResolver)
                val jobId = client.submitVoiceover(
                    video, fileName, apiKey, option.voice, 0, 0,
                    if (autoVoice) "auto" else "manual",
                    onUploadProgress = { pct ->
                        runOnUiThread {
                            voProgressBar.isIndeterminate = false
                            voProgressBar.progress = pct
                            voStatusText.text = "Video တင်နေတယ်… $pct%"
                        }
                    }
                )
                runOnUiThread {
                    voProgressBar.isIndeterminate = true
                    voStatusText.text = "မြန်မာအသံ ထည့်နေတယ်… (၁-၃ မိနစ် ကြာနိုင်တယ်)"
                }
                // Timed narration (server v24) synthesizes per speech block,
                // so a long video can take a while — allow up to ~30 min.
                val state = pollUntilDone(client, jobId, 450)
                val videoUrl = state.videoUrl
                    ?: throw IOException("Server က Video ပြန်မပေးဘူး။")
                runOnUiThread { voStatusText.text = "Video ပြန်ယူနေတယ်…" }
                val tmp = File(cacheDir, "voiceover-${stamp()}.mp4")
                client.downloadToFile(videoUrl, tmp)
                runOnUiThread {
                    voPickButton.isEnabled = true
                    voMakeButton.isEnabled = true
                    voProgressBar.isIndeterminate = false
                    voProgressBar.progress = 100
                    voLastTmp = tmp
                    voLastVideoUrl = videoUrl
                    voLastSrt = state.srt
                    voDownloadButton.visibility = View.VISIBLE
                    // Preview first: play the finished video here, and show
                    // the full SRT text on the page, before downloading.
                    val hasSrt = !state.srt.isNullOrBlank()
                    voSrtText.text = state.srt.orEmpty()
                    voSrtText.visibility = if (hasSrt) View.VISIBLE else View.GONE
                    voSrtDownloadButton.visibility =
                        if (hasSrt) View.VISIBLE else View.GONE
                    voPreviewVideo.setVideoURI(Uri.fromFile(tmp))
                    voPreviewVideo.setMediaController(
                        MediaController(this).apply { setAnchorView(voPreviewVideo) }
                    )
                    voPreviewVideo.visibility = View.VISIBLE
                    voPreviewVideo.start()
                    voStatusText.text = "ပြီးပြီ — Video နဲ့ SRT ကို ကြည့်ပြီး၊ လိုချင်တာကို ဒေါင်းလုပ်လုပ်ပါ။"
                    // Bring the finished video into view.
                    voScrollView.post {
                        voScrollView.smoothScrollTo(0, voPreviewVideo.top)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    voPickButton.isEnabled = true
                    voMakeButton.isEnabled = voVideoUri != null
                    voProgressBar.isIndeterminate = false
                    voProgressBar.progress = 0
                    voPreviewVideo.stopPlayback()
                    voPreviewVideo.visibility = View.GONE
                    voSrtText.visibility = View.GONE
                    voDownloadButton.visibility = View.GONE
                    voSrtDownloadButton.visibility = View.GONE
                    voStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    // v0.6.11: while a prompt-video job runs, hide the form (prompt
    // box, images) and show only the progress bar + status text, so
    // it is obvious the job is running. Restored when the job
    // finishes or fails.
    private fun setPvRunning(running: Boolean) {
        val formVisibility = if (running) View.GONE else View.VISIBLE
        pvInputCard.visibility = formVisibility
        pvHintText.visibility = formVisibility
        if (running) {
            pvImageLabel.visibility = View.GONE
            pvImageRow.visibility = View.GONE
            pvClearImagesButton.visibility = View.GONE
        } else {
            pvImageLabel.visibility = View.VISIBLE
            updatePvImageLabel()
        }
    }

    private fun onPromptVideoClicked() {
        val prompt = pvTextField.text.toString().trim()
        if (prompt.isEmpty()) {
            pvStatusText.text = "Prompt ရိုက်ထည့်ပါ။"
            return
        }
        val imageUris = pvImageUris.toList()
        pvMakeButton.isEnabled = false
        pvDownloadButton.visibility = View.GONE
        setPvRunning(true)
        pvProgressBar.isIndeterminate = true
        pvStatusText.text = "ဇာတ်လမ်း ရေးနေတယ်…"
        Thread {
            try {
                val imageFiles = imageUris.mapIndexed { idx, uri ->
                    copyUriToCache(uri, "pv-image-$idx")
                }
                // Auto mode (server v28+): the AI splits the narration by
                // character and gives each their own voice. The voice sent
                // here is only the fallback if the split fails.
                val jobId = TtsClient().submitPromptVideo(
                    prompt, apiKey, TtsClient.VOICE_NILAR, 0, 0, imageFiles, "auto"
                )
                runOnUiThread {
                    pvStatusText.text = "ပုံထုတ် + အသံထည့် + Video ပေါင်းနေတယ်… (မိနစ် အနည်းငယ် ကြာနိုင်တယ်)"
                }
                val client = TranscribeClient(contentResolver)
                // Prompt-video assembles 3 scenes on the free server, so it
                // may take longer than a transcription: allow ~30 minutes.
                val state = pollUntilDone(client, jobId, maxWaits = 450)
                val videoUrl = state.videoUrl
                    ?: throw IOException("Server က Video ပြန်မပေးဘူး။")
                runOnUiThread { pvStatusText.text = "Video ပြန်ယူနေတယ်…" }
                val tmp = File(cacheDir, "prompt-video-${stamp()}.mp4")
                client.downloadToFile(videoUrl, tmp)
                runOnUiThread {
                    pvMakeButton.isEnabled = true
                    setPvRunning(false)
                    pvProgressBar.isIndeterminate = false
                    pvProgressBar.progress = 100
                    pvLastTmp = tmp
                    pvLastVideoUrl = videoUrl
                    pvLastSrt = state.srt
                    pvDownloadButton.visibility = View.VISIBLE
                    pvStatusText.text = "ပြီးပြီ — ဒေါင်းလုဒ်လုပ်ရန် အောက်က ခလုတ်ကို နှိပ်ပါ။"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    pvMakeButton.isEnabled = true
                    setPvRunning(false)
                    pvProgressBar.isIndeterminate = false
                    pvProgressBar.progress = 0
                    pvStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    // v0.6.2: finished files are saved to Downloads only when the user
    // taps the separate download button on each screen.
    private fun onWorkDownloadClicked() {
        val srt = workLastSrt
        val output = workLastOutput
        if (srt == null && output == null) return
        workDownloadButton.isEnabled = false
        setStatus("Download/zhang file ထဲ သိမ်းနေတယ်…")
        Thread {
            try {
                val savedName = if (srt != null) {
                    saveSrtToDownloads(srt)
                } else {
                    copyToDownloads(output!!, "video/mp4")
                }
                runOnUiThread {
                    workDownloadButton.isEnabled = true
                    if (savedName != null) {
                        setStatus("ပြီးပြီ — Download/zhang file ထဲ သိမ်းပြီးပြီ:\n$savedName")
                    } else {
                        setStatus("အမှား: သိမ်းလို့ မရဘူး။")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    workDownloadButton.isEnabled = true
                    setStatus("အမှား: ${e.message ?: "unknown error"}")
                }
            }
        }.start()
    }

    private fun onTtsDownloadClicked() {
        val video = ttsLastVideo
        val audio = ttsLastAudio
        if (video == null && audio == null) return
        ttsDownloadButton.isEnabled = false
        ttsStatusText.text = "Download/zhang file ထဲ သိမ်းနေတယ်…"
        Thread {
            try {
                val mainName: String?
                if (video != null) {
                    val file = if (video.exists()) {
                        video
                    } else {
                        val videoUrl = ttsLastVideoUrl
                            ?: throw IOException("Video ပြန်ယူလို့ မရဘူး။")
                        val fresh = File(cacheDir, "narrated-image-${stamp()}.mp4")
                        TranscribeClient(contentResolver).downloadToFile(videoUrl, fresh)
                        ttsLastVideo = fresh
                        fresh
                    }
                    mainName = copyToDownloads(file, "video/mp4")
                } else {
                    mainName = saveBytesToDownloads(
                        audio!!, "zhang-studio-voice-${stamp()}.mp3", "audio/mpeg"
                    )
                }
                val srtName = ttsLastSrt?.let { saveSrtToDownloads(it) }
                runOnUiThread {
                    ttsDownloadButton.isEnabled = true
                    if (mainName != null) {
                        ttsStatusText.text = "ပြီးပြီ — Download/zhang file ထဲ သိမ်းပြီးပြီ:\n$mainName" +
                            (if (srtName != null) "\n$srtName" else "")
                    } else {
                        ttsStatusText.text = "အမှား: သိမ်းလို့ မရဘူး။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    ttsDownloadButton.isEnabled = true
                    ttsStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    private fun onTimingDownloadClicked() {
        val output = timingLastOutput ?: return
        timingDownloadButton.isEnabled = false
        timingStatusText.text = "Download/zhang file ထဲ သိမ်းနေတယ်…"
        Thread {
            try {
                val savedName = copyToDownloads(output, "video/mp4")
                runOnUiThread {
                    timingDownloadButton.isEnabled = true
                    if (savedName != null) {
                        timingStatusText.text =
                            "ပြီးပြီ — Download/zhang file ထဲ သိမ်းပြီးပြီ:\n$savedName"
                    } else {
                        timingStatusText.text = "အမှား: သိမ်းလို့ မရဘူး။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    timingDownloadButton.isEnabled = true
                    timingStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    // Download the last finished video without re-running the job:
    // the cached file is copied to Downloads (no data used), or the
    // video is fetched again from the saved server URL if the cache is gone.
    /** Downloads only the finished voiceover video. */
    private fun onVoVideoDownloadClicked() {
        val tmp = voLastTmp
        val videoUrl = voLastVideoUrl
        if (tmp == null || videoUrl == null) return
        voDownloadButton.isEnabled = false
        voStatusText.text = "Video ဒေါင်းလုဒ်လုပ်နေတယ်…"
        Thread {
            try {
                val file = if (tmp.exists()) {
                    tmp
                } else {
                    val fresh = File(cacheDir, "voiceover-${stamp()}.mp4")
                    TranscribeClient(contentResolver).downloadToFile(videoUrl, fresh)
                    voLastTmp = fresh
                    fresh
                }
                val savedName = copyToDownloads(file, "video/mp4")
                runOnUiThread {
                    voDownloadButton.isEnabled = true
                    voStatusText.text = if (savedName != null) {
                        "ပြီးပြီ — Download/zhang file ထဲ သိမ်းပြီးပြီ:\n$savedName"
                    } else {
                        "အမှား: Video သိမ်းလို့ မရဘူး။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    voDownloadButton.isEnabled = true
                    voStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    /** Downloads only the SRT, for users who want to add it themselves. */
    private fun onVoSrtDownloadClicked() {
        val srt = voLastSrt?.takeIf { it.isNotBlank() } ?: return
        voSrtDownloadButton.isEnabled = false
        voStatusText.text = "SRT သိမ်းနေတယ်…"
        Thread {
            try {
                val savedName = saveSrtToDownloads(srt)
                runOnUiThread {
                    voSrtDownloadButton.isEnabled = true
                    voStatusText.text = if (savedName != null) {
                        "ပြီးပြီ — Download/zhang file ထဲ သိမ်းပြီးပြီ:\n$savedName"
                    } else {
                        "အမှား: SRT သိမ်းလို့ မရဘူး။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    voSrtDownloadButton.isEnabled = true
                    voStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    private fun onPvDownloadClicked() {
        val tmp = pvLastTmp
        val videoUrl = pvLastVideoUrl
        if (tmp == null || videoUrl == null) return
        pvDownloadButton.isEnabled = false
        pvStatusText.text = "Video ဒေါင်းလုဒ်လုပ်နေတယ်…"
        Thread {
            try {
                val file = if (tmp.exists()) {
                    tmp
                } else {
                    val fresh = File(cacheDir, "prompt-video-${stamp()}.mp4")
                    TranscribeClient(contentResolver).downloadToFile(videoUrl, fresh)
                    pvLastTmp = fresh
                    fresh
                }
                val savedName = copyToDownloads(file, "video/mp4")
                val srtName = pvLastSrt?.takeIf { it.isNotBlank() }
                    ?.let { saveSrtToDownloads(it) }
                runOnUiThread {
                    pvDownloadButton.isEnabled = true
                    pvStatusText.text = if (savedName != null) {
                        "ပြီးပြီ — Download/zhang file ထဲ သိမ်းပြီးပြီ:\n$savedName" +
                            (if (srtName != null) "\n$srtName" else "")
                    } else {
                        "အမှား: Video သိမ်းလို့ မရဘူး။"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    pvDownloadButton.isEnabled = true
                    pvStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    private fun onTimingBurnClicked() {
        val video = timingVideoUri ?: return
        val (trimStartUs, trimEndUs) = timingTrimRange()
        if (trimEndUs != Long.MAX_VALUE && trimEndUs <= trimStartUs) {
            timingStatusText.text = "အဆုံး အချိန်က အစ ထက် နောက်ကျရမယ်။"
            return
        }
        val cut = timingCutRange()
        if (cut != null && cut.second <= cut.first) {
            timingStatusText.text = "ဖြတ်ထုတ်မယ့် အဆုံး အချိန်က အစ ထက် နောက်ကျရမယ်။"
            return
        }
        val segments = timingSegments()
        if (segments != null && segments.isEmpty()) {
            timingStatusText.text = "ဖြတ်ထုတ်ပြီးနောက် Video မကျန်ဘူး။"
            return
        }
        val cues = burnCues(segments != null)
        if (cues.isEmpty()) {
            timingStatusText.text = "ရွှေ့ပြီးနောက် စာတန်း မကျန်ဘူး။"
            return
        }
        timingBusy = true
        updateTimingEnabled()
        timingDownloadButton.visibility = View.GONE
        timingLastOutput = null
        timingProgressBar.progress = 0
        timingStatusText.text = "စာတန်းထည့်နေတယ်… 0%"
        timingPreviewVideo.stopPlayback()
        timingPreviewHandler.removeCallbacks(timingPreviewPoller)
        try {
            val typeface = loadMyanmarTypeface()
            val outputFile = newOutputFile()
            val newBurner = SubtitleBurner(this)
            timingBurner = newBurner
            val clipEndUs = if (trimEndUs == Long.MAX_VALUE) {
                androidx.media3.common.C.TIME_END_OF_SOURCE
            } else {
                trimEndUs
            }
            val topText = timingTopTextField.text.toString().trim()
                .takeIf { it.isNotEmpty() }
            newBurner.start(
                video, cues, typeface, outputFile, timingBurnCallback,
                trimStartUs, clipEndUs, topText,
                segments, timingSpeed, timingMusicUri,
                timingMuteCheck.isChecked, segments != null
            )
        } catch (e: Exception) {
            timingBusy = false
            updateTimingEnabled()
            timingStatusText.text = "အမှား: ${e.message ?: "unknown error"}"
        }
    }

    private fun onTimingSaveSrtClicked() {
        val (trimStartUs, trimEndUs) = timingTrimRange()
        if (trimEndUs != Long.MAX_VALUE && trimEndUs <= trimStartUs) {
            timingStatusText.text = "အဆုံး အချိန်က အစ ထက် နောက်ကျရမယ်။"
            return
        }
        val cut = timingCutRange()
        if (cut != null && cut.second <= cut.first) {
            timingStatusText.text = "ဖြတ်ထုတ်မယ့် အဆုံး အချိန်က အစ ထက် နောက်ကျရမယ်။"
            return
        }
        val cues = effectiveTimingCues()
        if (cues.isEmpty()) {
            timingStatusText.text = "ရွှေ့ပြီးနောက် စာတန်း မကျန်ဘူး။"
            return
        }
        timingBusy = true
        updateTimingEnabled()
        timingStatusText.text = "SRT သိမ်းနေတယ်…"
        Thread {
            val savedName = saveSrtToDownloads(SrtParser.toSrtText(cues))
            runOnUiThread {
                timingBusy = false
                updateTimingEnabled()
                timingProgressBar.progress = 100
                if (savedName != null) {
                    timingStatusText.text =
                        "ပြီးပြီ — SRT ကို Download/zhang file ထဲ သိမ်းပြီးပြီ:\n$savedName"
                } else {
                    timingStatusText.text = "အမှား: SRT သိမ်းလို့ မရဘူး။"
                }
            }
        }.start()
    }

    private fun updateTimingEnabled() {
        val ready = !timingBusy && timingVideoUri != null && timingCues.isNotEmpty()
        timingBurnButton.isEnabled = ready
        timingSaveSrtButton.isEnabled = ready
        timingPickVideoButton.isEnabled = !timingBusy
        timingChangeVideoButton.isEnabled = !timingBusy
        timingPickSrtButton.isEnabled = !timingBusy
    }

    private fun refreshSpeedButtons() {
        for ((button, speed) in timingSpeedButtons) {
            val selected = speed == timingSpeed
            button.background = pillBg(
                if (selected) Color.rgb(13, 84, 96) else Color.WHITE,
                if (selected) Color.rgb(72, 199, 214) else null,
                2
            )
            button.setTextColor(if (selected) Color.WHITE else Color.BLACK)
        }
    }

    /** Trim range from the trim fields, in microseconds. Blank/invalid
     * start = 0; blank/invalid end = no end trim (Long.MAX_VALUE). */
    private fun timingTrimRange(): Pair<Long, Long> {
        val startSecs = timingTrimStartField.text.toString().trim()
            .toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
        val endSecs = timingTrimEndField.text.toString().trim()
            .toDoubleOrNull()?.coerceAtLeast(0.0)
        val startUs = (startSecs * 1_000_000).toLong()
        val endUs = if (endSecs == null) Long.MAX_VALUE else (endSecs * 1_000_000).toLong()
        return startUs to endUs
    }

    /** Cut-out range from the cut fields, in microseconds on the TRIMMED
     * timeline. Null when both fields are blank (no cut). */
    private fun timingCutRange(): Pair<Long, Long>? {
        val startText = timingCutStartField.text.toString().trim()
        val endText = timingCutEndField.text.toString().trim()
        if (startText.isEmpty() && endText.isEmpty()) return null
        val startSecs = startText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
        val endSecs = endText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: return null
        return (startSecs * 1_000_000).toLong() to (endSecs * 1_000_000).toLong()
    }

    /** Original-timeline segments for the cut-out edit, or null when no
     * cut is requested. Empty list = the cut removes everything. */
    private fun timingSegments(): List<Pair<Long, Long>>? {
        val cut = timingCutRange() ?: return null
        val (trimStartUs, trimEndUs) = timingTrimRange()
        val trimmedEndUs = if (trimEndUs != Long.MAX_VALUE) {
            trimEndUs
        } else if (timingVideoDurationMs > 0) {
            timingVideoDurationMs * 1_000L
        } else {
            Long.MAX_VALUE
        }
        val segments = mutableListOf<Pair<Long, Long>>()
        if (cut.first > 0L) {
            segments.add(trimStartUs to trimStartUs + cut.first)
        }
        val seg2Start = trimStartUs + cut.second
        val seg2End = if (trimmedEndUs == Long.MAX_VALUE) {
            androidx.media3.common.C.TIME_END_OF_SOURCE
        } else {
            trimmedEndUs
        }
        if (trimmedEndUs == Long.MAX_VALUE || seg2Start < trimmedEndUs) {
            segments.add(seg2Start to seg2End)
        }
        return segments
    }

    /** Cues on the OUTPUT timeline (shift, trim, cut-out, speed) — what
     * the SRT save and the info line use. */
    private fun effectiveTimingCues(): List<SubtitleCue> {
        var cues = SrtParser.shifted(timingCues, timingShiftUs)
        val (startUs, endUs) = timingTrimRange()
        cues = SrtParser.trimmed(cues, startUs, endUs)
        val cut = timingCutRange()
        if (cut != null) cues = SrtParser.cutOut(cues, cut.first, cut.second)
        return SrtParser.scaled(cues, timingSpeed)
    }

    /** Cues for the burn. With a cut-out edit the overlay runs at
     * Composition level on the output timeline (scaled); otherwise it
     * runs at item level on content timestamps (unscaled). */
    private fun burnCues(cutRequested: Boolean): List<SubtitleCue> {
        var cues = SrtParser.shifted(timingCues, timingShiftUs)
        val (startUs, endUs) = timingTrimRange()
        cues = SrtParser.trimmed(cues, startUs, endUs)
        val cut = timingCutRange()
        if (cut != null) cues = SrtParser.cutOut(cues, cut.first, cut.second)
        if (cutRequested) cues = SrtParser.scaled(cues, timingSpeed)
        return cues
    }

    private fun updateTimingInfo() {
        if (::timingSrtTrack.isInitialized) {
            timingSrtTrack.setCues(SrtParser.shifted(timingCues, timingShiftUs))
        }
        if (timingCues.isEmpty()) {
            timingInfoText.text = ""
            return
        }
        val shifted = effectiveTimingCues()
        if (shifted.isEmpty()) {
            timingInfoText.text = "ရွှေ့ပြီးနောက် စာတန်း မကျန်ဘူး။"
            return
        }
        timingInfoText.text =
            "စာတန်း ${shifted.size} ပိုင်း — ပထမ စာတန်း ${formatClockUs(shifted.first().startUs)} မှာ စမယ်"
    }

    /** Polls the server until the job finishes (about 10 minutes max). */
    private fun pollUntilDone(
        client: TranscribeClient,
        jobId: String,
        maxWaits: Int = 150
    ): TranscribeClient.JobState {
        var failures = 0
        var waited = 0
        while (waited < maxWaits) {
            val state = try {
                client.poll(jobId)
            } catch (e: IOException) {
                failures++
                if (failures > 5) {
                    throw IOException("Server နဲ့ အဆက်ပြတ်သွားတယ်။ ထပ်စမ်းပါ။")
                }
                null
            }
            if (state != null) {
                failures = 0
                when (state.status) {
                    "done" -> return state
                    "error" -> throw IOException(state.error ?: "Server error")
                    // "pending": keep waiting.
                }
            }
            Thread.sleep(4000)
            waited++
        }
        throw IOException("အချိန်ကြာလွန်းတယ်။ ထပ်စမ်းပါ။")
    }

    private fun waitForJob(client: TranscribeClient, jobId: String): String {
        val state = pollUntilDone(client, jobId)
        return state.srt ?: throw IOException("Server returned no subtitles")
    }

    private fun postStatus(text: String) {
        runOnUiThread { setStatus(text) }
    }

    private fun postError(message: String) {
        runOnUiThread {
            setBusy(false)
            setStatus("အမှား: $message")
        }
    }

    // ---------- helpers ----------

    private fun titleText(text: String, size: Float): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
    }

    private fun sectionLabel(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 17f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(Color.WHITE)
    }

    private fun hintText(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(Color.rgb(235, 235, 235))
        gravity = Gravity.CENTER
    }

    private fun pillBg(color: Int, strokeColor: Int?, strokeWidthDp: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(30).toFloat()
            setColor(color)
            if (strokeColor != null) setStroke(dp(strokeWidthDp), strokeColor)
        }

    private fun pillButton(text: String, bg: Int, fg: Int, stroke: Int?): Button =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 18f
            setTextColor(fg)
            background = pillBg(bg, stroke, 2)
            setPadding(dp(20), dp(12), dp(20), dp(12))
        }

    private fun rowParams(topDp: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(topDp) }

    /**
     * Bundled Noto Sans Myanmar (shapes Myanmar correctly with
     * StaticLayout). Falls back to the system default typeface if the
     * asset is missing — most Android devices ship a Myanmar font.
     */
    private fun loadMyanmarTypeface(): Typeface {
        return try {
            Typeface.createFromAsset(assets, "NotoSansMyanmar-Regular.ttf")
        } catch (e: Exception) {
            Typeface.DEFAULT
        }
    }

    companion object {
        // All downloads go into a "zhang file" folder inside Downloads,
        // so the app's videos, audio and SRTs stay together in one place.
        // MediaStore creates the subfolder automatically on Android 10+.
        const val DOWNLOADS_FOLDER = "Download/zhang file"
    }

    /**
     * Copies [source] into the public Downloads folder (MediaStore, no
     * storage permission needed for the app's own files on Android 10+).
     * Returns the file name on success, null on failure (or on Android
     * older than 10, where the private path is reported instead). The
     * private temp file is deleted after a successful copy.
     */
    private fun copyToDownloads(source: File, mimeType: String): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, source.name)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, DOWNLOADS_FOLDER)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return null
            contentResolver.openOutputStream(uri)?.use { out ->
                FileInputStream(source).use { it.copyTo(out) }
            } ?: return null
            source.delete()
            source.name
        } catch (e: Exception) {
            null
        }
    }

    /** Writes bytes straight into the public Downloads folder. */
    private fun saveBytesToDownloads(bytes: ByteArray, name: String, mimeType: String): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, DOWNLOADS_FOLDER)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return null
            contentResolver.openOutputStream(uri)?.use { out ->
                out.write(bytes)
            } ?: return null
            name
        } catch (e: Exception) {
            null
        }
    }

    /** Writes SRT text straight into the public Downloads folder. */
    private fun saveSrtToDownloads(srtText: String): String? {
        return saveBytesToDownloads(
            srtText.toByteArray(Charsets.UTF_8),
            "zhang-studio-${stamp()}.srt",
            "application/x-subrip"
        )
    }

    private fun stamp(): String =
        SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())

    /** Copies a picked content Uri to a cache file for upload. */
    @Throws(IOException::class)
    private fun copyUriToCache(uri: Uri, prefix: String): File {
        val tmp = File(cacheDir, "$prefix-${stamp()}.jpg")
        contentResolver.openInputStream(uri)?.use { input ->
            tmp.outputStream().use { output -> input.copyTo(output) }
        } ?: throw IOException("Could not open the image")
        return tmp
    }

    /** Output goes to the app's private Movies folder (no storage permission needed). */
    private fun newOutputFile(): File {
        val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: cacheDir
        if (!dir.exists()) dir.mkdirs()
        return File(dir, "zhang-studio-subtitled-${stamp()}.mp4")
    }

    private fun formatClockUs(timeUs: Long): String {
        val totalSeconds = timeUs / 1_000_000L
        val minutes = totalSeconds / 60L
        val seconds = totalSeconds % 60L
        return "%02d:%02d".format(minutes, seconds)
    }

    private fun fmtSeconds(seconds: Double): String {
        return if (seconds == seconds.toInt().toDouble()) {
            seconds.toInt().toString()
        } else {
            "%.1f".format(seconds)
        }
    }

    private fun updateMakeEnabled() {
        makeButton.isEnabled = videoUri != null
    }

    private fun setBusy(busy: Boolean) {
        pickVideoButton.isEnabled = !busy
        makeButton.isEnabled = !busy && videoUri != null
    }

    private fun setStatus(text: String) {
        statusText.text = text
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
