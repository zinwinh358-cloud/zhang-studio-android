package com.zhangstudio.app

import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.util.UnstableApi
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Minimal UI: pick a video, pick an SRT file, burn the subtitles into the
 * video on-device, and report where the output was saved.
 *
 * The subtitle burn runs fully on the phone (Media3 Transformer). The SRT
 * file is picked from storage for now; fetching subtitles from the Zhang
 * Studio server is a later step and deliberately not implemented here.
 *
 * All errors surface as status text — the app never crashes on bad input.
 */
@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {

    private var videoUri: Uri? = null
    private var srtUri: Uri? = null
    private var burner: SubtitleBurner? = null

    private lateinit var pickVideoButton: Button
    private lateinit var videoLabel: TextView
    private lateinit var pickSrtButton: Button
    private lateinit var srtLabel: TextView
    private lateinit var burnButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView

    private val pickVideoLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                videoUri = uri
                videoLabel.text = "Video: ${uri.lastPathSegment ?: uri}"
                updateBurnEnabled()
            }
        }

    private val pickSrtLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                srtUri = uri
                srtLabel.text = "SRT: ${uri.lastPathSegment ?: uri}"
                updateBurnEnabled()
            }
        }

    private val burnCallback = object : SubtitleBurner.Callback {
        override fun onProgress(percent: Int) {
            progressBar.progress = percent
            setStatus("Burning subtitles… $percent%")
        }

        override fun onCompleted(outputPath: String) {
            setBusy(false)
            progressBar.progress = 100
            setStatus("Done — output saved at:\n$outputPath")
        }

        override fun onError(message: String) {
            setBusy(false)
            setStatus("Error: $message")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = dp(16)
            setPadding(pad, pad, pad, pad)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val title = TextView(this).apply {
            text = "Zhang Studio — Subtitle Burner"
            textSize = 20f
        }
        pickVideoButton = Button(this).apply { text = "Pick video" }
        videoLabel = TextView(this).apply { text = "No video selected" }
        pickSrtButton = Button(this).apply { text = "Pick SRT file" }
        srtLabel = TextView(this).apply { text = "No SRT file selected" }
        burnButton = Button(this).apply {
            text = "Burn subtitles"
            isEnabled = false
        }
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        statusText = TextView(this).apply { text = "Pick a video and an SRT file to start." }

        pickVideoButton.setOnClickListener { pickVideoLauncher.launch("video/*") }
        pickSrtButton.setOnClickListener { pickSrtLauncher.launch("*/*") }
        burnButton.setOnClickListener { onBurnClicked() }

        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
        root.addView(title, params)
        root.addView(pickVideoButton, params)
        root.addView(videoLabel, params)
        root.addView(pickSrtButton, params)
        root.addView(srtLabel, params)
        root.addView(burnButton, params)
        root.addView(progressBar, params)
        root.addView(statusText, params)

        setContentView(root)
    }

    override fun onDestroy() {
        burner?.cancel()
        burner = null
        super.onDestroy()
    }

    private fun onBurnClicked() {
        val video = videoUri
        val srt = srtUri
        if (video == null || srt == null) {
            setStatus("Pick a video and an SRT file first.")
            return
        }
        setBusy(true)
        progressBar.progress = 0
        setStatus("Reading subtitles…")
        try {
            val cues = SrtParser.parse(readTextFile(srt))
            if (cues.isEmpty()) {
                setBusy(false)
                setStatus("No cues found in the SRT file.")
                return
            }
            val typeface = loadMyanmarTypeface()
            val outputFile = newOutputFile()
            val newBurner = SubtitleBurner(this)
            burner = newBurner
            setStatus("Burning subtitles… 0%")
            newBurner.start(video, cues, typeface, outputFile, burnCallback)
        } catch (e: Exception) {
            setBusy(false)
            setStatus("Error: ${e.message ?: "unknown error"}")
        }
    }

    private fun readTextFile(uri: Uri): String {
        val stream = contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("Could not open the SRT file")
        return stream.use { it.bufferedReader(Charsets.UTF_8).readText() }
    }

    /**
     * Bundled Noto Sans Myanmar (shapes Myanmar correctly with
     * StaticLayout). Falls back to the system default typeface if the
     * asset is missing — most Android devices ship a Myanmar font.
     */
    private fun loadMyanmarTypeface(): Typeface {
        return try {
            Typeface.createFromAsset(assets, "NotoSansMyanmar-Regular.ttf")
        } catch (e: Exception) {
            Typeface.DEFAULT
        }
    }

    /** Output goes to the app's private Movies folder (no storage permission needed). */
    private fun newOutputFile(): File {
        val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: cacheDir
        if (!dir.exists()) dir.mkdirs()
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        return File(dir, "zhang-studio-subtitled-$stamp.mp4")
    }

    private fun updateBurnEnabled() {
        burnButton.isEnabled = videoUri != null && srtUri != null
    }

    private fun setBusy(busy: Boolean) {
        pickVideoButton.isEnabled = !busy
        pickSrtButton.isEnabled = !busy
        burnButton.isEnabled = !busy && videoUri != null && srtUri != null
    }

    private fun setStatus(text: String) {
        statusText.text = text
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
