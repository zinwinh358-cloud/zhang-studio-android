package com.zhangstudio.app

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

/**
 * v0.10.16: frosted-glass blur bands over the top and bottom edges of
 * the frame. Zin's reference video (15 Nov) covers baked-in original
 * subtitles and corner logos with a REAL blur — the picture shows
 * through, smeared and unreadable — not a tinted band. The old
 * translucent band bitmaps (CoverBandOverlay / TopBandOverlay) left
 * the original text readable, so this replaces them. The video stays
 * full-frame; nothing is cropped and no black bars appear.
 *
 * A custom [GlEffect]: Media3 1.11.1 ships GaussianBlur, but it blurs
 * the WHOLE frame — there is no built-in region blur. The shader
 * program mirrors AlphaScaleShaderProgram's structure, verified
 * against the 1.11.1 effect AAR bytecode (BaseGlShaderProgram +
 * GlProgram + identity matrices + fullscreen quad + glDrawArrays
 * TRIANGLE_STRIP), with a fragment shader that box-blurs only inside
 * the two bands and feathers the inner edge.
 *
 * Texture coordinates: v=0 is the bottom of the displayed frame
 * (Media3's transformation program normalizes orientation before
 * effects run). If a future Media3 version flips this, the bands
 * swap edges — the fix is swapping the two rects in [drawFrame].
 *
 * @param bottomFrac height of the bottom blur band as a fraction of
 *   frame height (0 = disabled). 0.14 covers the usual baked-in
 *   subtitle zone and the new subtitles' bottom edge (12%).
 * @param topFrac height of the top blur band as a fraction of frame
 *   height (0 = disabled). 0.10 covers corner logos.
 * @param midBand v0.14.0: an arbitrary blur band as (yStart, yEnd)
 *   frame fractions from the TOP (server detection coords) — the
 *   auto-detected baked-in subtitle zone, which can sit in the
 *   MIDDLE of the frame. Null = disabled. Converted to texture
 *   coords (y=0 at the bottom) in [drawFrame].
 * @param blurRadius blur step in texels (5x5 box taps span ±2 steps).
 */
@OptIn(UnstableApi::class)
class RegionBlurEffect(
    private val bottomFrac: Float,
    private val topFrac: Float,
    private val midBand: Pair<Float, Float>? = null,
    private val blurRadius: Float = 10f
) : GlEffect {

    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram {
        return RegionBlurShaderProgram(context, useHdr, bottomFrac, topFrac, midBand, blurRadius)
    }

    override fun isNoOp(inputWidth: Int, inputHeight: Int): Boolean = false
}

@OptIn(UnstableApi::class)
private class RegionBlurShaderProgram(
    context: Context,
    useHdr: Boolean,
    private val bottomFrac: Float,
    private val topFrac: Float,
    private val midBand: Pair<Float, Float>?,
    private val blurRadius: Float
) : BaseGlShaderProgram(useHdr, 1) {

    // GlProgram(String, String) takes raw shader code (verified in the
    // 1.11.1 common AAR: it calls addShader with the strings directly).
    private val glProgram: GlProgram = try {
        GlProgram(VERTEX_SHADER, FRAGMENT_SHADER)
    } catch (e: Exception) {
        throw VideoFrameProcessingException(e)
    }

    private var inputWidth: Int = 0
    private var inputHeight: Int = 0

    init {
        glProgram.setBufferAttribute(
            "aFramePosition",
            GlUtil.getNormalizedCoordinateBounds(),
            4
        )
        val identity = GlUtil.create4x4IdentityMatrix()
        glProgram.setFloatsUniform("uTransformationMatrix", identity)
        glProgram.setFloatsUniform("uTexTransformationMatrix", identity)
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        this.inputWidth = inputWidth
        this.inputHeight = inputHeight
        return Size(inputWidth, inputHeight)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            glProgram.use()
            glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            // Bands in texture coords (y=0 at the frame bottom). A band
            // with end <= start is disabled (the shader skips it).
            glProgram.setFloatsUniform(
                "uBottomBand", floatArrayOf(0f, bottomFrac)
            )
            glProgram.setFloatsUniform(
                "uTopBand", floatArrayOf(1f - topFrac, 1f)
            )
            // v0.14.0: the detected band arrives in frame fractions
            // from the TOP (server coords); texture coords run from
            // the BOTTOM, so the band flips. [0, 0] disables it.
            val mid = midBand
            glProgram.setFloatsUniform(
                "uMidBand", floatArrayOf(
                    if (mid != null) 1f - mid.second else 0f,
                    if (mid != null) 1f - mid.first else 0f
                )
            )
            glProgram.setFloatsUniform(
                "uTexelSize",
                floatArrayOf(
                    if (inputWidth > 0) 1f / inputWidth else 0f,
                    if (inputHeight > 0) 1f / inputHeight else 0f
                )
            )
            glProgram.setFloatUniform("uBlurRadius", blurRadius)
            glProgram.setFloatUniform("uFeather", 0.02f)
            glProgram.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        } catch (e: Exception) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    companion object {
        // ES 2 vertex shader: same structure as Media3's
        // vertex_shader_transformation_es2.glsl. With identity
        // matrices it is a plain fullscreen-quad passthrough.
        // (plain val, not const: trimIndent() is not a constant.)
        private val VERTEX_SHADER = """
            #version 100
            attribute vec4 aFramePosition;
            uniform mat4 uTransformationMatrix;
            uniform mat4 uTexTransformationMatrix;
            varying vec2 vTexSamplingCoord;
            void main() {
              gl_Position = uTransformationMatrix * aFramePosition;
              vec4 texturePosition = vec4(aFramePosition.x * 0.5 + 0.5,
                                          aFramePosition.y * 0.5 + 0.5, 0.0, 1.0);
              vTexSamplingCoord = (uTexTransformationMatrix * texturePosition).xy;
            }
        """.trimIndent()

        // ES 2 fragment shader: 5x5 box blur inside the bottom/top
        // bands, feathered at the inner edge, sharp everywhere else.
        private val FRAGMENT_SHADER = """
            #version 100
            precision mediump float;
            uniform sampler2D uTexSampler;
            uniform vec2 uBottomBand;
            uniform vec2 uTopBand;
            uniform vec2 uMidBand;
            uniform vec2 uTexelSize;
            uniform float uBlurRadius;
            uniform float uFeather;
            varying vec2 vTexSamplingCoord;
            void main() {
              vec2 c = vTexSamplingCoord;
              vec4 sharp = texture2D(uTexSampler, c);
              float f = 0.0;
              if (uBottomBand.y > uBottomBand.x) {
                f = max(f, 1.0 - smoothstep(uBottomBand.y - uFeather, uBottomBand.y + uFeather, c.y));
              }
              if (uTopBand.y > uTopBand.x) {
                f = max(f, smoothstep(uTopBand.x - uFeather, uTopBand.x + uFeather, c.y));
              }
              if (uMidBand.y > uMidBand.x) {
                float fMid = smoothstep(uMidBand.x - uFeather, uMidBand.x + uFeather, c.y) * (1.0 - smoothstep(uMidBand.y - uFeather, uMidBand.y + uFeather, c.y));
                f = max(f, fMid);
              }
              if (f <= 0.0) {
                gl_FragColor = sharp;
              } else {
                vec4 sum = vec4(0.0);
                for (int dx = -2; dx <= 2; dx++) {
                  for (int dy = -2; dy <= 2; dy++) {
                    sum += texture2D(uTexSampler, c + vec2(float(dx), float(dy)) * uTexelSize * uBlurRadius);
                  }
                }
                gl_FragColor = mix(sharp, sum / 25.0, f);
              }
            }
        """.trimIndent()
    }
}
