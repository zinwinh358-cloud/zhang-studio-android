package com.zhangstudio.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint

/**
 * Renders subtitle cues into bottom "band" bitmaps, porting the geometry
 * proven by the server-side burner (v11 `render_cue_png` in
 * burmese-subtitle-app-gradio-gemini.py):
 *
 * - font size = max(24px, 4.5% of video height), times the cue's
 *   own size scale (v0.9.0 templates: heading 1.5x, subheading 1.2x)
 * - text wrapped to 90% of the video width, centered
 * - line height = font size * 1.35
 * - per-cue fill color (white by default) + black outline
 *   (stroke = max(2, font size / 16))
 * - text bottom edge sits 8% of the video height above the frame bottom
 * - the band is only as tall as the text plus a small padding, so the GPU
 *   overlay blends far fewer pixels than a full-frame bitmap
 *
 * One deviation from the server: every cue's band has the SAME height (the
 * tallest cue's height) and the same top offset, so the overlay texture
 * never changes size mid-export. Shorter cues simply carry extra
 * transparent rows on top; the visible text position is identical.
 *
 * Text shaping is done by Android's text stack (HarfBuzz via StaticLayout),
 * which shapes Myanmar correctly when given a Myanmar typeface.
 */
class SubtitleBandRenderer(
    private val typeface: Typeface,
    private val videoWidth: Int,
    private val videoHeight: Int
) {
    /** Font size in pixels. */
    val fontSizePx: Int = maxOf(24, (videoHeight * 0.045f).toInt())

    /** Height of every band bitmap in pixels. Valid after [prepare]. */
    var bandHeight: Int = 0
        private set

    /** Pixel offset of the band's top edge from the frame top. Valid after [prepare]. */
    var bandTop: Int = 0
        private set

    /** Padding between the band's bottom edge and the text bottom edge
     * (stroke + 4px at base size). Valid after [prepare]; the overlay
     * uses it to place a dragged cue's band from its yFrac. */
    var bandPadPx: Int = 0
        private set

    private val wrapWidthPx: Int = (videoWidth * 0.9f).toInt().coerceAtLeast(1)
    private val bottomMarginPx: Int = (videoHeight * 0.08f).toInt()

    // v0.9.0: per-cue style — each cue carries its own text color
    // and size scale (templates + swatches in the subtitle sheet).
    // Paints are built per cue (render output is cached per cue, so
    // this costs one small allocation per cue change, not per frame).
    private fun scaledFontPx(scale: Float): Int =
        maxOf(12, (fontSizePx * scale).toInt())

    private fun strokePx(fontPx: Int): Int = maxOf(2, fontPx / 16)

    private fun lineHeightPx(fontPx: Int): Int =
        fontPx + (fontPx * 0.35f).toInt()

    private fun fillPaintFor(cue: SubtitleCue): TextPaint =
        TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = this@SubtitleBandRenderer.typeface
            textSize = scaledFontPx(cue.sizeScale).toFloat()
            color = cue.color
            style = Paint.Style.FILL
        }

    private fun strokePaintFor(cue: SubtitleCue): TextPaint {
        val fontPx = scaledFontPx(cue.sizeScale)
        return TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = this@SubtitleBandRenderer.typeface
            textSize = fontPx.toFloat()
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = strokePx(fontPx).toFloat()
            strokeJoin = Paint.Join.ROUND
        }
    }

    /**
     * Measures every cue and fixes the shared [bandHeight]/[bandTop].
     * Must be called before [render].
     */
    fun prepare(cues: List<SubtitleCue>) {
        val basePadPx = strokePx(fontSizePx) + 4
        bandPadPx = basePadPx
        var maxHeight = lineHeightPx(fontSizePx) + 2 * basePadPx
        for (cue in cues) {
            val fontPx = scaledFontPx(cue.sizeScale)
            val layout = buildLayout(
                cue.text, fillPaintFor(cue), lineHeightPx(fontPx)
            )
            val height = layout.height + 2 * (strokePx(fontPx) + 4)
            if (height > maxHeight) maxHeight = height
        }
        var height = maxHeight
        // Band bottom edge sits `pad` below the 8%-margin line, exactly like
        // the server geometry (text bottom == 8% margin).
        var top = videoHeight - bottomMarginPx + basePadPx - height
        if (top < 0) top = 0
        if (height > videoHeight - top) height = videoHeight - top
        bandHeight = height.coerceAtLeast(1)
        bandTop = top
    }

    /**
     * Renders one cue's band bitmap (full video width x [bandHeight]).
     * The caller keeps the bitmap while the cue is active and drops the
     * reference afterwards; GC reclaims it (never recycle: the GL thread
     * may still hold it for a frame in flight).
     */
    fun render(cue: SubtitleCue): Bitmap {
        val bitmap = Bitmap.createBitmap(
            videoWidth.coerceAtLeast(1),
            bandHeight.coerceAtLeast(1),
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(bitmap)
        val fontPx = scaledFontPx(cue.sizeScale)
        val lineH = lineHeightPx(fontPx)
        val padPx = strokePx(fontPx) + 4
        val fillLayout = buildLayout(cue.text, fillPaintFor(cue), lineH)
        val strokeLayout = buildLayout(cue.text, strokePaintFor(cue), lineH)
        // Text bottom edge lands `pad` above the band's bottom edge, i.e.
        // exactly on the 8%-margin line in the frame.
        val y = (bandHeight - padPx - fillLayout.height).toFloat()
        val x = ((videoWidth - wrapWidthPx) / 2).toFloat()
        // v0.9.3: horizontal drag — shift the text block so its
        // center lands at cue.xFrac of the frame width, clamped so
        // the widest line stays inside the frame.
        var maxLineW = 0f
        for (i in 0 until fillLayout.lineCount) {
            val w = fillLayout.getLineWidth(i)
            if (w > maxLineW) maxLineW = w
        }
        val shift = if (maxLineW > 0f) {
            val textLeft = x + (wrapWidthPx - maxLineW) / 2f
            val textRight = x + (wrapWidthPx + maxLineW) / 2f
            ((cue.xFrac - 0.5f) * videoWidth)
                .coerceIn(-textLeft, videoWidth - textRight)
        } else {
            0f
        }
        canvas.save()
        canvas.translate(x + shift, y)
        strokeLayout.draw(canvas)
        fillLayout.draw(canvas)
        canvas.restore()
        return bitmap
    }

    private fun buildLayout(text: String, paint: TextPaint, lineH: Int): StaticLayout {
        val metrics = paint.fontMetricsInt
        val naturalHeight = (metrics.descent - metrics.ascent + metrics.leading).coerceAtLeast(1)
        val lineSpacingMult = lineH.toFloat() / naturalHeight
        return StaticLayout.Builder.obtain(text, 0, text.length, paint, wrapWidthPx)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setIncludePad(false)
            .setLineSpacing(0f, lineSpacingMult)
            .setBreakStrategy(Layout.BREAK_STRATEGY_SIMPLE)
            .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE)
            .build()
    }
}
