package com.zhangstudio.app

/**
 * One subtitle cue. Timestamps are in microseconds (matching Media3's
 * presentationTimeUs). [text] may contain '\n' for multi-line cues.
 */
data class SubtitleCue(val startUs: Long, val endUs: Long, val text: String)

/**
 * Standard SRT parser. Pure Kotlin, no Android dependencies, so it stays
 * unit-testable on the JVM.
 *
 * Accepts: cue-number line (optional), timestamp line
 * `HH:MM:SS,mmm --> HH:MM:SS,mmm` (a `.` millis separator is also accepted),
 * one or more text lines, blocks separated by blank lines. Handles CRLF
 * line endings, a UTF-8 BOM, missing trailing blank line, and trailing
 * positioning junk after the end timestamp. Cues with empty text or
 * end <= start are dropped. Result is sorted by start time.
 */
object SrtParser {

    private val TIMESTAMP_REGEX =
        Regex("""(\d+):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d+):(\d{2}):(\d{2})[,.](\d{1,3})""")
    private val CUE_NUMBER_REGEX = Regex("""\d+""")

    fun parse(srtText: String): List<SubtitleCue> {
        val clean = srtText
            .replace("\uFEFF", "")
            .replace("\r\n", "\n")
            .replace('\r', '\n')
        val cues = mutableListOf<SubtitleCue>()
        for (block in clean.split("\n\n")) {
            val lines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (lines.isEmpty()) continue
            var index = 0
            // Optional numeric cue-id line.
            if (lines[0].matches(CUE_NUMBER_REGEX)) index = 1
            if (index >= lines.size) continue
            val match = TIMESTAMP_REGEX.find(lines[index]) ?: continue
            val values = match.groupValues
            val startUs = toMicroseconds(values[1], values[2], values[3], values[4])
            val endUs = toMicroseconds(values[5], values[6], values[7], values[8])
            val text = lines.drop(index + 1).joinToString("\n").trim()
            if (text.isEmpty() || endUs <= startUs) continue
            cues.add(SubtitleCue(startUs, endUs, text))
        }
        return cues.sortedBy { it.startUs }
    }

    /**
     * Shifts every cue by [shiftUs] microseconds (positive = later, negative
     * = earlier). Start times clamp at zero; cues that end at or before
     * their (clamped) start are dropped. Used by the timing-adjust screen.
     */
    fun shifted(cues: List<SubtitleCue>, shiftUs: Long): List<SubtitleCue> {
        if (shiftUs == 0L) return cues
        val out = mutableListOf<SubtitleCue>()
        for (cue in cues) {
            val start = (cue.startUs + shiftUs).coerceAtLeast(0L)
            val end = cue.endUs + shiftUs
            if (end <= start) continue
            out.add(SubtitleCue(start, end, cue.text))
        }
        return out.sortedBy { it.startUs }
    }

    /** Formats cues back into SRT text (for saving a shifted SRT file). */
    fun toSrtText(cues: List<SubtitleCue>): String {
        val sb = StringBuilder()
        for ((index, cue) in cues.withIndex()) {
            sb.append(index + 1).append('\n')
            sb.append(formatTime(cue.startUs)).append(" --> ")
                .append(formatTime(cue.endUs)).append('\n')
            sb.append(cue.text).append("\n\n")
        }
        return sb.toString()
    }

    private fun formatTime(timeUs: Long): String {
        val totalMs = timeUs / 1_000L
        val hours = totalMs / 3_600_000L
        val minutes = (totalMs % 3_600_000L) / 60_000L
        val seconds = (totalMs % 60_000L) / 1_000L
        val millis = totalMs % 1_000L
        return "%02d:%02d:%02d,%03d".format(hours, minutes, seconds, millis)
    }

    private fun toMicroseconds(hours: String, minutes: String, seconds: String, millis: String): Long {
        val ms = millis.padEnd(3, '0').toLong()
        val totalSeconds = hours.toLong() * 3600 + minutes.toLong() * 60 + seconds.toLong()
        return totalSeconds * 1_000_000L + ms * 1_000L
    }
}
