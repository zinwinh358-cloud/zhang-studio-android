package com.zhangstudio.app

/**
 * One subtitle cue. Timestamps are in microseconds (matching Media3's
 * presentationTimeUs). [text] may contain '\n' for multi-line cues.
 * v0.9.0: [color] is the text color as a raw ARGB int (white by
 * default) and [sizeScale] multiplies the base font size (templates
 * in the subtitle sheet). Both survive every transform below.
 */
data class SubtitleCue(
    val startUs: Long,
    val endUs: Long,
    val text: String,
    val color: Int = 0xFFFFFFFF.toInt(),
    val sizeScale: Float = 1f,
    // v0.9.3: dragged position on the preview (VN text-box drag).
    // xFrac = text center as a fraction of frame width (0.5 =
    // centered); yFrac = text bottom edge as a fraction of frame
    // height (0.92 = the proven 8%-margin bottom position).
    val xFrac: Float = 0.5f,
    val yFrac: Float = 0.92f
)

/**
 * Standard SRT parser. Pure Kotlin, no Android dependencies, so it stays
 * unit-testable on the JVM.
 *
 * Accepts: cue-number line (optional), timestamp line
 * `HH:MM:SS,mmm --> HH:MM:SS,mmm` (a `.` millis separator is also accepted),
 * one or more text lines, blocks separated by blank lines. Handles CRLF
 * line endings, a UTF-8 BOM, missing trailing blank line, and trailing
 * positioning junk after the end timestamp. Cues with empty text or
 * end <= start are dropped. Result is sorted by start time.
 */
object SrtParser {

    private val TIMESTAMP_REGEX =
        Regex("""(\d+):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d+):(\d{2}):(\d{2})[,.](\d{1,3})""")
    private val CUE_NUMBER_REGEX = Regex("""\d+""")

    fun parse(srtText: String): List<SubtitleCue> {
        val clean = srtText
            .replace("\uFEFF", "")
            .replace("\r\n", "\n")
            .replace('\r', '\n')
        val cues = mutableListOf<SubtitleCue>()
        for (block in clean.split("\n\n")) {
            val lines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (lines.isEmpty()) continue
            var index = 0
            // Optional numeric cue-id line.
            if (lines[0].matches(CUE_NUMBER_REGEX)) index = 1
            if (index >= lines.size) continue
            val match = TIMESTAMP_REGEX.find(lines[index]) ?: continue
            val values = match.groupValues
            val startUs = toMicroseconds(values[1], values[2], values[3], values[4])
            val endUs = toMicroseconds(values[5], values[6], values[7], values[8])
            val text = lines.drop(index + 1).joinToString("\n").trim()
            if (text.isEmpty() || endUs <= startUs) continue
            cues.add(SubtitleCue(startUs, endUs, text))
        }
        return cues.sortedBy { it.startUs }
    }

    /**
     * Shifts every cue by [shiftUs] microseconds (positive = later, negative
     * = earlier). Start times clamp at zero; cues that end at or before
     * their (clamped) start are dropped. Used by the timing-adjust screen.
     */
    fun shifted(cues: List<SubtitleCue>, shiftUs: Long): List<SubtitleCue> {
        if (shiftUs == 0L) return cues
        val out = mutableListOf<SubtitleCue>()
        for (cue in cues) {
            val start = (cue.startUs + shiftUs).coerceAtLeast(0L)
            val end = cue.endUs + shiftUs
            if (end <= start) continue
            out.add(cue.copy(startUs = start, endUs = end))
        }
        return out.sortedBy { it.startUs }
    }

    /**
     * Keeps only the cues overlapping [startUs, endUs] (endUs = MAX means
     * no end), clamps them to the range, and rebases times so the trimmed
     * video starts at zero. Used with the timing screen's trim controls.
     */
    fun trimmed(cues: List<SubtitleCue>, startUs: Long, endUs: Long): List<SubtitleCue> {
        if (startUs <= 0L && endUs == Long.MAX_VALUE) return cues
        val out = mutableListOf<SubtitleCue>()
        for (cue in cues) {
            if (cue.endUs <= startUs || cue.startUs >= endUs) continue
            val start = maxOf(cue.startUs, startUs) - startUs
            val end = minOf(cue.endUs, endUs) - startUs
            if (end <= start) continue
            out.add(cue.copy(startUs = start, endUs = end))
        }
        return out.sortedBy { it.startUs }
    }

    /**
     * Removes the [cutStartUs, cutEndUs] range (cut-out edit) and closes
     * the gap: cues after the cut shift earlier by the cut length. Cues
     * overlapping the cut keep only the part outside it; a cue spanning
     * the whole cut keeps its head part.
     */
    fun cutOut(cues: List<SubtitleCue>, cutStartUs: Long, cutEndUs: Long): List<SubtitleCue> {
        if (cutEndUs <= cutStartUs) return cues
        val removed = cutEndUs - cutStartUs
        val out = mutableListOf<SubtitleCue>()
        for (cue in cues) {
            if (cue.endUs <= cutStartUs) {
                out.add(cue)
            } else if (cue.startUs >= cutEndUs) {
                out.add(cue.copy(startUs = cue.startUs - removed, endUs = cue.endUs - removed))
            } else if (cue.startUs < cutStartUs && cue.endUs > cutEndUs) {
                out.add(cue.copy(startUs = cue.startUs, endUs = cutStartUs))
            } else if (cue.startUs < cutStartUs) {
                out.add(cue.copy(startUs = cue.startUs, endUs = cutStartUs))
            } else if (cue.endUs > cutEndUs) {
                out.add(cue.copy(startUs = cutStartUs, endUs = cue.endUs - removed))
            }
            // Fully inside the cut: dropped.
        }
        return out.filter { it.endUs > it.startUs }.sortedBy { it.startUs }
    }

    /**
     * v0.7.0: rebases cues onto the joined output timeline of kept
     * [segments] (source-time ranges, sorted, non-overlapping). A cue
     * overlapping a kept segment keeps the overlapping part, shifted by
     * the deleted time before that segment; cues fully inside deleted
     * ranges are dropped; a cue spanning a gap is split at the gap.
     */
    fun rebased(
        cues: List<SubtitleCue>,
        segments: List<Pair<Long, Long>>
    ): List<SubtitleCue> {
        if (segments.isEmpty()) return emptyList()
        val offsets = ArrayList<Long>(segments.size)
        var acc = 0L
        for ((s, e) in segments) {
            offsets.add(acc - s)
            acc += (e - s)
        }
        val out = mutableListOf<SubtitleCue>()
        for (cue in cues) {
            for (i in segments.indices) {
                val (s, e) = segments[i]
                if (cue.endUs <= s || cue.startUs >= e) continue
                val start = maxOf(cue.startUs, s) + offsets[i]
                val end = minOf(cue.endUs, e) + offsets[i]
                if (end > start) out.add(cue.copy(startUs = start, endUs = end))
            }
        }
        return out.sortedBy { it.startUs }
    }

    /**
     * v0.7.0: splits the cue at [index] into two cues with the same text
     * at [splitUs]. Returns the original list when the split point is
     * not strictly inside the cue.
     */
    fun splitCue(
        cues: List<SubtitleCue>,
        index: Int,
        splitUs: Long
    ): List<SubtitleCue> {
        if (index < 0 || index >= cues.size) return cues
        val cue = cues[index]
        if (splitUs <= cue.startUs || splitUs >= cue.endUs) return cues
        val out = cues.toMutableList()
        out[index] = cue.copy(startUs = cue.startUs, endUs = splitUs)
        out.add(index + 1, cue.copy(startUs = splitUs, endUs = cue.endUs))
        return out
    }

    /** Scales every cue's times by 1/[speed] (the output timeline of a
     * speed-changed export). speed <= 0 or 1 returns the cues unchanged. */
    fun scaled(cues: List<SubtitleCue>, speed: Float): List<SubtitleCue> {
        if (speed <= 0f || speed == 1f) return cues
        return cues.map {
            it.copy(startUs = (it.startUs / speed).toLong(), endUs = (it.endUs / speed).toLong())
        }
    }

    /** Formats cues back into SRT text (for saving a shifted SRT file). */
    fun toSrtText(cues: List<SubtitleCue>): String {
        val sb = StringBuilder()
        for ((index, cue) in cues.withIndex()) {
            sb.append(index + 1).append('\n')
            sb.append(formatTime(cue.startUs)).append(" --> ")
                .append(formatTime(cue.endUs)).append('\n')
            sb.append(cue.text).append("\n\n")
        }
        return sb.toString()
    }

    private fun formatTime(timeUs: Long): String {
        val totalMs = timeUs / 1_000L
        val hours = totalMs / 3_600_000L
        val minutes = (totalMs % 3_600_000L) / 60_000L
        val seconds = (totalMs % 60_000L) / 1_000L
        val millis = totalMs % 1_000L
        return "%02d:%02d:%02d,%03d".format(hours, minutes, seconds, millis)
    }

    private fun toMicroseconds(hours: String, minutes: String, seconds: String, millis: String): Long {
        val ms = millis.padEnd(3, '0').toLong()
        val totalSeconds = hours.toLong() * 3600 + minutes.toLong() * 60 + seconds.toLong()
        return totalSeconds * 1_000_000L + ms * 1_000L
    }
}
