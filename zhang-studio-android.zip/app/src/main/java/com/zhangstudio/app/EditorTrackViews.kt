package com.zhangstudio.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/**
 * Second ticks + time labels above the editor tracks. The label step
 * adapts to the video length so labels never overlap.
 */
class TimeRulerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var durationMs: Long = 0L
    private val density = context.resources.displayMetrics.density

    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(180, 180, 180)
        strokeWidth = 2f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(220, 220, 220)
        textSize = 11f * density
    }

    fun setDuration(newDurationMs: Long) {
        if (newDurationMs > 0) durationMs = newDurationMs
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (durationMs <= 0) return
        val w = width.toFloat()
        val h = height.toFloat()
        val totalSecs = durationMs / 1000
        if (totalSecs <= 0) return
        val (labelStep, tickStep) = when {
            totalSecs <= 60 -> 5L to 1L
            totalSecs <= 300 -> 30L to 5L
            else -> 60L to 10L
        }
        var sec = 0L
        while (sec <= totalSecs) {
            val x = sec.toFloat() / totalSecs * w
            val isLabel = sec % labelStep == 0L
            val top = if (isLabel) h * 0.65f else h * 0.8f
            canvas.drawLine(x, top, x, h, tickPaint)
            if (isLabel) {
                val label = "%d:%02d".format(sec / 60, sec % 60)
                canvas.drawText(label, x + 4f, h * 0.5f, textPaint)
            }
            sec += tickStep
        }
    }
}

/**
 * The video clip strip on the timeline: frame thumbnails grabbed in the
 * background (a plain labelled block if grabbing fails), with a
 * playhead. Tapping or dragging seeks the preview. All tracks share
 * the same left edge, so the playheads line up vertically.
 */
class VideoStripView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var onSeekTo: ((Int) -> Unit)? = null

    private var durationMs: Long = 0L
    private var positionMs: Long = 0L
    private var hasVideo: Boolean = false
    private var frames: List<Bitmap> = emptyList()
    private var generation: Int = 0
    private val density = context.resources.displayMetrics.density

    private val bgPaint = Paint().apply { color = Color.rgb(38, 50, 56) }
    private val tintPaint = Paint().apply { color = Color.argb(60, 0, 0, 0) }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(72, 199, 214)
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 13f * density
        textAlign = Paint.Align.CENTER
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(160, 160, 160)
        textSize = 13f * density
        textAlign = Paint.Align.CENTER
    }
    private val playheadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 4f
    }

    fun setVideo(uri: Uri, newDurationMs: Long) {
        hasVideo = true
        if (newDurationMs > 0) durationMs = newDurationMs
        frames = emptyList()
        invalidate()
        val gen = ++generation
        Thread {
            val grabbed = grabFrames(uri)
            post {
                if (gen == generation) {
                    frames = grabbed
                    invalidate()
                }
            }
        }.start()
    }

    fun setDuration(newDurationMs: Long) {
        if (newDurationMs > 0) durationMs = newDurationMs
        invalidate()
    }

    fun setPosition(newPositionMs: Long) {
        positionMs = newPositionMs
        invalidate()
    }

    private fun grabFrames(uri: Uri): List<Bitmap> {
        val out = mutableListOf<Bitmap>()
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val durUs = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull()?.times(1_000L) ?: (durationMs * 1_000L)
            if (durUs <= 0) return emptyList()
            val count = 8
            for (i in 0 until count) {
                val t = durUs * (i * 2 + 1) / (count * 2)
                val bmp = retriever.getFrameAtTime(
                    t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                ) ?: continue
                val scaled = Bitmap.createScaledBitmap(
                    bmp, 160,
                    (160f * bmp.height / bmp.width).toInt().coerceAtLeast(1), false
                )
                if (scaled !== bmp) bmp.recycle()
                out.add(scaled)
            }
        } catch (e: Exception) {
            // Frame grab failed — the fallback block still shows.
        } finally {
            try {
                retriever.release()
            } catch (e: Exception) {
            }
        }
        return out
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, h, bgPaint)
        if (!hasVideo) {
            canvas.drawText("Video မရွေးရသေးဘူး", w / 2f, h / 2f + 6f * density, hintPaint)
            return
        }
        if (frames.isNotEmpty()) {
            val slotW = w / frames.size
            val src = Rect()
            val dst = RectF()
            for ((i, bmp) in frames.withIndex()) {
                src.set(0, 0, bmp.width, bmp.height)
                dst.set(i * slotW, 0f, (i + 1) * slotW, h)
                canvas.drawBitmap(bmp, src, dst, null)
            }
            canvas.drawRect(0f, 0f, w, h, tintPaint)
        } else {
            val label = "Video — ${formatMs(durationMs)}"
            canvas.drawText(label, w / 2f, h / 2f + 6f * density, textPaint)
        }
        canvas.drawRect(1f, 1f, w - 1f, h - 1f, borderPaint)
        if (durationMs > 0) {
            val px = positionMs.toFloat() / durationMs * w
            canvas.drawLine(px, 0f, px, h, playheadPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (durationMs <= 0) return super.onTouchEvent(event)
        if (event.action == MotionEvent.ACTION_DOWN ||
            event.action == MotionEvent.ACTION_MOVE
        ) {
            val fraction = (event.x / width.toFloat()).coerceIn(0f, 1f)
            val target = (fraction * durationMs).toInt()
            onSeekTo?.invoke(target)
            setPosition(target.toLong())
            return true
        }
        return super.onTouchEvent(event)
    }

    private fun formatMs(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }
}

/**
 * The background-music track: empty it invites a tap to pick music;
 * filled it shows the music name as a looping block. Tapping or
 * dragging a filled track seeks the preview.
 */
class MusicTrackView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var onSeekTo: ((Int) -> Unit)? = null
    var onAddMusic: (() -> Unit)? = null

    private var durationMs: Long = 0L
    private var positionMs: Long = 0L
    private var musicName: String? = null
    private val density = context.resources.displayMetrics.density

    private val bgPaint = Paint().apply { color = Color.rgb(30, 30, 30) }
    private val blockPaint = Paint().apply { color = Color.rgb(0, 121, 107) }
    private val stripePaint = Paint().apply { color = Color.argb(70, 255, 255, 255) }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 13f * density
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(160, 160, 160)
        textSize = 13f * density
        textAlign = Paint.Align.CENTER
    }
    private val playheadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 4f
    }

    fun setMusic(name: String) {
        musicName = name
        invalidate()
    }

    fun clearMusic() {
        musicName = null
        invalidate()
    }

    fun setDuration(newDurationMs: Long) {
        if (newDurationMs > 0) durationMs = newDurationMs
        invalidate()
    }

    fun setPosition(newPositionMs: Long) {
        positionMs = newPositionMs
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, h, bgPaint)
        val name = musicName
        if (name == null) {
            canvas.drawText("♪  သီချင်းထည့်ရန် နှိပ်ပါ", w / 2f, h / 2f + 6f * density, hintPaint)
            return
        }
        canvas.drawRect(0f, 0f, w, h, blockPaint)
        var x = 0f
        while (x < w) {
            canvas.drawRect(x, h * 0.2f, x + 6f * density, h * 0.8f, stripePaint)
            x += 28f * density
        }
        val label = "♪ $name  •  LOOP"
        canvas.drawText(label, 12f * density, h / 2f + 6f * density, textPaint)
        if (durationMs > 0) {
            val px = positionMs.toFloat() / durationMs * w
            canvas.drawLine(px, 0f, px, h, playheadPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (musicName == null) {
            if (event.action == MotionEvent.ACTION_DOWN) {
                onAddMusic?.invoke()
                return true
            }
            return super.onTouchEvent(event)
        }
        if (durationMs <= 0) return super.onTouchEvent(event)
        if (event.action == MotionEvent.ACTION_DOWN ||
            event.action == MotionEvent.ACTION_MOVE
        ) {
            val fraction = (event.x / width.toFloat()).coerceIn(0f, 1f)
            val target = (fraction * durationMs).toInt()
            onSeekTo?.invoke(target)
            setPosition(target.toLong())
            return true
        }
        return super.onTouchEvent(event)
    }
}
