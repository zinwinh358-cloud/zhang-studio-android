package com.zhangstudio.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.abs

/**
 * One background-music clip on the timeline (v0.7.0): the song plays
 * from [offsetUs] while the playhead is inside [startUs, endUs].
 * Times are microseconds on the video timeline (start/end) and inside
 * the song file (offset).
 */
data class MusicClip(val startUs: Long, val endUs: Long, val offsetUs: Long)

/**
 * Second ticks + time labels above the editor tracks. The label step
 * adapts to the video length so labels never overlap.
 */
class TimeRulerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var durationMs: Long = 0L
    private val density = context.resources.displayMetrics.density

    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(180, 180, 180)
        strokeWidth = 2f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(220, 220, 220)
        textSize = 11f * density
    }

    fun setDuration(newDurationMs: Long) {
        if (newDurationMs > 0) durationMs = newDurationMs
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (durationMs <= 0) return
        val w = width.toFloat()
        val h = height.toFloat()
        val totalSecs = durationMs / 1000
        if (totalSecs <= 0) return
        val (labelStep, tickStep) = when {
            totalSecs <= 60 -> 5L to 1L
            totalSecs <= 300 -> 30L to 5L
            else -> 60L to 10L
        }
        var sec = 0L
        while (sec <= totalSecs) {
            val x = sec.toFloat() / totalSecs * w
            val isLabel = sec % labelStep == 0L
            val top = if (isLabel) h * 0.65f else h * 0.8f
            canvas.drawLine(x, top, x, h, tickPaint)
            if (isLabel) {
                val label = "%d:%02d".format(sec / 60, sec % 60)
                canvas.drawText(label, x + 4f, h * 0.5f, textPaint)
            }
            sec += tickStep
        }
    }
}

/**
 * The video clip strip on the timeline: frame thumbnails grabbed in the
 * background (a plain labelled block if grabbing fails), with a
 * playhead. Tapping or dragging seeks the preview. All tracks share
 * the same left edge, so the playheads line up vertically.
 */
class VideoStripView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var onSeekTo: ((Int) -> Unit)? = null
    var onSelect: ((Int) -> Unit)? = null
    // v0.8.1: fired when an edge-trim drag ends: (index, newStartUs, newEndUs).
    var onSegmentResized: ((Int, Long, Long) -> Unit)? = null

    private var durationMs: Long = 0L
    private var positionMs: Long = 0L
    private var hasVideo: Boolean = false
    private var frames: List<Bitmap> = emptyList()
    private var generation: Int = 0
    // v0.7.0: kept source-time segments (microseconds) + selection.
    private var segments: List<Pair<Long, Long>> = emptyList()
    private var selectedIndex: Int = -1
    // v0.8.1: edge-trim drag state (mirrors SrtTrackView).
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private var pendingIndex: Int = -1
    private var downX: Float = 0f
    private var dragging: Boolean = false
    private var dragMode: Int = 0 // 2 = left edge, 3 = right edge
    private var dragIndex: Int = -1
    private var dragOrigStartUs: Long = 0L
    private var dragOrigEndUs: Long = 0L
    private var dragStartUs: Long = 0L
    private var dragEndUs: Long = 0L
    private val density = context.resources.displayMetrics.density

    private val bgPaint = Paint().apply { color = Color.rgb(38, 50, 56) }
    private val tintPaint = Paint().apply { color = Color.argb(60, 0, 0, 0) }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(72, 199, 214)
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val gapPaint = Paint().apply { color = Color.argb(190, 0, 0, 0) }
    private val boundaryPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 3f
    }
    private val selectPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        // v0.9.4: white selection border + handles (CapCut style).
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }
    // v0.9.4: white trim handles (CapCut style; was yellow).
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
    }
    private val labelBgPaint = Paint().apply { color = Color.argb(170, 0, 0, 0) }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 13f * density
        textAlign = Paint.Align.CENTER
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(160, 160, 160)
        textSize = 13f * density
        textAlign = Paint.Align.CENTER
    }
    private val playheadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 4f
    }

    fun setVideo(uri: Uri, newDurationMs: Long) {
        hasVideo = true
        if (newDurationMs > 0) durationMs = newDurationMs
        frames = emptyList()
        invalidate()
        val gen = ++generation
        Thread {
            val grabbed = grabFrames(uri)
            post {
                if (gen == generation) {
                    frames = grabbed
                    invalidate()
                }
            }
        }.start()
    }

    /** v0.6.24: forget the video — thumbnails and playhead reset. */
    fun clear() {
        hasVideo = false
        frames = emptyList()
        positionMs = 0L
        segments = emptyList()
        selectedIndex = -1
        dragging = false
        dragIndex = -1
        pendingIndex = -1
        generation++
        invalidate()
    }

    /** v0.7.0: kept source-time segments (microseconds). */
    fun setSegments(newSegments: List<Pair<Long, Long>>) {
        segments = newSegments
        if (selectedIndex >= segments.size) selectedIndex = -1
        invalidate()
    }

    fun setSelectedIndex(index: Int) {
        selectedIndex = index
        invalidate()
    }

    fun setDuration(newDurationMs: Long) {
        if (newDurationMs > 0) durationMs = newDurationMs
        invalidate()
    }

    fun setPosition(newPositionMs: Long) {
        positionMs = newPositionMs
        invalidate()
    }

    private fun grabFrames(uri: Uri): List<Bitmap> {
        val out = mutableListOf<Bitmap>()
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val durUs = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull()?.times(1_000L) ?: (durationMs * 1_000L)
            if (durUs <= 0) return emptyList()
            // v0.8.0: one thumbnail per ~5s, so long videos keep
            // a readable strip in the scrolling timeline.
            val count = (durUs / 5_000_000L).toInt().coerceIn(8, 64)
            for (i in 0 until count) {
                val t = durUs * (i * 2 + 1) / (count * 2)
                val bmp = retriever.getFrameAtTime(
                    t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                ) ?: continue
                val scaled = Bitmap.createScaledBitmap(
                    bmp, 160,
                    (160f * bmp.height / bmp.width).toInt().coerceAtLeast(1), false
                )
                if (scaled !== bmp) bmp.recycle()
                out.add(scaled)
            }
        } catch (e: Exception) {
            // Frame grab failed — the fallback block still shows.
        } finally {
            try {
                retriever.release()
            } catch (e: Exception) {
            }
        }
        return out
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, h, bgPaint)
        if (!hasVideo) {
            canvas.drawText("No video picked", w / 2f, h / 2f + 6f * density, hintPaint)
            return
        }
        if (frames.isNotEmpty()) {
            val slotW = w / frames.size
            val src = Rect()
            val dst = RectF()
            for ((i, bmp) in frames.withIndex()) {
                src.set(0, 0, bmp.width, bmp.height)
                dst.set(i * slotW, 0f, (i + 1) * slotW, h)
                canvas.drawBitmap(bmp, src, dst, null)
            }
            canvas.drawRect(0f, 0f, w, h, tintPaint)
        } else {
            val label = "Video — ${formatMs(durationMs)}"
            canvas.drawText(label, w / 2f, h / 2f + 6f * density, textPaint)
        }
        canvas.drawRect(1f, 1f, w - 1f, h - 1f, borderPaint)
        // v0.7.0: darken deleted ranges, draw cut lines + selection.
        if (durationMs > 0 && segments.isNotEmpty()) {
            val totalUs = durationMs * 1_000L
            var cursor = 0L
            for ((i, seg) in segments.withIndex()) {
                // v0.8.1: the dragged segment draws at its preview bounds.
                val s = if (i == dragIndex && dragging) dragStartUs else seg.first
                val e = if (i == dragIndex && dragging) dragEndUs else seg.second
                if (s > cursor) {
                    canvas.drawRect(
                        cursor.toFloat() / totalUs * w, 0f,
                        s.toFloat() / totalUs * w, h, gapPaint
                    )
                }
                if (s > 0L) {
                    val x = s.toFloat() / totalUs * w
                    canvas.drawLine(x, 0f, x, h, boundaryPaint)
                }
                if (e < totalUs) {
                    val x = e.toFloat() / totalUs * w
                    canvas.drawLine(x, 0f, x, h, boundaryPaint)
                }
                if (e > cursor) cursor = e
            }
            if (cursor < totalUs) {
                canvas.drawRect(
                    cursor.toFloat() / totalUs * w, 0f, w, h, gapPaint
                )
            }
            if (selectedIndex in segments.indices) {
                val (os, oe) = segments[selectedIndex]
                val s = if (selectedIndex == dragIndex && dragging) dragStartUs else os
                val e = if (selectedIndex == dragIndex && dragging) dragEndUs else oe
                val left = s.toFloat() / totalUs * w
                val right = e.toFloat() / totalUs * w
                canvas.drawRect(left, 2f, right, h - 2f, selectPaint)
                // v0.9.4: white trim handles on the selected segment.
                val hw = 8f * density
                canvas.drawRect(left, 0f, left + hw, h, handlePaint)
                canvas.drawRect(right - hw, 0f, right, h, handlePaint)
                // v0.9.4: duration label on the selected segment
                // (CapCut shows "1.6s" on the selected clip).
                val durLabel = "%.1fs".format((e - s) / 1_000_000f)
                val tw = textPaint.measureText(durLabel)
                val pillW = tw + 16f * density
                if (right - left >= pillW) {
                    val cx = (left + right) / 2f
                    val top = 2f
                    canvas.drawRect(
                        cx - pillW / 2f, top, cx + pillW / 2f,
                        top + 22f * density, labelBgPaint
                    )
                    canvas.drawText(durLabel, cx, top + 16f * density, textPaint)
                }
            }
        }
        // v0.9.4: total duration on the first thumbnail (CapCut).
        // v0.9.5: bottom-left — the top-left overlapped the
        // selected segment's duration pill.
        if (durationMs > 0) {
            val totalLabel = formatMs(durationMs)
            val tw = textPaint.measureText(totalLabel)
            val left = 4f * density
            canvas.drawRect(
                left, h - 22f * density, left + tw + 12f * density,
                h - 2f, labelBgPaint
            )
            canvas.drawText(
                totalLabel, left + 6f * density + tw / 2f,
                h - 7f * density, textPaint
            )
        }
        if (durationMs > 0) {
            val px = positionMs.toFloat() / durationMs * w
            canvas.drawLine(px, 0f, px, h, playheadPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (durationMs <= 0) return super.onTouchEvent(event)
        val totalUs = durationMs * 1_000L
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                val fraction = (event.x / width.toFloat()).coerceIn(0f, 1f)
                val target = (fraction * durationMs).toInt()
                val targetUs = target.toLong() * 1_000L
                val index = segments.indexOfFirst {
                    targetUs >= it.first && targetUs < it.second
                }
                downX = event.x
                pendingIndex = index
                dragging = false
                dragMode = 0
                if (index >= 0) {
                    // v0.9.2: claim the gesture NOW (same timeline
                    // scroll-steal fix as the subtitle track).
                    parent?.requestDisallowInterceptTouchEvent(true)
                    // Select now; seek waits for UP so a trim drag
                    // doesn't yank the playhead around.
                    onSelect?.invoke(index)
                } else {
                    onSeekTo?.invoke(target)
                    setPosition(target.toLong())
                    onSelect?.invoke(-1)
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (pendingIndex >= 0 && !dragging &&
                    abs(event.x - downX) > touchSlop
                ) {
                    val (os, oe) = segments[pendingIndex]
                    val w = width.toFloat()
                    val left = os.toFloat() / totalUs * w
                    val right = oe.toFloat() / totalUs * w
                    // v0.9.2: edge zones shrink on tiny segments.
                    val edge = minOf(
                        14f * density,
                        maxOf(4f * density, (right - left) / 3f)
                    )
                    dragMode = when {
                        downX <= left + edge -> 2
                        downX >= right - edge -> 3
                        else -> 0
                    }
                    if (dragMode != 0) {
                        dragging = true
                        dragIndex = pendingIndex
                        dragOrigStartUs = os
                        dragOrigEndUs = oe
                        dragStartUs = os
                        dragEndUs = oe
                        parent?.requestDisallowInterceptTouchEvent(true)
                    }
                }
                if (dragging) {
                    val deltaUs =
                        ((event.x - downX) / width.toFloat() * totalUs).toLong()
                    val minDurUs = 500_000L
                    val prevEnd =
                        if (dragIndex > 0) segments[dragIndex - 1].second else 0L
                    val nextStart =
                        if (dragIndex < segments.size - 1) segments[dragIndex + 1].first
                        else totalUs
                    when (dragMode) {
                        2 -> {
                            dragStartUs = (dragOrigStartUs + deltaUs).coerceIn(
                                prevEnd, maxOf(prevEnd, dragOrigEndUs - minDurUs)
                            )
                            dragEndUs = dragOrigEndUs
                        }
                        3 -> {
                            dragStartUs = dragOrigStartUs
                            dragEndUs = (dragOrigEndUs + deltaUs).coerceIn(
                                minOf(dragOrigStartUs + minDurUs, nextStart), nextStart
                            )
                        }
                    }
                    invalidate()
                } else {
                    // Drag-to-seek (empty track, or a segment's middle).
                    val fraction = (event.x / width.toFloat()).coerceIn(0f, 1f)
                    val target = (fraction * durationMs).toInt()
                    onSeekTo?.invoke(target)
                    setPosition(target.toLong())
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    if (event.action == MotionEvent.ACTION_UP) {
                        onSegmentResized?.invoke(dragIndex, dragStartUs, dragEndUs)
                    }
                    dragging = false
                    dragMode = 0
                    dragIndex = -1
                    invalidate()
                } else if (pendingIndex >= 0 &&
                    event.action == MotionEvent.ACTION_UP
                ) {
                    // A tap on a segment: seek (selection set on DOWN).
                    val fraction = (event.x / width.toFloat()).coerceIn(0f, 1f)
                    val target = (fraction * durationMs).toInt()
                    onSeekTo?.invoke(target)
                    setPosition(target.toLong())
                }
                pendingIndex = -1
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun formatMs(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }
}

/**
 * The background-music track: empty it invites a tap to pick music;
 * filled it shows the music clips (v0.7.0: split/deletable ranges of
 * the song, gaps stay silent). Tapping a clip selects it; tapping or
 * dragging seeks the preview.
 *
 * v0.9.2: VN-style clip dragging — drag a clip's middle to move it,
 * drag its edges to stretch it (the song offset follows the left
 * edge, so the music stays in sync with the clip).
 */
class MusicTrackView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var onSeekTo: ((Int) -> Unit)? = null
    var onAddMusic: (() -> Unit)? = null
    var onSelect: ((Int) -> Unit)? = null
    // v0.9.2: fired when a clip drag ends:
    // (index, newStartUs, newEndUs, newOffsetUs).
    var onMusicClipMoved: ((Int, Long, Long, Long) -> Unit)? = null

    private var durationMs: Long = 0L
    private var positionMs: Long = 0L
    private var clips: List<MusicClip> = emptyList()
    private var musicName: String? = null
    private var selectedIndex: Int = -1
    private val density = context.resources.displayMetrics.density

    // v0.9.2: drag state (mirrors SrtTrackView).
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private var pendingIndex: Int = -1
    private var downX: Float = 0f
    private var dragging: Boolean = false
    private var dragMode: Int = 0 // 1 = move, 2 = left edge, 3 = right edge
    private var dragIndex: Int = -1
    private var dragOrigStartUs: Long = 0L
    private var dragOrigEndUs: Long = 0L
    private var dragOrigOffsetUs: Long = 0L
    private var dragStartUs: Long = 0L
    private var dragEndUs: Long = 0L
    private var dragOffsetUs: Long = 0L

    private val bgPaint = Paint().apply { color = Color.rgb(30, 30, 30) }
    private val blockPaint = Paint().apply { color = Color.rgb(0, 121, 107) }
    private val stripePaint = Paint().apply { color = Color.argb(70, 255, 255, 255) }
    private val boundaryPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 3f
    }
    private val selectPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 213, 74)
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }
    // v0.9.2: yellow grab handles on the selected clip (#FFD600).
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 214, 0)
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 13f * density
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(160, 160, 160)
        textSize = 13f * density
        textAlign = Paint.Align.CENTER
    }
    private val playheadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 4f
    }

    /** v0.7.0: the clips on the timeline + the song name for the label. */
    fun setClips(newClips: List<MusicClip>, name: String?) {
        clips = newClips
        musicName = name
        if (selectedIndex >= clips.size) selectedIndex = -1
        invalidate()
    }

    fun clearMusic() {
        clips = emptyList()
        musicName = null
        selectedIndex = -1
        dragging = false
        dragIndex = -1
        pendingIndex = -1
        invalidate()
    }

    fun setSelectedIndex(index: Int) {
        selectedIndex = index
        invalidate()
    }

    fun setDuration(newDurationMs: Long) {
        if (newDurationMs > 0) durationMs = newDurationMs
        invalidate()
    }

    fun setPosition(newPositionMs: Long) {
        positionMs = newPositionMs
        invalidate()
    }

    private fun axisEndMs(): Long {
        if (durationMs > 0) return durationMs
        return clips.maxOfOrNull { it.endUs / 1_000L } ?: 0L
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, h, bgPaint)
        if (clips.isEmpty()) {
            canvas.drawText("♪  Tap to add music", w / 2f, h / 2f + 6f * density, hintPaint)
            return
        }
        val axisMs = axisEndMs()
        if (axisMs <= 0) return
        for ((i, clip) in clips.withIndex()) {
            // v0.9.2: the dragged clip draws at its preview bounds.
            val sUs = if (i == dragIndex && dragging) dragStartUs else clip.startUs
            val eUs = if (i == dragIndex && dragging) dragEndUs else clip.endUs
            val left = sUs / 1_000f / axisMs * w
            val right = eUs / 1_000f / axisMs * w
            canvas.drawRect(left, 0f, right, h, blockPaint)
            var x = left
            while (x < right) {
                canvas.drawRect(
                    x, h * 0.2f,
                    minOf(x + 6f * density, right), h * 0.8f, stripePaint
                )
                x += 28f * density
            }
            if (clip.startUs > 0L) {
                canvas.drawLine(left, 0f, left, h, boundaryPaint)
            }
            if (i == selectedIndex) {
                canvas.drawRect(left + 2f, 2f, right - 2f, h - 2f, selectPaint)
                // v0.9.2: yellow grab handles on the selected clip.
                val hw = 8f * density
                canvas.drawRect(left, 0f, left + hw, h, handlePaint)
                canvas.drawRect(right - hw, 0f, right, h, handlePaint)
            }
        }
        val name = musicName
        if (name != null && clips.isNotEmpty()) {
            val first = clips.first()
            val left = first.startUs / 1_000f / axisMs * w
            canvas.drawText("♪ $name", left + 12f * density, h / 2f + 6f * density, textPaint)
        }
        if (durationMs > 0) {
            val px = positionMs.toFloat() / durationMs * w
            canvas.drawLine(px, 0f, px, h, playheadPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (clips.isEmpty()) {
            if (event.action == MotionEvent.ACTION_DOWN) {
                onAddMusic?.invoke()
                return true
            }
            return super.onTouchEvent(event)
        }
        val axisMs = axisEndMs()
        if (axisMs <= 0) return super.onTouchEvent(event)
        val axisUs = axisMs * 1_000L
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                val fraction = (event.x / width.toFloat()).coerceIn(0f, 1f)
                val target = (fraction * axisMs).toInt()
                val targetUs = target.toLong() * 1_000L
                val index = clips.indexOfFirst {
                    targetUs >= it.startUs && targetUs < it.endUs
                }
                downX = event.x
                pendingIndex = index
                dragging = false
                dragMode = 0
                if (index >= 0) {
                    // Claim the gesture now: the scrolling timeline
                    // would otherwise steal horizontal drags.
                    parent?.requestDisallowInterceptTouchEvent(true)
                    onSelect?.invoke(index)
                } else {
                    onSeekTo?.invoke(target)
                    setPosition(target.toLong())
                    onSelect?.invoke(-1)
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (pendingIndex >= 0 && !dragging &&
                    abs(event.x - downX) > touchSlop
                ) {
                    val clip = clips[pendingIndex]
                    val w = width.toFloat()
                    val left = clip.startUs / 1_000f / axisMs * w
                    val right = clip.endUs / 1_000f / axisMs * w
                    val edge = minOf(
                        18f * density,
                        maxOf(4f * density, (right - left) / 3f)
                    )
                    dragMode = when {
                        downX <= left + edge -> 2
                        downX >= right - edge -> 3
                        else -> 1
                    }
                    dragging = true
                    dragIndex = pendingIndex
                    dragOrigStartUs = clip.startUs
                    dragOrigEndUs = clip.endUs
                    dragOrigOffsetUs = clip.offsetUs
                    dragStartUs = clip.startUs
                    dragEndUs = clip.endUs
                    dragOffsetUs = clip.offsetUs
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
                if (dragging) {
                    val deltaUs =
                        ((event.x - downX) / width.toFloat() * axisUs).toLong()
                    val minDurUs = 500_000L
                    val sorted = clips.sortedBy { it.startUs }
                    val pos = sorted.indexOf(clips[dragIndex])
                    val prevEnd =
                        if (pos > 0) sorted[pos - 1].endUs else 0L
                    val nextStart =
                        if (pos < sorted.size - 1) sorted[pos + 1].startUs
                        else axisUs
                    when (dragMode) {
                        1 -> {
                            val dur = dragOrigEndUs - dragOrigStartUs
                            val maxStart =
                                maxOf(prevEnd, minOf(nextStart - dur, axisUs - dur))
                            dragStartUs = (dragOrigStartUs + deltaUs)
                                .coerceIn(prevEnd, maxOf(prevEnd, maxStart))
                            dragEndUs = dragStartUs + dur
                            dragOffsetUs = dragOrigOffsetUs
                        }
                        2 -> {
                            // Left edge: the song offset follows, so
                            // the music stays in sync with the clip.
                            val offsetFloor =
                                dragOrigStartUs - dragOrigOffsetUs
                            val lo = maxOf(prevEnd, offsetFloor)
                            val hi = maxOf(lo, dragOrigEndUs - minDurUs)
                            dragStartUs =
                                (dragOrigStartUs + deltaUs).coerceIn(lo, hi)
                            dragEndUs = dragOrigEndUs
                            dragOffsetUs = dragOrigOffsetUs +
                                (dragStartUs - dragOrigStartUs)
                        }
                        3 -> {
                            dragStartUs = dragOrigStartUs
                            dragEndUs = (dragOrigEndUs + deltaUs).coerceIn(
                                minOf(dragOrigStartUs + minDurUs, nextStart),
                                nextStart
                            )
                            dragOffsetUs = dragOrigOffsetUs
                        }
                    }
                    invalidate()
                } else if (pendingIndex < 0) {
                    // Drag-to-seek on empty track (existing behavior).
                    val fraction = (event.x / width.toFloat()).coerceIn(0f, 1f)
                    val target = (fraction * axisMs).toInt()
                    onSeekTo?.invoke(target)
                    setPosition(target.toLong())
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    if (event.action == MotionEvent.ACTION_UP) {
                        onMusicClipMoved?.invoke(
                            dragIndex, dragStartUs, dragEndUs, dragOffsetUs
                        )
                    }
                    dragging = false
                    dragMode = 0
                    dragIndex = -1
                    invalidate()
                } else if (pendingIndex >= 0 &&
                    event.action == MotionEvent.ACTION_UP
                ) {
                    // A tap on a clip: seek (selection set on DOWN).
                    val fraction = (event.x / width.toFloat()).coerceIn(0f, 1f)
                    val target = (fraction * axisMs).toInt()
                    onSeekTo?.invoke(target)
                    setPosition(target.toLong())
                }
                pendingIndex = -1
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}

/**
 * One photo overlay (sticker) on the timeline (v0.9.4): the photo
 * shows on the video while the playhead is inside [startUs, endUs].
 * [xFrac]/[yFrac] are the photo center as fractions of the frame;
 * [scale] is the photo width as a fraction of the frame width.
 * Times are microseconds on the video timeline.
 */
data class OverlayClip(
    val uri: Uri,
    val startUs: Long,
    val endUs: Long,
    val xFrac: Float = 0.5f,
    val yFrac: Float = 0.5f,
    val scale: Float = 0.5f
)

/**
 * The sticker/overlay track (v0.9.4): empty it invites a tap to add
 * a photo; filled it shows the photo clips with thumbnails.
 * Tapping a clip selects it; dragging moves/stretches it (mirrors
 * MusicTrackView, without the song offset). Tapping or dragging on
 * empty space seeks the preview.
 */
class OverlayTrackView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var onSeekTo: ((Int) -> Unit)? = null
    var onAddOverlay: (() -> Unit)? = null
    var onSelect: ((Int) -> Unit)? = null
    // Fired when a clip drag ends: (index, newStartUs, newEndUs).
    var onOverlayClipMoved: ((Int, Long, Long) -> Unit)? = null

    private var durationMs: Long = 0L
    private var positionMs: Long = 0L
    private var clips: List<OverlayClip> = emptyList()
    private var selectedIndex: Int = -1
    private val density = context.resources.displayMetrics.density
    private val thumbs = mutableMapOf<Uri, Bitmap>()
    private val loadingThumbs = mutableSetOf<Uri>()

    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private var pendingIndex: Int = -1
    private var downX: Float = 0f
    private var dragging: Boolean = false
    private var dragMode: Int = 0 // 1 = move, 2 = left edge, 3 = right edge
    private var dragIndex: Int = -1
    private var dragOrigStartUs: Long = 0L
    private var dragOrigEndUs: Long = 0L
    private var dragStartUs: Long = 0L
    private var dragEndUs: Long = 0L

    private val bgPaint = Paint().apply { color = Color.rgb(30, 30, 30) }
    private val blockPaint = Paint().apply { color = Color.rgb(55, 71, 79) }
    private val tintPaint = Paint().apply { color = Color.argb(50, 0, 0, 0) }
    private val boundaryPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 3f
    }
    private val selectPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 213, 74)
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 214, 0)
    }
    private val labelBgPaint = Paint().apply { color = Color.argb(170, 0, 0, 0) }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 13f * density
        textAlign = Paint.Align.CENTER
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(160, 160, 160)
        textSize = 13f * density
        textAlign = Paint.Align.CENTER
    }
    private val playheadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 4f
    }

    fun setClips(newClips: List<OverlayClip>) {
        clips = newClips
        if (selectedIndex >= clips.size) selectedIndex = -1
        for (clip in clips) loadThumb(clip.uri)
        invalidate()
    }

    fun clearOverlays() {
        clips = emptyList()
        selectedIndex = -1
        dragging = false
        dragIndex = -1
        pendingIndex = -1
        invalidate()
    }

    fun setSelectedIndex(index: Int) {
        selectedIndex = index
        invalidate()
    }

    fun setDuration(newDurationMs: Long) {
        if (newDurationMs > 0) durationMs = newDurationMs
        invalidate()
    }

    fun setPosition(newPositionMs: Long) {
        positionMs = newPositionMs
        invalidate()
    }

    private fun axisEndMs(): Long {
        if (durationMs > 0) return durationMs
        return clips.maxOfOrNull { it.endUs / 1_000L } ?: 0L
    }

    private fun loadThumb(uri: Uri) {
        if (thumbs.containsKey(uri) || loadingThumbs.contains(uri)) return
        loadingThumbs.add(uri)
        Thread {
            try {
                val bounds = android.graphics.BitmapFactory.Options().apply {
                    inJustDecodeBounds = true
                }
                context.contentResolver.openInputStream(uri)?.use {
                    android.graphics.BitmapFactory.decodeStream(it, null, bounds)
                }
                var sample = 1
                while (bounds.outWidth / sample > 160 && sample < 64) sample *= 2
                val opts = android.graphics.BitmapFactory.Options().apply {
                    inSampleSize = sample
                }
                val bmp = context.contentResolver.openInputStream(uri)?.use {
                    android.graphics.BitmapFactory.decodeStream(it, null, opts)
                }
                if (bmp != null) {
                    post {
                        thumbs[uri] = bmp
                        loadingThumbs.remove(uri)
                        invalidate()
                    }
                } else {
                    loadingThumbs.remove(uri)
                }
            } catch (e: Exception) {
                loadingThumbs.remove(uri)
            }
        }.start()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, h, bgPaint)
        if (clips.isEmpty()) {
            canvas.drawText(
                "🖼️  Tap to add sticker / Overlay",
                w / 2f, h / 2f + 6f * density, hintPaint
            )
            return
        }
        val axisMs = axisEndMs()
        if (axisMs <= 0) return
        for ((i, clip) in clips.withIndex()) {
            val sUs = if (i == dragIndex && dragging) dragStartUs else clip.startUs
            val eUs = if (i == dragIndex && dragging) dragEndUs else clip.endUs
            val left = sUs / 1_000f / axisMs * w
            val right = eUs / 1_000f / axisMs * w
            canvas.drawRect(left, 0f, right, h, blockPaint)
            val thumb = thumbs[clip.uri]
            if (thumb != null) {
                // Center-crop the thumbnail into the clip rect.
                val src = Rect()
                val dst = RectF(left, 0f, right, h)
                val clipAspect = (right - left) / h
                val bmpAspect = thumb.width.toFloat() / thumb.height
                if (bmpAspect > clipAspect) {
                    val sw = (thumb.height * clipAspect).toInt()
                    val sx = (thumb.width - sw) / 2
                    src.set(sx, 0, sx + sw, thumb.height)
                } else {
                    val sh = (thumb.width / clipAspect).toInt()
                    val sy = (thumb.height - sh) / 2
                    src.set(0, sy, thumb.width, sy + sh)
                }
                canvas.drawBitmap(thumb, src, dst, null)
                canvas.drawRect(left, 0f, right, h, tintPaint)
            }
            if (clip.startUs > 0L) {
                canvas.drawLine(left, 0f, left, h, boundaryPaint)
            }
            if (i == selectedIndex) {
                canvas.drawRect(left + 2f, 2f, right - 2f, h - 2f, selectPaint)
                val hw = 8f * density
                canvas.drawRect(left, 0f, left + hw, h, handlePaint)
                canvas.drawRect(right - hw, 0f, right, h, handlePaint)
                val durLabel = "%.1fs".format((eUs - sUs) / 1_000_000f)
                val tw = textPaint.measureText(durLabel)
                val pillW = tw + 16f * density
                if (right - left >= pillW) {
                    val cx = (left + right) / 2f
                    canvas.drawRect(
                        cx - pillW / 2f, 2f, cx + pillW / 2f,
                        2f + 22f * density, labelBgPaint
                    )
                    canvas.drawText(durLabel, cx, 2f + 16f * density, textPaint)
                }
            }
        }
        if (durationMs > 0) {
            val px = positionMs.toFloat() / durationMs * w
            canvas.drawLine(px, 0f, px, h, playheadPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (clips.isEmpty()) {
            if (event.action == MotionEvent.ACTION_DOWN) {
                onAddOverlay?.invoke()
                return true
            }
            return super.onTouchEvent(event)
        }
        val axisMs = axisEndMs()
        if (axisMs <= 0) return super.onTouchEvent(event)
        val axisUs = axisMs * 1_000L
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                val fraction = (event.x / width.toFloat()).coerceIn(0f, 1f)
                val target = (fraction * axisMs).toInt()
                val targetUs = target.toLong() * 1_000L
                val index = clips.indexOfFirst {
                    targetUs >= it.startUs && targetUs < it.endUs
                }
                downX = event.x
                pendingIndex = index
                dragging = false
                dragMode = 0
                if (index >= 0) {
                    // Claim the gesture now: the scrolling timeline
                    // would otherwise steal horizontal drags.
                    parent?.requestDisallowInterceptTouchEvent(true)
                    onSelect?.invoke(index)
                } else {
                    onSeekTo?.invoke(target)
                    setPosition(target.toLong())
                    onSelect?.invoke(-1)
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (pendingIndex >= 0 && !dragging &&
                    abs(event.x - downX) > touchSlop
                ) {
                    val clip = clips[pendingIndex]
                    val w = width.toFloat()
                    val left = clip.startUs / 1_000f / axisMs * w
                    val right = clip.endUs / 1_000f / axisMs * w
                    val edge = minOf(
                        18f * density,
                        maxOf(4f * density, (right - left) / 3f)
                    )
                    dragMode = when {
                        downX <= left + edge -> 2
                        downX >= right - edge -> 3
                        else -> 1
                    }
                    dragging = true
                    dragIndex = pendingIndex
                    dragOrigStartUs = clip.startUs
                    dragOrigEndUs = clip.endUs
                    dragStartUs = clip.startUs
                    dragEndUs = clip.endUs
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
                if (dragging) {
                    val deltaUs =
                        ((event.x - downX) / width.toFloat() * axisUs).toLong()
                    val minDurUs = 500_000L
                    val sorted = clips.sortedBy { it.startUs }
                    val pos = sorted.indexOf(clips[dragIndex])
                    val prevEnd =
                        if (pos > 0) sorted[pos - 1].endUs else 0L
                    val nextStart =
                        if (pos < sorted.size - 1) sorted[pos + 1].startUs
                        else axisUs
                    when (dragMode) {
                        1 -> {
                            val dur = dragOrigEndUs - dragOrigStartUs
                            val maxStart =
                                maxOf(prevEnd, minOf(nextStart - dur, axisUs - dur))
                            dragStartUs = (dragOrigStartUs + deltaUs)
                                .coerceIn(prevEnd, maxOf(prevEnd, maxStart))
                            dragEndUs = dragStartUs + dur
                        }
                        2 -> {
                            dragStartUs = (dragOrigStartUs + deltaUs).coerceIn(
                                prevEnd, maxOf(prevEnd, dragOrigEndUs - minDurUs)
                            )
                            dragEndUs = dragOrigEndUs
                        }
                        3 -> {
                            dragStartUs = dragOrigStartUs
                            dragEndUs = (dragOrigEndUs + deltaUs).coerceIn(
                                minOf(dragOrigStartUs + minDurUs, nextStart),
                                nextStart
                            )
                        }
                    }
                    invalidate()
                } else if (pendingIndex < 0) {
                    val fraction = (event.x / width.toFloat()).coerceIn(0f, 1f)
                    val target = (fraction * axisMs).toInt()
                    onSeekTo?.invoke(target)
                    setPosition(target.toLong())
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    if (event.action == MotionEvent.ACTION_UP) {
                        onOverlayClipMoved?.invoke(dragIndex, dragStartUs, dragEndUs)
                    }
                    dragging = false
                    dragMode = 0
                    dragIndex = -1
                    invalidate()
                } else if (pendingIndex >= 0 &&
                    event.action == MotionEvent.ACTION_UP
                ) {
                    val fraction = (event.x / width.toFloat()).coerceIn(0f, 1f)
                    val target = (fraction * axisMs).toInt()
                    onSeekTo?.invoke(target)
                    setPosition(target.toLong())
                }
                pendingIndex = -1
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}
