package com.zhangstudio.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.abs

/**
 * One background-music clip on the timeline (v0.7.0): the song plays
 * from [offsetUs] while the playhead is inside [startUs, endUs].
 * Times are microseconds on the video timeline (start/end) and inside
 * the song file (offset).
 */
data class MusicClip(val startUs: Long, val endUs: Long, val offsetUs: Long)

/**
 * Second ticks + time labels above the editor tracks. The label step
 * adapts to the video length so labels never overlap.
 */
class TimeRulerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var durationMs: Long = 0L
    private val density = context.resources.displayMetrics.density

    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(180, 180, 180)
        strokeWidth = 2f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(220, 220, 220)
        textSize = 11f * density
    }

    fun setDuration(newDurationMs: Long) {
        if (newDurationMs > 0) durationMs = newDurationMs
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (durationMs <= 0) return
        val w = width.toFloat()
        val h = height.toFloat()
        val totalSecs = durationMs / 1000
        if (totalSecs <= 0) return
        val (labelStep, tickStep) = when {
            totalSecs <= 60 -> 5L to 1L
            totalSecs <= 300 -> 30L to 5L
            else -> 60L to 10L
        }
        var sec = 0L
        while (sec <= totalSecs) {
            val x = sec.toFloat() / totalSecs * w
            val isLabel = sec % labelStep == 0L
            val top = if (isLabel) h * 0.65f else h * 0.8f
            canvas.drawLine(x, top, x, h, tickPaint)
            if (isLabel) {
                val label = "%d:%02d".format(sec / 60, sec % 60)
                canvas.drawText(label, x + 4f, h * 0.5f, textPaint)
            }
            sec += tickStep
        }
    }
}

/**
 * The video clip strip on the timeline: frame thumbnails grabbed in the
 * background (a plain labelled block if grabbing fails), with a
 * playhead. Tapping or dragging seeks the preview. All tracks share
 * the same left edge, so the playheads line up vertically.
 */
class VideoStripView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var onSeekTo: ((Int) -> Unit)? = null
    var onSelect: ((Int) -> Unit)? = null
    // v0.8.1: fired when an edge-trim drag ends: (index, newStartUs, newEndUs).
    var onSegmentResized: ((Int, Long, Long) -> Unit)? = null

    private var durationMs: Long = 0L
    private var positionMs: Long = 0L
    private var hasVideo: Boolean = false
    private var frames: List<Bitmap> = emptyList()
    private var generation: Int = 0
    // v0.7.0: kept source-time segments (microseconds) + selection.
    private var segments: List<Pair<Long, Long>> = emptyList()
    private var selectedIndex: Int = -1
    // v0.8.1: edge-trim drag state (mirrors SrtTrackView).
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private var pendingIndex: Int = -1
    private var downX: Float = 0f
    private var dragging: Boolean = false
    private var dragMode: Int = 0 // 2 = left edge, 3 = right edge
    private var dragIndex: Int = -1
    private var dragOrigStartUs: Long = 0L
    private var dragOrigEndUs: Long = 0L
    private var dragStartUs: Long = 0L
    private var dragEndUs: Long = 0L
    private val density = context.resources.displayMetrics.density

    private val bgPaint = Paint().apply { color = Color.rgb(38, 50, 56) }
    private val tintPaint = Paint().apply { color = Color.argb(60, 0, 0, 0) }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(72, 199, 214)
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val gapPaint = Paint().apply { color = Color.argb(190, 0, 0, 0) }
    private val boundaryPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 3f
    }
    private val selectPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 213, 74)
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }
    // v0.8.1: yellow trim handles (#FFD600, Gemini-zip style).
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 214, 0)
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 13f * density
        textAlign = Paint.Align.CENTER
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(160, 160, 160)
        textSize = 13f * density
        textAlign = Paint.Align.CENTER
    }
    private val playheadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 4f
    }

    fun setVideo(uri: Uri, newDurationMs: Long) {
        hasVideo = true
        if (newDurationMs > 0) durationMs = newDurationMs
        frames = emptyList()
        invalidate()
        val gen = ++generation
        Thread {
            val grabbed = grabFrames(uri)
            post {
                if (gen == generation) {
                    frames = grabbed
                    invalidate()
                }
            }
        }.start()
    }

    /** v0.6.24: forget the video — thumbnails and playhead reset. */
    fun clear() {
        hasVideo = false
        frames = emptyList()
        positionMs = 0L
        segments = emptyList()
        selectedIndex = -1
        dragging = false
        dragIndex = -1
        pendingIndex = -1
        generation++
        invalidate()
    }

    /** v0.7.0: kept source-time segments (microseconds). */
    fun setSegments(newSegments: List<Pair<Long, Long>>) {
        segments = newSegments
        if (selectedIndex >= segments.size) selectedIndex = -1
        invalidate()
    }

    fun setSelectedIndex(index: Int) {
        selectedIndex = index
        invalidate()
    }

    fun setDuration(newDurationMs: Long) {
        if (newDurationMs > 0) durationMs = newDurationMs
        invalidate()
    }

    fun setPosition(newPositionMs: Long) {
        positionMs = newPositionMs
        invalidate()
    }

    private fun grabFrames(uri: Uri): List<Bitmap> {
        val out = mutableListOf<Bitmap>()
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val durUs = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull()?.times(1_000L) ?: (durationMs * 1_000L)
            if (durUs <= 0) return emptyList()
            // v0.8.0: one thumbnail per ~5s, so long videos keep
            // a readable strip in the scrolling timeline.
            val count = (durUs / 5_000_000L).toInt().coerceIn(8, 64)
            for (i in 0 until count) {
                val t = durUs * (i * 2 + 1) / (count * 2)
                val bmp = retriever.getFrameAtTime(
                    t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                ) ?: continue
                val scaled = Bitmap.createScaledBitmap(
                    bmp, 160,
                    (160f * bmp.height / bmp.width).toInt().coerceAtLeast(1), false
                )
                if (scaled !== bmp) bmp.recycle()
                out.add(scaled)
            }
        } catch (e: Exception) {
            // Frame grab failed — the fallback block still shows.
        } finally {
            try {
                retriever.release()
            } catch (e: Exception) {
            }
        }
        return out
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, h, bgPaint)
        if (!hasVideo) {
            canvas.drawText("No video picked", w / 2f, h / 2f + 6f * density, hintPaint)
            return
        }
        if (frames.isNotEmpty()) {
            val slotW = w / frames.size
            val src = Rect()
            val dst = RectF()
            for ((i, bmp) in frames.withIndex()) {
                src.set(0, 0, bmp.width, bmp.height)
                dst.set(i * slotW, 0f, (i + 1) * slotW, h)
                canvas.drawBitmap(bmp, src, dst, null)
            }
            canvas.drawRect(0f, 0f, w, h, tintPaint)
        } else {
            val label = "Video — ${formatMs(durationMs)}"
            canvas.drawText(label, w / 2f, h / 2f + 6f * density, textPaint)
        }
        canvas.drawRect(1f, 1f, w - 1f, h - 1f, borderPaint)
        // v0.7.0: darken deleted ranges, draw cut lines + selection.
        if (durationMs > 0 && segments.isNotEmpty()) {
            val totalUs = durationMs * 1_000L
            var cursor = 0L
            for ((i, seg) in segments.withIndex()) {
                // v0.8.1: the dragged segment draws at its preview bounds.
                val s = if (i == dragIndex && dragging) dragStartUs else seg.first
                val e = if (i == dragIndex && dragging) dragEndUs else seg.second
                if (s > cursor) {
                    canvas.drawRect(
                        cursor.toFloat() / totalUs * w, 0f,
                        s.toFloat() / totalUs * w, h, gapPaint
                    )
                }
                if (s > 0L) {
                    val x = s.toFloat() / totalUs * w
                    canvas.drawLine(x, 0f, x, h, boundaryPaint)
                }
                if (e < totalUs) {
                    val x = e.toFloat() / totalUs * w
                    canvas.drawLine(x, 0f, x, h, boundaryPaint)
                }
                if (e > cursor) cursor = e
            }
            if (cursor < totalUs) {
                canvas.drawRect(
                    cursor.toFloat() / totalUs * w, 0f, w, h, gapPaint
                )
            }
            if (selectedIndex in segments.indices) {
                val (os, oe) = segments[selectedIndex]
                val s = if (selectedIndex == dragIndex && dragging) dragStartUs else os
                val e = if (selectedIndex == dragIndex && dragging) dragEndUs else oe
                val left = s.toFloat() / totalUs * w
                val right = e.toFloat() / totalUs * w
                canvas.drawRect(left, 2f, right, h - 2f, selectPaint)
                // v0.8.1: yellow trim handles on the selected segment.
                val hw = 8f * density
                canvas.drawRect(left, 0f, left + hw, h, handlePaint)
                canvas.drawRect(right - hw, 0f, right, h, handlePaint)
            }
        }
        if (durationMs > 0) {
            val px = positionMs.toFloat() / durationMs * w
            canvas.drawLine(px, 0f, px, h, playheadPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (durationMs <= 0) return super.onTouchEvent(event)
        val totalUs = durationMs * 1_000L
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                val fraction = (event.x / width.toFloat()).coerceIn(0f, 1f)
                val target = (fraction * durationMs).toInt()
                val targetUs = target.toLong() * 1_000L
                val index = segments.indexOfFirst {
                    targetUs >= it.first && targetUs < it.second
                }
                downX = event.x
                pendingIndex = index
                dragging = false
                dragMode = 0
                if (index >= 0) {
                    // Select now; seek waits for UP so a trim drag
                    // doesn't yank the playhead around.
                    onSelect?.invoke(index)
                } else {
                    onSeekTo?.invoke(target)
                    setPosition(target.toLong())
                    onSelect?.invoke(-1)
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (pendingIndex >= 0 && !dragging &&
                    abs(event.x - downX) > touchSlop
                ) {
                    val (os, oe) = segments[pendingIndex]
                    val w = width.toFloat()
                    val left = os.toFloat() / totalUs * w
                    val right = oe.toFloat() / totalUs * w
                    val edge = 14f * density
                    dragMode = when {
                        downX <= left + edge -> 2
                        downX >= right - edge -> 3
                        else -> 0
                    }
                    if (dragMode != 0) {
                        dragging = true
                        dragIndex = pendingIndex
                        dragOrigStartUs = os
                        dragOrigEndUs = oe
                        dragStartUs = os
                        dragEndUs = oe
                        parent?.requestDisallowInterceptTouchEvent(true)
                    }
                }
                if (dragging) {
                    val deltaUs =
                        ((event.x - downX) / width.toFloat() * totalUs).toLong()
                    val minDurUs = 500_000L
                    val prevEnd =
                        if (dragIndex > 0) segments[dragIndex - 1].second else 0L
                    val nextStart =
                        if (dragIndex < segments.size - 1) segments[dragIndex + 1].first
                        else totalUs
                    when (dragMode) {
                        2 -> {
                            dragStartUs = (dragOrigStartUs + deltaUs).coerceIn(
                                prevEnd, maxOf(prevEnd, dragOrigEndUs - minDurUs)
                            )
                            dragEndUs = dragOrigEndUs
                        }
                        3 -> {
                            dragStartUs = dragOrigStartUs
                            dragEndUs = (dragOrigEndUs + deltaUs).coerceIn(
                                minOf(dragOrigStartUs + minDurUs, nextStart), nextStart
                            )
                        }
                    }
                    invalidate()
                } else {
                    // Drag-to-seek (empty track, or a segment's middle).
                    val fraction = (event.x / width.toFloat()).coerceIn(0f, 1f)
                    val target = (fraction * durationMs).toInt()
                    onSeekTo?.invoke(target)
                    setPosition(target.toLong())
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    if (event.action == MotionEvent.ACTION_UP) {
                        onSegmentResized?.invoke(dragIndex, dragStartUs, dragEndUs)
                    }
                    dragging = false
                    dragMode = 0
                    dragIndex = -1
                    invalidate()
                } else if (pendingIndex >= 0 &&
                    event.action == MotionEvent.ACTION_UP
                ) {
                    // A tap on a segment: seek (selection set on DOWN).
                    val fraction = (event.x / width.toFloat()).coerceIn(0f, 1f)
                    val target = (fraction * durationMs).toInt()
                    onSeekTo?.invoke(target)
                    setPosition(target.toLong())
                }
                pendingIndex = -1
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun formatMs(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }
}

/**
 * The background-music track: empty it invites a tap to pick music;
 * filled it shows the music clips (v0.7.0: split/deletable ranges of
 * the song, gaps stay silent). Tapping a clip selects it; tapping or
 * dragging seeks the preview.
 */
class MusicTrackView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var onSeekTo: ((Int) -> Unit)? = null
    var onAddMusic: (() -> Unit)? = null
    var onSelect: ((Int) -> Unit)? = null

    private var durationMs: Long = 0L
    private var positionMs: Long = 0L
    private var clips: List<MusicClip> = emptyList()
    private var musicName: String? = null
    private var selectedIndex: Int = -1
    private val density = context.resources.displayMetrics.density

    private val bgPaint = Paint().apply { color = Color.rgb(30, 30, 30) }
    private val blockPaint = Paint().apply { color = Color.rgb(0, 121, 107) }
    private val stripePaint = Paint().apply { color = Color.argb(70, 255, 255, 255) }
    private val boundaryPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 3f
    }
    private val selectPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 213, 74)
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 13f * density
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(160, 160, 160)
        textSize = 13f * density
        textAlign = Paint.Align.CENTER
    }
    private val playheadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 4f
    }

    /** v0.7.0: the clips on the timeline + the song name for the label. */
    fun setClips(newClips: List<MusicClip>, name: String?) {
        clips = newClips
        musicName = name
        if (selectedIndex >= clips.size) selectedIndex = -1
        invalidate()
    }

    fun clearMusic() {
        clips = emptyList()
        musicName = null
        selectedIndex = -1
        invalidate()
    }

    fun setSelectedIndex(index: Int) {
        selectedIndex = index
        invalidate()
    }

    fun setDuration(newDurationMs: Long) {
        if (newDurationMs > 0) durationMs = newDurationMs
        invalidate()
    }

    fun setPosition(newPositionMs: Long) {
        positionMs = newPositionMs
        invalidate()
    }

    private fun axisEndMs(): Long {
        if (durationMs > 0) return durationMs
        return clips.maxOfOrNull { it.endUs / 1_000L } ?: 0L
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, h, bgPaint)
        if (clips.isEmpty()) {
            canvas.drawText("♪  Tap to add music", w / 2f, h / 2f + 6f * density, hintPaint)
            return
        }
        val axisMs = axisEndMs()
        if (axisMs <= 0) return
        for ((i, clip) in clips.withIndex()) {
            val left = clip.startUs / 1_000f / axisMs * w
            val right = clip.endUs / 1_000f / axisMs * w
            canvas.drawRect(left, 0f, right, h, blockPaint)
            var x = left
            while (x < right) {
                canvas.drawRect(
                    x, h * 0.2f,
                    minOf(x + 6f * density, right), h * 0.8f, stripePaint
                )
                x += 28f * density
            }
            if (clip.startUs > 0L) {
                canvas.drawLine(left, 0f, left, h, boundaryPaint)
            }
            if (i == selectedIndex) {
                canvas.drawRect(left + 2f, 2f, right - 2f, h - 2f, selectPaint)
            }
        }
        val name = musicName
        if (name != null && clips.isNotEmpty()) {
            val first = clips.first()
            val left = first.startUs / 1_000f / axisMs * w
            canvas.drawText("♪ $name", left + 12f * density, h / 2f + 6f * density, textPaint)
        }
        if (durationMs > 0) {
            val px = positionMs.toFloat() / durationMs * w
            canvas.drawLine(px, 0f, px, h, playheadPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (clips.isEmpty()) {
            if (event.action == MotionEvent.ACTION_DOWN) {
                onAddMusic?.invoke()
                return true
            }
            return super.onTouchEvent(event)
        }
        val axisMs = axisEndMs()
        if (axisMs <= 0) return super.onTouchEvent(event)
        if (event.action == MotionEvent.ACTION_DOWN ||
            event.action == MotionEvent.ACTION_MOVE
        ) {
            val fraction = (event.x / width.toFloat()).coerceIn(0f, 1f)
            val target = (fraction * axisMs).toInt()
            onSeekTo?.invoke(target)
            setPosition(target.toLong())
            if (event.action == MotionEvent.ACTION_DOWN) {
                val targetUs = target.toLong() * 1_000L
                val index = clips.indexOfFirst {
                    targetUs >= it.startUs && targetUs < it.endUs
                }
                onSelect?.invoke(index)
            }
            return true
        }
        return super.onTouchEvent(event)
    }
}
