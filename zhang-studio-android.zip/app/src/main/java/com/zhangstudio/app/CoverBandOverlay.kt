package com.zhangstudio.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import androidx.media3.common.OverlaySettings
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.StaticOverlaySettings

/**
 * A [BitmapOverlay] that hides baked-in original subtitles (v0.9.9):
 * one opaque black band over the bottom 15% of the frame, shown for
 * the whole export. Source dramas usually carry their original
 * (e.g. Chinese) subtitles in the bottom ~10-12%; the band covers
 * them, and the new Myanmar subtitles draw on top of it (this
 * overlay is first in the OverlayEffect list, so it is drawn first).
 *
 * One instance serves one export only. Call [dispose] after the
 * export ends to drop the bitmap reference (GC reclaims it).
 */
@OptIn(UnstableApi::class)
class CoverBandOverlay : BitmapOverlay() {

    @Volatile
    private var bitmap: Bitmap? = null

    @Volatile
    private var settings: OverlaySettings? = null

    private val emptyBitmap: Bitmap =
        Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)

    override fun configure(videoSize: Size) {
        val bandH = (videoSize.height * 0.15f).toInt().coerceAtLeast(1)
        val band = Bitmap.createBitmap(
            videoSize.width.coerceAtLeast(1), bandH, Bitmap.Config.ARGB_8888
        )
        Canvas(band).drawColor(Color.BLACK)
        bitmap = band
        // NDC y axis points up: frame top = +1, frame bottom = -1.
        val bandTopPx = videoSize.height - bandH
        val bandCenterYPx = bandTopPx + bandH / 2f
        val anchorY = 1f - 2f * bandCenterYPx / videoSize.height
        settings = StaticOverlaySettings.Builder()
            .setOverlayFrameAnchor(0f, 0f)
            .setBackgroundFrameAnchor(0f, anchorY)
            .setScale(1f, 1f)
            .build()
    }

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        return bitmap ?: emptyBitmap
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        return settings ?: StaticOverlaySettings.Builder().build()
    }

    /** Drops the bitmap reference (GC reclaims it). Call once, after the export has ended. */
    fun dispose() {
        bitmap = null
    }

    override fun release() {
        dispose()
        super.release()
    }
}
