package com.zhangstudio.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import androidx.media3.common.OverlaySettings
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.StaticOverlaySettings

/**
 * A [BitmapOverlay] that hides baked-in original subtitles (v0.9.9):
 * one hazy translucent black band over the bottom 10% of the
 * frame, shown for the whole export. Source dramas usually carry
 * their original (e.g. Chinese) subtitles in the bottom ~10-12%;
 * the band dims them, and the new Myanmar subtitles draw on top
 * of it (this overlay is first in the OverlayEffect list, so it
 * is drawn first). Deliberately translucent (alpha 140/255, Zin's
 * corrected spec 15 Nov: "မှုန်ဝါးဝါးလေးပဲ ဖုံးရမှာ" — cover it
 * hazily, don't erase it): a solid black bar made the video look
 * CUT, and the video must stay full-frame.
 *
 * One instance serves one export only. Call [dispose] after the
 * export ends to drop the bitmap reference (GC reclaims it).
 */
@OptIn(UnstableApi::class)
class CoverBandOverlay : BitmapOverlay() {

    @Volatile
    private var bitmap: Bitmap? = null

    @Volatile
    private var settings: OverlaySettings? = null

    private val emptyBitmap: Bitmap =
        Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)

    override fun configure(videoSize: Size) {
        // v0.10.11: 10% — Zin: a SMALL black bar.
        val bandH = (videoSize.height * 0.10f).toInt().coerceAtLeast(1)
        val band = Bitmap.createBitmap(
            videoSize.width.coerceAtLeast(1), bandH, Bitmap.Config.ARGB_8888
        )
        // v0.10.14: alpha 140 — hazy cover, never solid black
        // (opaque black made the video look CUT — Zin's spec).
        Canvas(band).drawColor(Color.argb(140, 0, 0, 0))
        bitmap = band
        // NDC y axis points up: frame top = +1, frame bottom = -1.
        val bandTopPx = videoSize.height - bandH
        val bandCenterYPx = bandTopPx + bandH / 2f
        val anchorY = 1f - 2f * bandCenterYPx / videoSize.height
        settings = StaticOverlaySettings.Builder()
            .setOverlayFrameAnchor(0f, 0f)
            .setBackgroundFrameAnchor(0f, anchorY)
            .setScale(1f, 1f)
            .build()
    }

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        return bitmap ?: emptyBitmap
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        return settings ?: StaticOverlaySettings.Builder().build()
    }

    /** Drops the bitmap reference (GC reclaims it). Call once, after the export has ended. */
    fun dispose() {
        bitmap = null
    }

    override fun release() {
        dispose()
        super.release()
    }
}
