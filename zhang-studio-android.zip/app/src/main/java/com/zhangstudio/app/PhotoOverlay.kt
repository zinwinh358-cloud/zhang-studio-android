package com.zhangstudio.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.media3.common.OverlaySettings
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.StaticOverlaySettings

/**
 * A [BitmapOverlay] that shows one photo overlay (sticker) on the
 * video while the playhead is inside [startUs, endUs) (v0.9.4).
 *
 * The photo is decoded once in [configure] and pre-scaled to
 * [scale] × the video width, so the overlay runs at 1:1 pixel
 * scale with its center anchored at ([xFrac], [yFrac]) of the
 * frame — the same position the user dragged it to on the preview.
 * Outside the clip's interval a 1x1 transparent bitmap is returned.
 *
 * One instance serves one export only. Call [dispose] after the
 * export ends to drop the bitmap reference (GC reclaims it).
 */
@OptIn(UnstableApi::class)
class PhotoOverlay(
    private val appContext: Context,
    private val uri: Uri,
    private val startUs: Long,
    private val endUs: Long,
    private val xFrac: Float,
    private val yFrac: Float,
    private val scale: Float
) : BitmapOverlay() {

    @Volatile
    private var bitmap: Bitmap? = null

    @Volatile
    private var settings: OverlaySettings? = null

    private val emptyBitmap: Bitmap =
        Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)

    override fun configure(videoSize: Size) {
        val targetW = (scale * videoSize.width).toInt().coerceIn(2, videoSize.width * 2)
        bitmap = decodeScaled(targetW)
        // NDC: x -1 (left) .. +1 (right), y +1 (top) .. -1 (bottom).
        val anchorX = 2f * xFrac - 1f
        val anchorY = 1f - 2f * yFrac
        settings = StaticOverlaySettings.Builder()
            .setOverlayFrameAnchor(0f, 0f)
            .setBackgroundFrameAnchor(anchorX, anchorY)
            .setScale(1f, 1f)
            .build()
    }

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        if (presentationTimeUs < startUs || presentationTimeUs >= endUs) {
            return emptyBitmap
        }
        return bitmap ?: emptyBitmap
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        return settings ?: StaticOverlaySettings.Builder().build()
    }

    /** Drops the bitmap reference (GC reclaims it). Call once, after the export has ended. */
    fun dispose() {
        bitmap = null
    }

    override fun release() {
        dispose()
        super.release()
    }

    private fun decodeScaled(targetW: Int): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            appContext.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, bounds)
            }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (bounds.outWidth / sample > targetW * 2 && sample < 64) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val decoded = appContext.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return null
            val scaledW = targetW.coerceAtLeast(2)
            val scaledH = (decoded.height.toFloat() * scaledW / decoded.width)
                .toInt().coerceAtLeast(2)
            if (decoded.width == scaledW && decoded.height == scaledH) {
                decoded
            } else {
                val scaled = Bitmap.createScaledBitmap(decoded, scaledW, scaledH, true)
                if (scaled !== decoded) decoded.recycle()
                scaled
            }
        } catch (e: Exception) {
            null
        }
    }
}
