package com.zhangstudio.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/**
 * A simple SRT track for the timing screen's editor area: subtitle cues
 * drawn as blocks on a time axis, with a playhead line. Tapping or
 * dragging on the track seeks the preview to that time. The axis spans
 * the video duration when known, else the last cue's end.
 */
class SrtTrackView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var onSeekTo: ((Int) -> Unit)? = null
    var onAddSrt: (() -> Unit)? = null
    var onSelect: ((Int) -> Unit)? = null

    private var cues: List<SubtitleCue> = emptyList()
    private var durationMs: Long = 0L
    private var positionMs: Long = 0L
    // v0.7.0: selected cue index (-1 = none).
    private var selectedIndex: Int = -1
    private val density = context.resources.displayMetrics.density

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 0, 0, 0)
    }
    private val cuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(72, 199, 214)
    }
    private val selectPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 213, 74)
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }
    private val playheadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 4f
    }
    // v0.6.22: empty-state hint, same style as the music track.
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(160, 160, 160)
        textSize = 13f * density
        textAlign = Paint.Align.CENTER
    }

    fun setCues(newCues: List<SubtitleCue>, newDurationMs: Long = durationMs) {
        cues = newCues
        if (newDurationMs > 0) durationMs = newDurationMs
        if (selectedIndex >= cues.size) selectedIndex = -1
        invalidate()
    }

    fun setSelectedIndex(index: Int) {
        selectedIndex = index
        invalidate()
    }

    fun setDuration(newDurationMs: Long) {
        if (newDurationMs > 0) durationMs = newDurationMs
        invalidate()
    }

    fun setPosition(newPositionMs: Long) {
        positionMs = newPositionMs
        invalidate()
    }

    private fun axisEndMs(): Long {
        if (durationMs > 0) return durationMs
        return cues.maxOfOrNull { it.endUs / 1_000L } ?: 1L
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, h, trackPaint)
        if (cues.isEmpty()) {
            canvas.drawText(
                "SRT ထည့်ရန် နှိပ်ပါ", w / 2f, h / 2f + 6f * density, hintPaint
            )
            return
        }
        val end = axisEndMs().coerceAtLeast(1L)
        val rect = RectF()
        var selectedRect: RectF? = null
        for ((i, cue) in cues.withIndex()) {
            val left = (cue.startUs / 1_000L).toFloat() / end * w
            val right = (cue.endUs / 1_000L).toFloat() / end * w
            if (right < 0 || left > w) continue
            rect.set(left.coerceAtLeast(0f), h * 0.2f, right.coerceAtMost(w), h * 0.8f)
            canvas.drawRoundRect(rect, 8f, 8f, cuePaint)
            if (i == selectedIndex) selectedRect = RectF(rect)
        }
        if (selectedRect != null) {
            canvas.drawRoundRect(selectedRect, 8f, 8f, selectPaint)
        }
        val px = positionMs.toFloat() / end * w
        canvas.drawLine(px, 0f, px, h, playheadPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (cues.isEmpty()) {
            if (event.action == MotionEvent.ACTION_DOWN) {
                onAddSrt?.invoke()
                return true
            }
            return super.onTouchEvent(event)
        }
        if (event.action == MotionEvent.ACTION_DOWN ||
            event.action == MotionEvent.ACTION_MOVE
        ) {
            val fraction = (event.x / width.toFloat()).coerceIn(0f, 1f)
            val target = (fraction * axisEndMs()).toInt()
            onSeekTo?.invoke(target)
            setPosition(target.toLong())
            if (event.action == MotionEvent.ACTION_DOWN) {
                val targetUs = target.toLong() * 1_000L
                val index = cues.indexOfFirst {
                    targetUs >= it.startUs && targetUs < it.endUs
                }
                onSelect?.invoke(index)
            }
            return true
        }
        return super.onTouchEvent(event)
    }
}
