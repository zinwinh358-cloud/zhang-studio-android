package com.zhangstudio.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/**
 * A simple SRT track for the timing screen's editor area: subtitle cues
 * drawn as blocks on a time axis, with a playhead line. Tapping or
 * dragging on the track seeks the preview to that time. The axis spans
 * the video duration when known, else the last cue's end.
 */
class SrtTrackView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var onSeekTo: ((Int) -> Unit)? = null

    private var cues: List<SubtitleCue> = emptyList()
    private var durationMs: Long = 0L
    private var positionMs: Long = 0L

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 0, 0, 0)
    }
    private val cuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(72, 199, 214)
    }
    private val playheadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 4f
    }

    fun setCues(newCues: List<SubtitleCue>, newDurationMs: Long = durationMs) {
        cues = newCues
        if (newDurationMs > 0) durationMs = newDurationMs
        invalidate()
    }

    fun setDuration(newDurationMs: Long) {
        if (newDurationMs > 0) durationMs = newDurationMs
        invalidate()
    }

    fun setPosition(newPositionMs: Long) {
        positionMs = newPositionMs
        invalidate()
    }

    private fun axisEndMs(): Long {
        if (durationMs > 0) return durationMs
        return cues.maxOfOrNull { it.endUs / 1_000L } ?: 1L
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, h, trackPaint)
        val end = axisEndMs().coerceAtLeast(1L)
        val rect = RectF()
        for (cue in cues) {
            val left = (cue.startUs / 1_000L).toFloat() / end * w
            val right = (cue.endUs / 1_000L).toFloat() / end * w
            if (right < 0 || left > w) continue
            rect.set(left.coerceAtLeast(0f), h * 0.2f, right.coerceAtMost(w), h * 0.8f)
            canvas.drawRoundRect(rect, 8f, 8f, cuePaint)
        }
        val px = positionMs.toFloat() / end * w
        canvas.drawLine(px, 0f, px, h, playheadPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN ||
            event.action == MotionEvent.ACTION_MOVE
        ) {
            val fraction = (event.x / width.toFloat()).coerceIn(0f, 1f)
            val target = (fraction * axisEndMs()).toInt()
            onSeekTo?.invoke(target)
            setPosition(target.toLong())
            return true
        }
        return super.onTouchEvent(event)
    }
}
