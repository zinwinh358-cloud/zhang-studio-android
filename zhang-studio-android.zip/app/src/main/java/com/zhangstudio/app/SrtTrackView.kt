package com.zhangstudio.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.abs

/**
 * A simple SRT track for the timing screen's editor area: subtitle cues
 * drawn as blocks on a time axis, with a playhead line. Tapping or
 * dragging on empty track seeks the preview to that time. The axis spans
 * the video duration when known, else the last cue's end.
 *
 * v0.7.9: VN-style cue dragging — drag a cue's middle to move it in
 * time, drag its left/right edge to resize it. Tapping a cue still
 * selects it and seeks.
 */
class SrtTrackView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var onSeekTo: ((Int) -> Unit)? = null
    var onAddSrt: (() -> Unit)? = null
    var onSelect: ((Int) -> Unit)? = null
    // v0.7.9: fired when a cue drag ends: (index, newStartUs, newEndUs),
    // in the same (shifted) time space as the cues passed to setCues.
    var onCueMoved: ((Int, Long, Long) -> Unit)? = null

    private var cues: List<SubtitleCue> = emptyList()
    private var durationMs: Long = 0L
    private var positionMs: Long = 0L
    // v0.7.0: selected cue index (-1 = none).
    private var selectedIndex: Int = -1
    private val density = context.resources.displayMetrics.density

    // v0.7.9: drag state.
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private var pendingIndex: Int = -1
    private var downX: Float = 0f
    private var dragging: Boolean = false
    private var dragMode: Int = 0 // 1 = move, 2 = left edge, 3 = right edge
    private var dragIndex: Int = -1
    private var dragOrigStartUs: Long = 0L
    private var dragOrigEndUs: Long = 0L
    private var dragStartUs: Long = 0L
    private var dragEndUs: Long = 0L

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 0, 0, 0)
    }
    private val cuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(72, 199, 214)
    }
    private val selectPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 213, 74)
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }
    private val playheadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 4f
    }
    // v0.6.22: empty-state hint, same style as the music track.
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(160, 160, 160)
        textSize = 13f * density
        textAlign = Paint.Align.CENTER
    }

    fun setCues(newCues: List<SubtitleCue>, newDurationMs: Long = durationMs) {
        cues = newCues
        if (newDurationMs > 0) durationMs = newDurationMs
        if (selectedIndex >= cues.size) selectedIndex = -1
        invalidate()
    }

    fun setSelectedIndex(index: Int) {
        selectedIndex = index
        invalidate()
    }

    fun setDuration(newDurationMs: Long) {
        if (newDurationMs > 0) durationMs = newDurationMs
        invalidate()
    }

    fun setPosition(newPositionMs: Long) {
        positionMs = newPositionMs
        invalidate()
    }

    private fun axisEndMs(): Long {
        if (durationMs > 0) return durationMs
        return cues.maxOfOrNull { it.endUs / 1_000L } ?: 1L
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, h, trackPaint)
        if (cues.isEmpty()) {
            canvas.drawText(
                "SRT ထည့်ရန် နှိပ်ပါ", w / 2f, h / 2f + 6f * density, hintPaint
            )
            return
        }
        val end = axisEndMs().coerceAtLeast(1L)
        val rect = RectF()
        var selectedRect: RectF? = null
        for ((i, cue) in cues.withIndex()) {
            // v0.7.9: the dragged cue draws at its preview position.
            val sUs = if (i == dragIndex && dragging) dragStartUs else cue.startUs
            val eUs = if (i == dragIndex && dragging) dragEndUs else cue.endUs
            val left = (sUs / 1_000L).toFloat() / end * w
            val right = (eUs / 1_000L).toFloat() / end * w
            if (right < 0 || left > w) continue
            rect.set(left.coerceAtLeast(0f), h * 0.2f, right.coerceAtMost(w), h * 0.8f)
            canvas.drawRoundRect(rect, 8f, 8f, cuePaint)
            if (i == selectedIndex) selectedRect = RectF(rect)
        }
        if (selectedRect != null) {
            canvas.drawRoundRect(selectedRect, 8f, 8f, selectPaint)
        }
        val px = positionMs.toFloat() / end * w
        canvas.drawLine(px, 0f, px, h, playheadPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (cues.isEmpty()) {
            if (event.action == MotionEvent.ACTION_DOWN) {
                onAddSrt?.invoke()
                return true
            }
            return super.onTouchEvent(event)
        }
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                val fraction = (event.x / width.toFloat()).coerceIn(0f, 1f)
                val targetMs = fraction * axisEndMs()
                val targetUs = targetMs.toLong() * 1_000L
                val index = cues.indexOfFirst {
                    targetUs >= it.startUs && targetUs < it.endUs
                }
                downX = event.x
                pendingIndex = index
                dragging = false
                dragMode = 0
                if (index >= 0) {
                    // Select now; seek waits for UP so a drag
                    // doesn't yank the playhead around.
                    onSelect?.invoke(index)
                } else {
                    onSeekTo?.invoke(targetMs.toInt())
                    setPosition(targetMs.toLong())
                    onSelect?.invoke(-1)
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (pendingIndex >= 0 && !dragging &&
                    abs(event.x - downX) > touchSlop
                ) {
                    val cue = cues[pendingIndex]
                    val end = axisEndMs().coerceAtLeast(1L)
                    val w = width.toFloat()
                    val left = (cue.startUs / 1_000L).toFloat() / end * w
                    val right = (cue.endUs / 1_000L).toFloat() / end * w
                    val edge = 14f * density
                    dragMode = when {
                        downX <= left + edge -> 2
                        downX >= right - edge -> 3
                        else -> 1
                    }
                    dragging = true
                    dragIndex = pendingIndex
                    dragOrigStartUs = cue.startUs
                    dragOrigEndUs = cue.endUs
                    dragStartUs = cue.startUs
                    dragEndUs = cue.endUs
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
                if (dragging) {
                    val end = axisEndMs().coerceAtLeast(1L)
                    val deltaUs =
                        ((event.x - downX) / width.toFloat() * end * 1_000L).toLong()
                    val axisEndUs = end * 1_000L
                    val minDurUs = 500_000L
                    when (dragMode) {
                        1 -> {
                            val dur = dragOrigEndUs - dragOrigStartUs
                            val maxStart =
                                maxOf(0L, axisEndUs - dur)
                            dragStartUs =
                                (dragOrigStartUs + deltaUs).coerceIn(0L, maxStart)
                            dragEndUs = dragStartUs + dur
                        }
                        2 -> {
                            val maxStart =
                                maxOf(0L, dragOrigEndUs - minDurUs)
                            dragStartUs =
                                (dragOrigStartUs + deltaUs).coerceIn(0L, maxStart)
                            dragEndUs = dragOrigEndUs
                        }
                        3 -> {
                            dragStartUs = dragOrigStartUs
                            dragEndUs = (dragOrigEndUs + deltaUs)
                                .coerceAtLeast(dragOrigStartUs + minDurUs)
                                .coerceAtMost(
                                    maxOf(axisEndUs, dragOrigStartUs + minDurUs)
                                )
                        }
                    }
                    invalidate()
                } else if (pendingIndex < 0) {
                    // Drag-to-seek on empty track (existing behavior).
                    val fraction = (event.x / width.toFloat()).coerceIn(0f, 1f)
                    val target = (fraction * axisEndMs()).toInt()
                    onSeekTo?.invoke(target)
                    setPosition(target.toLong())
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    if (event.action == MotionEvent.ACTION_UP) {
                        onCueMoved?.invoke(dragIndex, dragStartUs, dragEndUs)
                    }
                    dragging = false
                    dragMode = 0
                    dragIndex = -1
                    invalidate()
                } else if (pendingIndex >= 0 &&
                    event.action == MotionEvent.ACTION_UP
                ) {
                    // A tap on a cue: seek (selection was set on DOWN).
                    val fraction = (event.x / width.toFloat()).coerceIn(0f, 1f)
                    val target = (fraction * axisEndMs()).toInt()
                    onSeekTo?.invoke(target)
                    setPosition(target.toLong())
                }
                pendingIndex = -1
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}
