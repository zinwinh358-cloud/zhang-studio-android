package com.zhangstudio.app

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.SpeedProvider
import androidx.media3.transformer.Transformer
import java.io.File

/**
 * Runs one on-device subtitle-burning export with Media3 Transformer.
 *
 * Pipeline: decode (hardware) -> [OverlayEffect] with [SubtitleOverlay]
 * (GPU-composited band bitmaps) -> H.264 encode (hardware) -> MP4 mux.
 * Video is re-encoded at its original resolution. The audio MIME type is
 * intentionally left unset, so Transformer keeps the input audio format
 * and transmuxes (copies) the audio samples when possible instead of
 * re-encoding them.
 *
 * All Transformer access happens on the main thread (Transformer requires
 * single-thread access and posts listener callbacks to that thread).
 * Progress is polled with [Transformer.getProgress], the documented
 * approach — there is no progress callback API.
 *
 * One instance serves one export. Call [cancel] to stop early.
 */
@OptIn(UnstableApi::class)
class SubtitleBurner(context: Context) {

    interface Callback {
        fun onProgress(percent: Int)
        fun onCompleted(outputPath: String)
        fun onError(message: String)
    }

    private val appContext: Context = context.applicationContext
    private var transformer: Transformer? = null
    private var overlay: SubtitleOverlay? = null
    private var callback: Callback? = null
    private var outputPath: String? = null
    private var finished = false

    private val handler = Handler(Looper.getMainLooper())
    private val progressHolder = ProgressHolder()
    private val progressRunnable = object : Runnable {
        override fun run() {
            val runningTransformer = transformer
            if (runningTransformer == null || finished) return
            val state = runningTransformer.getProgress(progressHolder)
            if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                callback?.onProgress(progressHolder.progress.coerceIn(0, 100))
            }
            if (!finished) handler.postDelayed(this, 500L)
        }
    }

    /** Starts one export.
     *
     * [clipStartUs]/[clipEndUs] trim the video (C.TIME_END_OF_SOURCE = no
     * end trim); callers must rebase the cues to the trimmed timeline
     * (see SrtParser.trimmed). [topText], when non-blank, is shown at the
     * top of the frame for the whole export.
     *
     * [segments], when non-null, is the cut-out edit: the export joins
     * these original-timeline ranges in order, and the cues must already
     * be joined to match (SrtParser.cutOut). The subtitle overlay then
     * runs at Composition level ([compositionOverlay] must be true), so
     * it sees the joined output timeline.
     *
     * [speed] applies a constant speed change (item-level effect, after
     * the overlay in the effects list, so an item-level overlay sees
     * content timestamps). [musicUri] adds a looping background-music
     * sequence mixed with the video audio; [muteOriginal] drops the
     * video's own audio track. Mixing re-encodes audio as AAC.
     */
    fun start(
        videoUri: Uri,
        cues: List<SubtitleCue>,
        typeface: Typeface,
        outputFile: File,
        callback: Callback,
        clipStartUs: Long = 0L,
        clipEndUs: Long = C.TIME_END_OF_SOURCE,
        topText: String? = null,
        segments: List<Pair<Long, Long>>? = null,
        speed: Float = 1f,
        musicUri: Uri? = null,
        muteOriginal: Boolean = false,
        compositionOverlay: Boolean = false
    ) {
        this.callback = callback
        finished = false
        try {
            if (outputFile.exists()) outputFile.delete()
            val subtitleOverlay = SubtitleOverlay(cues, typeface)
            overlay = subtitleOverlay
            val overlays = mutableListOf<TextureOverlay>(subtitleOverlay)
            val staticOverlay = topText?.takeIf { it.isNotBlank() }?.let {
                StaticTextOverlay(it, typeface)
            }
            if (staticOverlay != null) overlays.add(staticOverlay)

            val speedEffect = if (speed != 1f) {
                val provider = object : SpeedProvider {
                    override fun getSpeed(timeUs: Long): Float = speed
                    override fun getNextSpeedChangeTimeUs(timeUs: Long): Long =
                        C.TIME_UNSET
                }
                Effects.createExperimentalSpeedChangingEffect(provider)
            } else {
                null
            }
            val audioProcessors = speedEffect?.let { listOf(it.first) } ?: emptyList()

            val segmentRanges = segments ?: listOf(clipStartUs to clipEndUs)
            val videoItems = segmentRanges.map { (segStart, segEnd) ->
                // Clipping belongs on the MediaItem, not on EditedMediaItem
                // (Media3 1.11.1 — CI run #24 proved it). Transformer honors
                // the MediaItem's clipping configuration.
                val mediaItemBuilder = MediaItem.Builder().setUri(videoUri)
                if (segStart > 0L || segEnd != C.TIME_END_OF_SOURCE) {
                    mediaItemBuilder.setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionUs(segStart)
                            .setEndPositionUs(segEnd)
                            .build()
                    )
                }
                val videoEffects = mutableListOf<Effect>()
                if (!compositionOverlay) {
                    videoEffects.add(OverlayEffect(overlays))
                }
                if (speedEffect != null) videoEffects.add(speedEffect.second)
                val itemBuilder = EditedMediaItem.Builder(mediaItemBuilder.build())
                    .setEffects(Effects(audioProcessors, videoEffects))
                if (muteOriginal) itemBuilder.setRemoveAudio(true)
                itemBuilder.build()
            }

            val listener = object : Transformer.Listener {
                override fun onCompleted(composition: Composition, result: ExportResult) {
                    finishCompleted()
                }

                override fun onError(
                    composition: Composition,
                    result: ExportResult,
                    exception: ExportException
                ) {
                    finishError(exception.message ?: "Export failed")
                }
            }
            val transformerBuilder = Transformer.Builder(appContext)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .addListener(listener)
            if (musicUri != null) {
                transformerBuilder.setAudioMimeType(MimeTypes.AUDIO_AAC)
            }
            val builtTransformer = transformerBuilder.build()
            transformer = builtTransformer
            outputPath = outputFile.absolutePath
            val useComposition = segments != null || musicUri != null
            if (useComposition) {
                val videoSequence = if (muteOriginal) {
                    EditedMediaItemSequence.withVideoFrom(videoItems)
                } else {
                    EditedMediaItemSequence.withAudioAndVideoFrom(videoItems)
                }
                val sequences = mutableListOf(videoSequence)
                if (musicUri != null) {
                    val musicItem = EditedMediaItem.Builder(
                        MediaItem.fromUri(musicUri)
                    ).build()
                    val musicSequence = EditedMediaItemSequence.withAudioFrom(
                        listOf(musicItem)
                    ).buildUpon().setIsLooping(true).build()
                    sequences.add(musicSequence)
                }
                val compositionBuilder =
                    Composition.Builder(*sequences.toTypedArray())
                if (compositionOverlay) {
                    compositionBuilder.setEffects(
                        Effects(emptyList(), listOf(OverlayEffect(overlays)))
                    )
                }
                builtTransformer.start(
                    compositionBuilder.build(), outputFile.absolutePath
                )
            } else {
                builtTransformer.start(videoItems.single(), outputFile.absolutePath)
            }
            handler.post(progressRunnable)
        } catch (e: Exception) {
            finishError(e.message ?: "Failed to start export")
        }
    }

    fun cancel() {
        finished = true
        handler.removeCallbacks(progressRunnable)
        try {
            transformer?.cancel()
        } catch (ignored: Exception) {
            // Ignore: transformer may already be idle.
        }
        transformer = null
        overlay?.dispose()
        overlay = null
        callback = null
        outputPath = null
    }

    private fun finishCompleted() {
        if (finished) return
        finished = true
        handler.removeCallbacks(progressRunnable)
        val path = outputPath
        transformer = null
        overlay?.dispose()
        overlay = null
        outputPath = null
        if (path != null) {
            callback?.onCompleted(path)
        } else {
            callback?.onError("Export finished but the output path is missing")
        }
        callback = null
    }

    private fun finishError(message: String) {
        if (finished) return
        finished = true
        handler.removeCallbacks(progressRunnable)
        transformer = null
        overlay?.dispose()
        overlay = null
        outputPath = null
        callback?.onError(message)
        callback = null
    }
}
