package com.zhangstudio.app

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.DefaultGainProvider
import androidx.media3.common.audio.GainProcessor
import androidx.media3.common.audio.SpeedProvider
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File
import java.io.FileOutputStream

/**
 * One piece of the background-music sequence (v0.7.0): a clipped range
 * of the song ([isSilence] = false, [uri] = the song), or silence
 * ([isSilence] = true, [uri] ignored — the burner substitutes a
 * generated silent WAV). Times are positions inside the source file.
 */
data class MusicItem(
    val uri: Uri?,
    val startUs: Long,
    val endUs: Long,
    val isSilence: Boolean = false,
    val gain: Float = 1f
)

/**
 * Runs one on-device subtitle-burning export with Media3 Transformer.
 *
 * Pipeline: decode (hardware) -> [RegionBlurEffect] (v0.10.16:
 * frosted blur bands over baked-in subtitles / corner logos) ->
 * [OverlayEffect] with [SubtitleOverlay] (GPU-composited subtitle
 * bitmaps) -> H.264 encode (hardware) -> MP4 mux.
 * Video is re-encoded at its original resolution. Audio is ALWAYS
 * re-encoded to AAC (v0.10.3): transmuxing (copying) the input audio
 * breaks MediaMuxer on real drama files — HE-AAC tracks and timestamp
 * quirks surface as a bare "Muxer error" mid-export (wonton drama,
 * 14 Nov). Re-encoding costs almost nothing next to the video encode
 * and is always muxer-safe.
 *
 * All Transformer access happens on the main thread (Transformer requires
 * single-thread access and posts listener callbacks to that thread).
 * Progress is polled with [Transformer.getProgress], the documented
 * approach — there is no progress callback API.
 *
 * One instance serves one export. Call [cancel] to stop early.
 */
@OptIn(UnstableApi::class)
class SubtitleBurner(context: Context) {

    interface Callback {
        fun onProgress(percent: Int)
        fun onCompleted(outputPath: String)
        fun onError(message: String)
    }

    private val appContext: Context = context.applicationContext
    private var transformer: Transformer? = null
    private var overlay: SubtitleOverlay? = null
    // v0.10.16: the hazy band bitmaps (CoverBandOverlay /
    // TopBandOverlay) are replaced by RegionBlurEffect — a real
    // frosted blur, applied as a video effect before the overlay.
    // The band classes are kept (dormant) for easy rollback.
    // v0.9.4: photo overlays (stickers) burned with the same effect.
    private var photoOverlays: List<PhotoOverlay> = emptyList()
    private var callback: Callback? = null
    private var outputPath: String? = null
    private var finished = false

    private val handler = Handler(Looper.getMainLooper())
    private val progressHolder = ProgressHolder()
    private val progressRunnable = object : Runnable {
        override fun run() {
            val runningTransformer = transformer
            if (runningTransformer == null || finished) return
            val state = runningTransformer.getProgress(progressHolder)
            if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                callback?.onProgress(progressHolder.progress.coerceIn(0, 100))
            }
            if (!finished) handler.postDelayed(this, 500L)
        }
    }

    /** Starts one export.
     *
     * [clipStartUs]/[clipEndUs] trim the video (C.TIME_END_OF_SOURCE = no
     * end trim); callers must rebase the cues to the trimmed timeline
     * (see SrtParser.trimmed). [topText], when non-blank, is shown at the
     * top of the frame for the whole export.
     *
     * [segments], when non-null, is the cut-out edit: the export joins
     * these original-timeline ranges in order, and the cues must already
     * be joined to match (SrtParser.cutOut). The subtitle overlay then
     * runs at Composition level ([compositionOverlay] must be true), so
     * it sees the joined output timeline.
     *
     * [speed] applies a constant speed change via
     * EditedMediaItem.Builder.setSpeed (Media3 1.9+ API; the old
     * Effects.createExperimentalSpeedChangingEffect is deprecated).
     * [musicUri] adds a looping background-music sequence mixed with the
     * video audio; [muteOriginal] drops the video's own audio track.
     * Mixing re-encodes audio as AAC.
     *
     * [musicItems], when non-empty (v0.7.0), replaces [musicUri]: the
     * music sequence is built from these clipped song/silence pieces in
     * order, with no looping, so deleted music ranges stay silent.
     *
     * [videoGain]/[musicGain] (v0.9.2) scale the video / music audio
     * separately via Media3's GainProcessor; 1f leaves the proven
     * no-effect path untouched.
     *
     * [photoOverlays] (v0.9.4) are the sticker overlays, already
     * rebased/scaled onto the export timeline by the caller; they
     * ride the same OverlayEffect as the subtitles.
     */
    fun start(
        videoUri: Uri,
        cues: List<SubtitleCue>,
        typeface: Typeface,
        outputFile: File,
        callback: Callback,
        clipStartUs: Long = 0L,
        clipEndUs: Long = C.TIME_END_OF_SOURCE,
        topText: String? = null,
        segments: List<Pair<Long, Long>>? = null,
        speed: Float = 1f,
        musicUri: Uri? = null,
        muteOriginal: Boolean = false,
        compositionOverlay: Boolean = false,
        musicItems: List<MusicItem>? = null,
        videoGain: Float = 1f,
        musicGain: Float = 1f,
        titleXFrac: Float = 0.5f,
        titleTopFrac: Float = 0.08f,
        photoOverlays: List<PhotoOverlay> = emptyList(),
        coverUri: Uri? = null,
        coverDurationUs: Long = 0L,
        coverOriginalSubs: Boolean = false,
        coverTopLogos: Boolean = false,
        // v0.14.0: auto-detected baked-in subtitle zone as (yStart,
        // yEnd) frame fractions from the TOP (server v55 detection).
        // Null = no detection; the manual cover bands apply alone.
        subsZone: Pair<Float, Float>? = null
    ) {
        this.callback = callback
        finished = false
        try {
            if (outputFile.exists()) outputFile.delete()
            val subtitleOverlay = SubtitleOverlay(cues, typeface)
            overlay = subtitleOverlay
            this.photoOverlays = photoOverlays
            val overlays = mutableListOf<TextureOverlay>()
            // v0.10.16: no band bitmaps — the blur bands are a video
            // effect (RegionBlurEffect, added to videoEffects below),
            // so the subtitles, photos and title all draw on top of
            // the blurred frame.
            overlays.add(subtitleOverlay)
            overlays.addAll(photoOverlays)
            val staticOverlay = topText?.takeIf { it.isNotBlank() }?.let {
                StaticTextOverlay(it, typeface, titleXFrac, titleTopFrac)
            }
            if (staticOverlay != null) overlays.add(staticOverlay)

            val speedProvider = if (speed != 1f) {
                object : SpeedProvider {
                    override fun getSpeed(timeUs: Long): Float = speed
                    override fun getNextSpeedChangeTimeUs(timeUs: Long): Long =
                        C.TIME_UNSET
                }
            } else {
                null
            }

            val segmentRanges = segments ?: listOf(clipStartUs to clipEndUs)
            val segmentItems = segmentRanges.map { (segStart, segEnd) ->
                // Clipping belongs on the MediaItem, not on EditedMediaItem
                // (Media3 1.11.1 — CI run #24 proved it). Transformer honors
                // the MediaItem's clipping configuration.
                val mediaItemBuilder = MediaItem.Builder().setUri(videoUri)
                if (segStart > 0L || segEnd != C.TIME_END_OF_SOURCE) {
                    mediaItemBuilder.setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionUs(segStart)
                            .setEndPositionUs(segEnd)
                            .build()
                    )
                }
                val videoEffects = mutableListOf<Effect>()
                // v0.10.16: frosted blur bands FIRST, before the
                // overlay — the blur is per-frame and timeline
                // independent, so it rides each item even when the
                // subtitle overlay runs at Composition level.
                // v0.14.0: the detected subtitle band rides along with
                // (F2 checkboxes) or instead of (F1) the fixed cover
                // bands — the call site decides the booleans.
                if (coverOriginalSubs || coverTopLogos || subsZone != null) {
                    videoEffects.add(
                        RegionBlurEffect(
                            bottomFrac = if (coverOriginalSubs) 0.14f else 0f,
                            topFrac = if (coverTopLogos) 0.10f else 0f,
                            midBand = subsZone
                        )
                    )
                }
                if (!compositionOverlay) {
                    videoEffects.add(OverlayEffect(overlays))
                }
                // v0.9.2: separate video volume via GainProcessor.
                val audioProcessors: List<AudioProcessor> = if (videoGain != 1f) {
                    listOf(
                        GainProcessor(
                            DefaultGainProvider.Builder(videoGain).build()
                        )
                    )
                } else {
                    emptyList()
                }
                val itemBuilder = EditedMediaItem.Builder(mediaItemBuilder.build())
                    .setEffects(Effects(audioProcessors, videoEffects))
                if (speedProvider != null) itemBuilder.setSpeed(speedProvider)
                if (muteOriginal) itemBuilder.setRemoveAudio(true)
                itemBuilder.build()
            }

            // v0.9.7: still-image intro, prepended before the video.
            // The default asset-loader factory routes image inputs to
            // ImageAssetLoader (verified in the 1.11.1 AAR); the still
            // plays for coverDurationUs with no audio of its own.
            val videoItems = if (coverUri != null && coverDurationUs > 0L) {
                listOf(
                    EditedMediaItem.Builder(MediaItem.fromUri(coverUri))
                        .setDurationUs(coverDurationUs)
                        .build()
                ) + segmentItems
            } else {
                segmentItems
            }

            val listener = object : Transformer.Listener {
                override fun onCompleted(composition: Composition, result: ExportResult) {
                    finishCompleted()
                }

                override fun onError(
                    composition: Composition,
                    result: ExportResult,
                    exception: ExportException
                ) {
                    // v0.10.3: include the error code + cause chain, so
                    // a screenshot of the next failure says WHY it
                    // failed ("Muxer error" alone is not diagnosable).
                    val detail = StringBuilder(exception.message ?: "Export failed")
                    detail.append(" (code ${exception.errorCode})")
                    var cause = exception.cause
                    while (cause != null) {
                        detail.append(" — ${cause.javaClass.simpleName}: ${cause.message}")
                        cause = cause.cause
                    }
                    finishError(detail.toString())
                }
            }
            val transformerBuilder = Transformer.Builder(appContext)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                // v0.10.8: the default 10s muxer watchdog (ERROR_CODE_MUXING_TIMEOUT,
                // 7002) aborts slow-but-alive encodes on mid-range phones — the
                // 778G+ can stall >10s on hard sections with GL overlays. 60s
                // lets it ride through slow patches; a truly wedged encode
                // still fails, just later.
                .setMaxDelayBetweenMuxerSamplesMs(60_000L)
                .addListener(listener)
            val musicItemList = musicItems?.takeIf { it.isNotEmpty() }
            // v0.10.3: always re-encode audio to AAC — never transmux.
            // (See the class KDoc: transmuxing breaks the muxer on
            // HE-AAC / quirky drama audio.)
            transformerBuilder.setAudioMimeType(MimeTypes.AUDIO_AAC)
            val builtTransformer = transformerBuilder.build()
            transformer = builtTransformer
            outputPath = outputFile.absolutePath
            val useComposition = segments != null || musicUri != null || musicItemList != null
            if (useComposition) {
                val videoSequence = if (muteOriginal) {
                    EditedMediaItemSequence.withVideoFrom(videoItems)
                } else {
                    EditedMediaItemSequence.withAudioAndVideoFrom(videoItems)
                }
                val sequences = mutableListOf(videoSequence)
                if (musicItemList != null) {
                    val silenceUri = if (musicItemList.any { it.isSilence }) {
                        Uri.fromFile(silenceWavFile())
                    } else {
                        null
                    }
                    val items = musicItemList.map { item ->
                        val srcUri = if (item.isSilence) silenceUri!! else item.uri!!
                        val itemBuilder = MediaItem.Builder().setUri(srcUri)
                        if (item.startUs > 0L || item.endUs != C.TIME_END_OF_SOURCE) {
                            itemBuilder.setClippingConfiguration(
                                MediaItem.ClippingConfiguration.Builder()
                                    .setStartPositionUs(item.startUs)
                                    .setEndPositionUs(item.endUs)
                                    .build()
                            )
                        }
                        // v0.9.2: separate music volume via GainProcessor.
                        // v0.9.7: per-clip gain multiplies the global gain.
                        val musicBuilder =
                            EditedMediaItem.Builder(itemBuilder.build())
                        val itemGain = item.gain * musicGain
                        if (itemGain != 1f) {
                            musicBuilder.setEffects(
                                Effects(
                                    listOf(
                                        GainProcessor(
                                            DefaultGainProvider.Builder(itemGain)
                                                .build()
                                        )
                                    ),
                                    emptyList()
                                )
                            )
                        }
                        musicBuilder.build()
                    }
                    sequences.add(EditedMediaItemSequence.withAudioFrom(items))
                } else if (musicUri != null) {
                    val musicBuilder = EditedMediaItem.Builder(
                        MediaItem.fromUri(musicUri)
                    )
                    if (musicGain != 1f) {
                        musicBuilder.setEffects(
                            Effects(
                                listOf(
                                    GainProcessor(
                                        DefaultGainProvider.Builder(musicGain).build()
                                    )
                                ),
                                emptyList()
                            )
                        )
                    }
                    val musicSequence = EditedMediaItemSequence.withAudioFrom(
                        listOf(musicBuilder.build())
                    ).buildUpon().setIsLooping(true).build()
                    sequences.add(musicSequence)
                }
                val compositionBuilder = Composition.Builder(sequences)
                if (compositionOverlay) {
                    compositionBuilder.setEffects(
                        Effects(emptyList(), listOf(OverlayEffect(overlays)))
                    )
                }
                builtTransformer.start(
                    compositionBuilder.build(), outputFile.absolutePath
                )
            } else {
                builtTransformer.start(videoItems.single(), outputFile.absolutePath)
            }
            handler.post(progressRunnable)
        } catch (e: Exception) {
            finishError(e.message ?: "Failed to start export")
        }
    }

    /**
     * v0.7.0: a 30-second silent PCM WAV (8 kHz mono 16-bit — it is
     * silence, so fidelity does not matter), reused for every silent
     * music gap. Callers split longer gaps into 30s pieces.
     */
    private fun silenceWavFile(): File {
        val file = File(appContext.cacheDir, "zhang-silence-30s.wav")
        if (file.exists() && file.length() > 44) return file
        val sampleRate = 8000
        val dataSize = sampleRate * 30 * 2
        FileOutputStream(file).use { out ->
            fun writeInt(v: Int) {
                out.write(v and 0xFF)
                out.write(v shr 8 and 0xFF)
                out.write(v shr 16 and 0xFF)
                out.write(v shr 24 and 0xFF)
            }
            fun writeShort(v: Int) {
                out.write(v and 0xFF)
                out.write(v shr 8 and 0xFF)
            }
            out.write("RIFF".toByteArray())
            writeInt(36 + dataSize)
            out.write("WAVE".toByteArray())
            out.write("fmt ".toByteArray())
            writeInt(16)
            writeShort(1)
            writeShort(1)
            writeInt(sampleRate)
            writeInt(sampleRate * 2)
            writeShort(2)
            writeShort(16)
            out.write("data".toByteArray())
            writeInt(dataSize)
            val zeros = ByteArray(8192)
            var left = dataSize
            while (left > 0) {
                val n = minOf(left, zeros.size)
                out.write(zeros, 0, n)
                left -= n
            }
        }
        return file
    }

    fun cancel() {
        finished = true
        handler.removeCallbacks(progressRunnable)
        try {
            transformer?.cancel()
        } catch (ignored: Exception) {
            // Ignore: transformer may already be idle.
        }
        transformer = null
        overlay?.dispose()
        overlay = null
        photoOverlays.forEach { it.dispose() }
        photoOverlays = emptyList()
        callback = null
        outputPath = null
    }

    private fun finishCompleted() {
        if (finished) return
        finished = true
        handler.removeCallbacks(progressRunnable)
        val path = outputPath
        transformer = null
        overlay?.dispose()
        overlay = null
        photoOverlays.forEach { it.dispose() }
        photoOverlays = emptyList()
        outputPath = null
        if (path != null) {
            callback?.onCompleted(path)
        } else {
            callback?.onError("Export finished but the output path is missing")
        }
        callback = null
    }

    private fun finishError(message: String) {
        if (finished) return
        finished = true
        handler.removeCallbacks(progressRunnable)
        transformer = null
        overlay?.dispose()
        overlay = null
        photoOverlays.forEach { it.dispose() }
        photoOverlays = emptyList()
        outputPath = null
        callback?.onError(message)
        callback = null
    }
}
