package com.zhangstudio.app

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlayEffect
import androidx.media3.transformer.Composition
import androidx.media3.transformer.Effects
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File

/**
 * Runs one on-device subtitle-burning export with Media3 Transformer.
 *
 * Pipeline: decode (hardware) -> [OverlayEffect] with [SubtitleOverlay]
 * (GPU-composited band bitmaps) -> H.264 encode (hardware) -> MP4 mux.
 * Video is re-encoded at its original resolution. The audio MIME type is
 * intentionally left unset, so Transformer keeps the input audio format
 * and transmuxes (copies) the audio samples when possible instead of
 * re-encoding them.
 *
 * All Transformer access happens on the main thread (Transformer requires
 * single-thread access and posts listener callbacks to that thread).
 * Progress is polled with [Transformer.getProgress], the documented
 * approach — there is no progress callback API.
 *
 * One instance serves one export. Call [cancel] to stop early.
 */
@OptIn(UnstableApi::class)
class SubtitleBurner(context: Context) {

    interface Callback {
        fun onProgress(percent: Int)
        fun onCompleted(outputPath: String)
        fun onError(message: String)
    }

    private val appContext: Context = context.applicationContext
    private var transformer: Transformer? = null
    private var overlay: SubtitleOverlay? = null
    private var callback: Callback? = null
    private var outputPath: String? = null
    private var finished = false

    private val handler = Handler(Looper.getMainLooper())
    private val progressHolder = ProgressHolder()
    private val progressRunnable = object : Runnable {
        override fun run() {
            val runningTransformer = transformer
            if (runningTransformer == null || finished) return
            val state = runningTransformer.getProgress(progressHolder)
            if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                callback?.onProgress(progressHolder.progress.coerceIn(0, 100))
            }
            if (!finished) handler.postDelayed(this, 500L)
        }
    }

    fun start(
        videoUri: Uri,
        cues: List<SubtitleCue>,
        typeface: Typeface,
        outputFile: File,
        callback: Callback
    ) {
        this.callback = callback
        finished = false
        try {
            if (outputFile.exists()) outputFile.delete()
            val subtitleOverlay = SubtitleOverlay(cues, typeface)
            overlay = subtitleOverlay
            val effects = Effects(
                emptyList(),
                listOf(OverlayEffect(listOf(subtitleOverlay)))
            )
            val editedItem = EditedMediaItem.Builder(MediaItem.fromUri(videoUri))
                .setEffects(effects)
                .build()
            val listener = object : Transformer.Listener {
                override fun onCompleted(composition: Composition, result: ExportResult) {
                    finishCompleted()
                }

                override fun onError(
                    composition: Composition,
                    result: ExportResult,
                    exception: ExportException
                ) {
                    finishError(exception.message ?: "Export failed")
                }
            }
            val builtTransformer = Transformer.Builder(appContext)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .addListener(listener)
                .build()
            transformer = builtTransformer
            outputPath = outputFile.absolutePath
            builtTransformer.start(editedItem, outputFile.absolutePath)
            handler.post(progressRunnable)
        } catch (e: Exception) {
            finishError(e.message ?: "Failed to start export")
        }
    }

    fun cancel() {
        finished = true
        handler.removeCallbacks(progressRunnable)
        try {
            transformer?.cancel()
        } catch (ignored: Exception) {
            // Ignore: transformer may already be idle.
        }
        transformer = null
        overlay?.dispose()
        overlay = null
        callback = null
        outputPath = null
    }

    private fun finishCompleted() {
        if (finished) return
        finished = true
        handler.removeCallbacks(progressRunnable)
        val path = outputPath
        transformer = null
        overlay?.dispose()
        overlay = null
        outputPath = null
        if (path != null) {
            callback?.onCompleted(path)
        } else {
            callback?.onError("Export finished but the output path is missing")
        }
        callback = null
    }

    private fun finishError(message: String) {
        if (finished) return
        finished = true
        handler.removeCallbacks(progressRunnable)
        transformer = null
        overlay?.dispose()
        overlay = null
        outputPath = null
        callback?.onError(message)
        callback = null
    }
}
